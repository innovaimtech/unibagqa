<?
//----------------------------------------------------------------------------------
// Author:        1BIT LTDA
// Copyright:     2011 by 1BIT LTDA. All Rights Reserved.
// Any unauthorized redistribution, reselling, modifying or reproduction of part
// or all of the contents in any form is strictly prohibited.
//----------------------------------------------------------------------------------

//----------------------------------------------------------------------------------
$_sesmodulename         = "customer";
$_sesbasefilterstatus   = "0";
$_sesbaseorderby        = "2";
$_sesbaseordersort      = "asc";
$_sortlinks             = Array("Rut" => "1", "Nombre" => "2", "Direcci�n" => "3", "Region" => "4",
                               "Comuna" => "5", "Vendedor" => "6,7", "Tel�fono" => "8", "Email" => "9",
                               "Categoria" => "21", "Canal" => 10);

unset($_SESSION["STATS"][$_sesmodulename]);

//----------------------------------------------------------------------------------
resetOverviewSession($_sesmodulename);

//----------------------------------------------------------------------------------
if($_REQUEST["subexec"] == "search")
{
   $_SESSION[$_sesmodulename]["sql_seller"]      = (int)$_REQUEST["sql_seller"];
   $_SESSION[$_sesmodulename]["country"]         = (int)$_REQUEST["country"];
   $_SESSION[$_sesmodulename]["regions"]         = (int)$_REQUEST["regions"];
   $_SESSION[$_sesmodulename]["provincias"]      = (int)$_REQUEST["provincias"];
   $_SESSION[$_sesmodulename]["comunas"]         = (int)$_REQUEST["comunas"];
   $_SESSION[$_sesmodulename]["sql_nadj"]        = (int)$_REQUEST["sql_nadj"];
   $_SESSION[$_sesmodulename]["sql_custcatid"]   = (int)$_REQUEST["sql_custcatid"];
   $_SESSION[$_sesmodulename]["sql_cust_type"]   = trim(addslashes($_REQUEST["sql_cust_type"]));
   $_SESSION[$_sesmodulename]["sql_cust_presu"]  = trim(addslashes($_REQUEST["sql_cust_presu"]));
   $_SESSION[$_sesmodulename]["page"]            = 0;
   $_SESSION[$_sesmodulename]["search_active"]   = 1;
}

//----------------------------------------------------------------------------------
$countries  = getCountries($CON);
$regions    = getRegions($CON);
$provincias = getProvincias($CON);
$comunas    = getComunas($CON);
$sellers    = getSellers($CON);

//----------------------------------------------------------------------------------
prepareOverviewSession($_sesmodulename, $_sesbasefilterstatus, $_sesbaseorderby, $_sesbaseordersort, 100);

//----------------------------------------------------------------------------------

//----------------------------------------------------------------------------------
$cntsql = " select count(distinct t1.id) 'cc'
            from customer t1
            {$joisql}
            where
            t1.cust_status = 1 ";

$joisql = " LEFT OUTER JOIN regions t2 ON t1.cust_regionid = t2.id
            LEFT OUTER JOIN comunas t3 ON t1.cust_comunaid = t3.id
            LEFT OUTER JOIN provincias t3x ON t1.cust_provinciaid = t3x.id
            LEFT OUTER JOIN user    t4 ON t1.cust_sellerid = t4.id
            LEFT OUTER JOIN giros   t5 ON t1.cust_giroid = t5.id
            LEFT OUTER JOIN transports t6 ON t1.cust_transportid = t6.id
            LEFT OUTER JOIN price_lists t7 ON t1.cust_plid = t7.id
            LEFT OUTER JOIN payments t8 ON t1.cust_paymentid = t8.id
            LEFT OUTER JOIN customer_cats t9 ON t1.cust_catid = t9.id 
            INNER JOIN parametros tc on tc.tabla = 'CANAL' and t1.cust_canal = tc.codigo
            /*
            LEFT JOIN (
               SELECT o1.req_cust_rut, o1.req_date, o1.req_total_netto
                  FROM offers o1
               INNER JOIN (SELECT req_cust_rut, MAX(req_date) AS max_date FROM offers GROUP BY req_cust_rut)
               o2 ON o1.req_cust_rut = o2.req_cust_rut AND o1.req_date = o2.max_date) o ON o.req_cust_rut = t1.cust_rut 


            LEFT JOIN (
               SELECT r1.req_cust_id, r1.req_crtdat, r1.req_total_netto 
               FROM orders r1
               INNER JOIN (SELECT req_cust_id, MAX(req_crtdat) AS max_ord_fecha FROM orders
                  GROUP BY req_cust_id
               ) r2 ON r1.req_cust_id = r2.req_cust_id AND r1.req_crtdat = r2.max_ord_fecha
            ) ord ON ord.req_cust_id = t1.id
            */

            LEFT JOIN orders ord ON ord.id = (
               SELECT id
               FROM orders
               WHERE req_cust_id = t1.id and req_status > 0
               ORDER BY req_crtdat DESC, id DESC
               LIMIT 1
            )
           ";

$datsql = " select t1.cust_rut
                 , t1.cust_company
                 , t1.cust_name
                 , t1.cust_street
                 , t2.name
                 , t3.nombre
                 , t4.user_firstname
                 , t4.user_lastname
                 , t1.cust_phone
                 , t1.cust_email
                 , t3x.pro_name
                 , t1.cust_cellphone
                 , t1.cust_fax
                 , t1.cust_website
                 , t1.cust_pricetolerance
                 , t1.cust_convenio_act
                 , t5.giro_name
                 , t6.trans_name
                 , t7.pl_title
                 , t8.pay_title
                 , t9.cat_name      as cat_name
                 , tc.descripcion   as canal
                 /* , o.req_date AS ultima_cotizacion
                 , o.req_total_netto AS monto_cotizacion */
                 , 0 AS ultima_cotizacion
                 , 0 AS monto_cotizacion
                 , ord.req_crtdat
                 , ord.req_total_netto
                 , t1.cust_crtdat                 
                 , t1.cust_crtdat
                 , t1.cust_presupuesto
                 , t1.cust_paymentid
                 , t1.cust_montocredito
            from customer t1
            {$joisql}
            where
            t1.cust_status = 1 ";

//----------------------------------------------------------------------------------
if($_SESSION[$_sesmodulename]["country"])
   $seasql .= " and t1.cust_countryid = {$_SESSION[$_sesmodulename]["country"]} ";
if($_SESSION[$_sesmodulename]["regions"])
   $seasql .= " and t1.cust_regionid = {$_SESSION[$_sesmodulename]["regions"]} ";
if($_SESSION[$_sesmodulename]["provincias"])
      $seasql .= " and t1.cust_provinciaid = {$_SESSION[$_sesmodulename]["provincias"]} ";
if($_SESSION[$_sesmodulename]["comunas"])
   $seasql .= " and t1.cust_comunaid = {$_SESSION[$_sesmodulename]["comunas"]} ";
if($_SESSION[$_sesmodulename]["sql_seller"])
   $seasql .= " and t1.cust_sellerid = {$_SESSION[$_sesmodulename]["sql_seller"]} ";
if((int)$_SESSION[$_sesmodulename]["sql_custcatid"])
   $seasql .= " and t1.cust_catid = {$_SESSION[$_sesmodulename]["sql_custcatid"]} ";
if((int)$_SESSION[$_sesmodulename]["sql_nadj"])
{
   if((int)$_SESSION[$_sesmodulename]["sql_nadj"] == 1)
      $seasql .= " and t1.cust_discount_spec = 1 ";
   else
      $seasql .= " and t1.cust_discount_spec = 0 ";
}
if($_SESSION[$_sesmodulename]["sql_cust_type"] != "")
   $seasql .= " and t1.cust_type = '{$_SESSION[$_sesmodulename]["sql_cust_type"]}' ";

if($_SESSION[$_sesmodulename]["sql_cust_presu"] != "")
   $seasql .= " and t1.cust_presupuesto = '{$_SESSION[$_sesmodulename]["sql_cust_presu"]}' ";


//----------------------------------------------------------------------------------
$cntsql .= $seasql;
$datsql .= $seasql;
$itemcount = $CON->select($cntsql);
$itemcount = (int)$itemcount[0]["cc"];

//----------------------------------------------------------------------------------
$_SESSION[$_sesmodulename]["startrow"] = $_SESSION[$_sesmodulename]["page"] * $_SESSION[$_sesmodulename]["rows_per_page"];

$datsql .= " order by {$_SESSION[$_sesmodulename]["orderBy"]} {$_SESSION[$_sesmodulename]["orderSort"]} ";

// echo($datsql);

// echo($datsql);
//----------------------------------------------------------------------------------
$clients = $CON->select($datsql);
?>
<script language="JavaScript">
   <?generateCountryJS($countries, $regions, $comunas, $provincias)?>
</script>
<table border="0" cellpadding="0" cellspacing="0" width="980">
<tr>
   <td height="30"><b class="content_header">Clientes</b></td>
   <td align="right" class="content_row_clear"><? if($savemsg == "") printOverviewResults($itemcount); else echo $savemsg;?></td>
</tr>
<tr>
   <td class="content_headerline" colspan="2">&nbsp;</td>
</tr>
</table>
<table border="0" cellpadding="0" cellspacing="0" width="100%">
<tr>
   <td>
      <form action="index.php" method="post" name="xform_itemsearch" class="fokusfirst">
      <input type="hidden" name="subexec" value="search">
      <input type="hidden" name="mid" value="<?=$_REQUEST["mid"]?>">
      <input type="hidden" name="printpdf" value="0">
      <input type="hidden" name="printxls" value="0">
      <?=Nifty_printH("box2", "980")?>
      <table border="0" class="content_table" cellpadding="3" cellspacing="0" width="100%">
      <colgroup>
         <col width="100">
         <col>
         <col width="100">
         <col width="300">
      </colgroup>
      <tr>
         <td class="content_tbl_header" colspan="4">Opciones de b�squeda</td>
      </tr>
      <tr>
         <td class="content_rowl">Vendedor</td>
         <td class="content_row">
            <select class="text" style="width:375px" name="sql_seller" id="sql_seller"
            onmousedown="markfield(this,0)" onblur="markfield(this,1)">
               <option value="">&lt; <?=$_LANG["FORM"]["OPTION"][0]?> &gt;</option>
               <?
               foreach($sellers as $seller)
               {  ?>
                  <option value="<?=$seller["id"]?>" <? if($seller["id"] == $_SESSION[$_sesmodulename]["sql_seller"]) echo "selected"?>>
                     <?=$seller["user_firstname"]?> <?=$seller["user_lastname"]?>
                  </option>
                  <?
               }
               ?>
            </select>
         </td>
         <td class="content_rowl">Pa�s</td>
         <td class="content_row">
            <select class="text" style="width:375px" name="country" id="country"
            onchange="setRegions(this.value)"
            onmousedown="markfield(this,0)" onblur="markfield(this,1)">
               <option value="">&lt; <?=$_LANG["FORM"]["OPTION"][0]?> &gt;</option>
               <?
               foreach($countries as $country)
               {  ?>
                  <option value="<?=$country["id"]?>"
                  <? if($country["id"] == $_SESSION[$_sesmodulename]["country"]) echo "selected"?>><?=$country["country_name"]?></option>
                  <?
               }
               ?>
            </select>
         </td>
      </tr>
      <tr>
         <td class="content_rowl">Regi�n</td>
         <td class="content_row">
            <select class="text" style="width:375px" name="regions" id="regions"
            onchange="setProvincias(this.value);"
            onmousedown="markfield(this,0)" onblur="markfield(this,1)">
               <option value="">&lt; <?=$_LANG["FORM"]["OPTION"][0]?> &gt;</option>
               <?
               if((int)$_SESSION[$_sesmodulename]["country"])
               {
                  foreach($regions as $region)
                  {
                     if($region["id_pais"] == $_SESSION[$_sesmodulename]["country"])
                     {  ?>
                        <option value="<?=$region["id"]?>"
                        <? if($region["id"] == $_SESSION[$_sesmodulename]["regions"]) echo "selected"?>><?=$region["name"]?></option>
                        <?
                     }
                  }
               }
               ?>
            </select>
         </td>
         <td class="content_rowl">Provincia</td>
         <td class="content_row">
            <select class="text" style="width:375px" name="provincias" id="provincias" onmousedown="markfield(this,0)" onblur="markfield(this,1)"
            onchange="setComunas(this.value)">
               <option value="">&lt; <?=$_LANG["FORM"]["OPTION"][0]?> &gt;</option>
               <?
               if((int)$_SESSION[$_sesmodulename]["regions"])
               {
                  foreach($provincias as $provincia)
                  {
                     if($provincia["region_id"] == $_SESSION[$_sesmodulename]["regions"])
                     {  ?>
                        <option value="<?=$provincia["id"]?>"
                        <? if($provincia["id"] == $_SESSION[$_sesmodulename]["provincias"]) echo "selected"?>><?=$provincia["pro_name"]?></option>
                        <?
                     }
                  }
               }
               ?>
            </select>
         </td>
      </tr>
      <tr>
         <td class="content_rowl">Comuna</td>
         <td class="content_row">
            <select class="text" style="width:375px" name="comunas" id="comunas" onmousedown="markfield(this,0)" onblur="markfield(this,1)">
               <option value="">&lt; <?=$_LANG["FORM"]["OPTION"][0]?> &gt;</option>
               <?
               if((int)$_SESSION[$_sesmodulename]["provincias"])
               {
                  foreach($comunas as $comuna)
                  {
                     if($comuna["prov_id"] == $_SESSION[$_sesmodulename]["provincias"])
                     {  ?>
                        <option value="<?=$comuna["id"]?>"
                        <? if($comuna["id"] == $_SESSION[$_sesmodulename]["comunas"]) echo "selected"?>><?=$comuna["nombre"]?></option>
                        <?
                     }
                  }
               }
               ?>
            </select>
         </td>
         <td class="content_rowl">Categoria</td>
         <td class="content_row">
            <?
            $sql = " select t1.id, t1.cat_name, t1.cat_crtdat
                     from customer_cats t1
                     where
                     t1.cat_status > 0
                     order by t1.cat_name";
            $custcats = $CON->select($sql);
            ?>
            <select class="text" style="width:375px" name="sql_custcatid" id="sql_custcatid"
            onmousedown="markfield(this,0)" onblur="markfield(this,1)">
               <option value="">&lt; <?=$_LANG["FORM"]["OPTION"][0]?> &gt;</option>
               <?
               foreach($custcats as $custcat)
               {  ?>
                  <option value="<?=$custcat["id"]?>" <? if($custcat["id"] == $_SESSION[$_sesmodulename]["sql_custcatid"]) echo "selected"?>>
                     <?=$custcat["cat_name"]?>
                  </option>
                  <?
               }
               ?>
            </select>
         </td>
      </tr>      
      <tr>
         <td class="content_rowl" valign="top">Tipo</td>
         <td class="content_row" valign="top">
            <select name="sql_cust_type" style="width:375px">
               <option value="" <?php if ($_SESSION[$_sesmodulename]["sql_cust_type"] == "") echo "selected"; ?>>Todos</option>
               <option value="Concesi�n" <?php if ($_SESSION[$_sesmodulename]["sql_cust_type"] == "Concesi�n") echo "selected"; ?>>Concesi�n</option>
               <option value="Distribuidor" <?php if ($_SESSION[$_sesmodulename]["sql_cust_type"] == "Distribuidor") echo "selected"; ?>>Distribuidor</option>
               <option value="Cliente final" <?php if ($_SESSION[$_sesmodulename]["sql_cust_type"] == "Cliente final") echo "selected"; ?>>Cliente final</option>
               <option value="Paciente oncol�gico" <?php if ($_SESSION[$_sesmodulename]["sql_cust_type"] == "Paciente oncol�gico") echo "selected"; ?>>Paciente oncol�gico</option>
               <option value="Cliente frecuente" <?php if ($_SESSION[$_sesmodulename]["sql_cust_type"] == "Cliente frecuente") echo "selected"; ?>>Cliente frecuente</option>
               <option value="Preferencial" <?php if ($_SESSION[$_sesmodulename]["sql_cust_type"] == "Preferencial") echo "selected"; ?>>Preferencial</option>
            </select>
         </td>     
         <td class="content_rowl" height="32">Cliente en presupuesto</td>
         <td class="content_row">
            <nobr><input type="radio" name="sql_cust_presu" value="" <?php if ($_SESSION[$_sesmodulename]["sql_cust_presu"] == "") echo "checked"; ?>>Todos</nobr>
            <nobr><input type="radio" name="sql_cust_presu" value="1" <?php if ($_SESSION[$_sesmodulename]["sql_cust_presu"] == "1") echo "checked"; ?>>SI</nobr>
            <nobr><input type="radio" name="sql_cust_presu" value="0" <?php if ($_SESSION[$_sesmodulename]["sql_cust_presu"] == "0") echo "checked"; ?>>NO</nobr>
         </td>
         <!--
         <td class="content_rowl" valign="top">Tipo</td>
         <td class="content_row" valign="top" colspan="3">
            <nobr><input type="radio" value="" name="sql_cust_type" <? if($_SESSION[$_sesmodulename]["sql_cust_type"] == "") echo "checked"?>> Todos</nobr>
            <nobr><input type="radio" value="Concesi�n" name="sql_cust_type" <? if($_SESSION[$_sesmodulename]["sql_cust_type"] == "Concesi�n") echo "checked"?>> Concesi�n</nobr>
            <nobr><input type="radio" value="Distribuidor" name="sql_cust_type" <? if($_SESSION[$_sesmodulename]["sql_cust_type"] == "Distribuidor") echo "checked"?>> Distribuidor</nobr>
            <nobr><input type="radio" value="Cliente final" name="sql_cust_type" <? if($_SESSION[$_sesmodulename]["sql_cust_type"] == "Cliente final") echo "checked"?>> Cliente final</nobr>
            <nobr><input type="radio" value="Paciente oncol�gico" name="sql_cust_type" <? if($_SESSION[$_sesmodulename]["sql_cust_type"] == "Paciente oncol�gico") echo "checked"?>> Paciente oncol�gico</nobr>
            <nobr><input type="radio" value="Cliente frecuente" name="sql_cust_type" <? if($_SESSION[$_sesmodulename]["sql_cust_type"] == "Cliente frecuente") echo "checked"?>> Cliente frecuente</nobr>
            <nobr><input type="radio" value="Preferencial" name="sql_cust_type" <? if($_SESSION[$_sesmodulename]["sql_cust_type"] == "Preferencial") echo "checked"?>> Preferencial</nobr>
         </td>
         -->
      </tr>

      <tr>
         <td class="content_row" align="right" colspan="4">
            <table border="0" cellpadding="0" cellspacing="0" width="100%">
            <colgroup>
               <col width='132'>
               <col>
               <col width="132">
               <col width="132">
            </colgroup>
            <tr>
               <td align="left">
                  <?
                  if($itemcount > 0)
                  {
                     printButton("Imprimir PDF", "postnav", "javascript: deactivateFormChange()", "document.xform_itemsearch.printpdf.value='1';submitForm(document.xform_itemsearch)", "document-pdf", 130);
                     $_SESSION["_SUBMITBTN"] = 1;
                  }
                  ?>
               </td>
               <td align="left">
                  <?
                  if($itemcount > 0)
                  {
                     printButton("Generar XLS", "postnav", "javascript: deactivateFormChange()", "document.xform_itemsearch.printxls.value='1';submitForm(document.xform_itemsearch)", "document-excel", 130);
                     $_SESSION["_SUBMITBTN"] = 1;
                  }
                  ?>
               </td>
               <td align="right">
                  <?
                  if((int)$_SESSION[$_sesmodulename]["search_active"])
                     printButton("Resetear", "postnav", "index.php?mid={$_REQUEST["mid"]}&searchexec=reset", "", "arrow-circle-double-135", 130);
                  ?>
               </td>
               <td align="right">
                  <?
                  printButton("Buscar", "postnav_save", "javascript: deactivateFormChange()", "submitForm(document.xform_itemsearch)", "magnifier", 130);
                  $_SESSION["_SUBMITBTN"] = 1;
                  ?>
               </td>
            </tr>
            </table>
         </td>
      </tr>
      </table>
      <?=Nifty_printF(false)?>
      </form>
   </td>
</tr>
<tr>
   <td>
      <?=Nifty_printH("box1", "99%")?>
      <table border="0" cellpadding="3" cellspacing="0" width="100%">
      <colgroup>
         <col width="80">
         <col>
         <col>
         <col>
         <col>
         <col>
         <col>
         <col>
         <col>
         <col>
         <col>
         <col>
         <col>
         <col>
         <col>
      </colgroup>
      <tr>
         <td class="content_tbl_header"><?=printSortLink($_sesmodulename, $_sortlinks, 0)?></td>
         <td class="content_tbl_header"><?=printSortLink($_sesmodulename, $_sortlinks, 1)?></td>
         <td class="content_tbl_header"><?=printSortLink($_sesmodulename, $_sortlinks, 2)?></td>
         <td class="content_tbl_header"><?=printSortLink($_sesmodulename, $_sortlinks, 6)?></td>
         <td class="content_tbl_header"><?=printSortLink($_sesmodulename, $_sortlinks, 7)?></td>
         <td class="content_tbl_header"><?=printSortLink($_sesmodulename, $_sortlinks, 3)?></td>
         <td class="content_tbl_header"><?=printSortLink($_sesmodulename, $_sortlinks, 4)?></td>
         <td class="content_tbl_header"><?=printSortLink($_sesmodulename, $_sortlinks, 5)?></td>
         <td class="content_tbl_header"><?=printSortLink($_sesmodulename, $_sortlinks, 8)?></td>
         <td class="content_tbl_header"><?=printSortLink($_sesmodulename, $_sortlinks, 9)?></td>
         <td class="content_tbl_header">Forma de Pago</td>
         <td class="content_tbl_header">Monto Cr�dito</td>
         <td class="content_tbl_header">Creaci�n</td>
         <td class="content_tbl_header">Ult. Cotizaci�n</td>
         <td class="content_tbl_header">$ Ult. Cotizaci�n</td>
         <td class="content_tbl_header">Ult. C.C.</td>
         <td class="content_tbl_header">$ Ult. C.C.</td>         
         <td class="content_tbl_header">Presupuesto</td>
      </tr>
      <?
      //----------------------------------------------------------------------------------
      for($x = 0; $x < count($clients) && $clients != false; $x++)
      {  ?>
         <tr bgcolor="<?=getRowColor($x)?>" onmouseover="mark(this, 0)" onmouseout="mark(this,1)">
            <td class="content_row_os"><nobr><?=$clients[$x]["cust_rut"]?></nobr></td>
            <td class="content_row_os"><nobr><?=$clients[$x]["cust_company"]?></nobr></td>
            <td class="content_row_os"><nobr><?=$clients[$x]["cust_street"]?>&nbsp;</nobr></td>
            <td class="content_row_os"><nobr><?=($_SESSION["user_type"] == 1 ? $clients[$x]["cust_phone"] : " ")?>&nbsp;</nobr></td>
            <td class="content_row_os"><nobr><?=($_SESSION["user_type"] == 1 ? $clients[$x]["cust_email"]: " ")?>&nbsp;</nobr></td>
            <td class="content_row_os"><nobr><?=$clients[$x]["name"]?>&nbsp;</nobr></td>
            <td class="content_row_os"><nobr><?=$clients[$x]["nombre"]?>&nbsp;</nobr></td>
            <td class="content_row_os"><nobr><?=$clients[$x]["user_firstname"]?>&nbsp;<?=$clients[$x]["user_lastname"]?></nobr></td>
            <td class="content_row_os"><nobr><?=($_SESSION["user_type"] == 1 ? $clients[$x]["cat_name"]: " ")?>&nbsp;</nobr></td>
            <td class="content_row_os"><nobr><?=$clients[$x]["canal"]?>&nbsp;</nobr></td>            
            <td class="content_row_os"><nobr><?=$clients[$x]["pay_title"]?>&nbsp;</nobr></td>
            <td class="content_row_os"><nobr><?=printPrice($clients[$x]["cust_pricetolerance"])?>&nbsp;</nobr></td>
            <td class="content_row_os"><nobr><?=empty($clients[$x]["cust_crtdat"])?'':date("d/m/Y",$clients[$x]["cust_crtdat"]);?>&nbsp;</nobr></td>
            <td class="content_row_os"><nobr><?=empty($clients[$x]["ultima_cotizacion"])?'':date("d/m/Y",$clients[$x]["ultima_cotizacion"]);?>&nbsp;</nobr></td>
            <td class="content_row_os"><nobr><?=printPrice($clients[$x]["monto_cotizacion"])?>&nbsp;</nobr></td>
            <td class="content_row_os"><nobr><?=empty($clients[$x]["req_crtdat"])?'':date("d/m/Y",$clients[$x]["req_crtdat"])?>&nbsp;</nobr></td>
            <td class="content_row_os"><nobr><?=printPrice($clients[$x]["req_total_netto"])?>&nbsp;</nobr></td>
            <td class="content_row_os"><nobr><?=($clients[$x]["cust_presupuesto"] == 1) ? 'SI' : 'NO'?>&nbsp;</nobr></td>
         </tr>
         <?
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["cust_rut"]     = $clients[$x]["cust_rut"];
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["cust_company"] = $clients[$x]["cust_company"];
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["cust_name"]    = $clients[$x]["cust_name"];
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["cust_street"]  = $clients[$x]["cust_street"];
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["cust_cellphone"] = ($_SESSION["user_type"] == 1 ? $clients[$x]["cust_cellphone"] : "");
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["cust_fax"]       = ($_SESSION["user_type"] == 1 ? $clients[$x]["cust_fax"] : "");
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["cust_website"]   = $clients[$x]["cust_website"];
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["pro_name"]       = $clients[$x]["pro_name"];
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["cust_pricetolerance"]  = printPrice($clients[$x]["cust_pricetolerance"],0);
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["cust_convenio_act"]    = $clients[$x]["cust_convenio_act"];
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["giro_name"]    = $clients[$x]["giro_name"];
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["trans_name"]    = $clients[$x]["trans_name"];
         if($clients[$x]["pl_title"] == "")
            $clients[$x]["pl_title"] = "PRECIOS BASICOS";
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["pl_title"]    = $clients[$x]["pl_title"];
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["pay_title"]   = $clients[$x]["pay_title"];
        /*  $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["cust_montocredito"]   = $clients[$x]["cust_montocredito"];*/
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["name"]         = $clients[$x]["name"];
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["nombre"]       = $clients[$x]["nombre"];
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["username"]     = $clients[$x]["user_firstname"]." ".$clients[$x]["user_lastname"];
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["cust_phone"]   = $clients[$x]["cust_phone"];
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["cust_email"]   = $clients[$x]["cust_email"];
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["cat_name"]     = $clients[$x]["cat_name"];
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["canal"]        = $clients[$x]["canal"];
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["creacion"]          = $clients[$x]["cust_crtdat"];
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["ultima_cotizacion"] = $clients[$x]["ultima_cotizacion"];
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["monto_cotizacion"]  = $clients[$x]["monto_cotizacion"];
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["req_crtdat"]        = $clients[$x]["req_crtdat"];
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["req_total_netto"]   = $clients[$x]["req_total_netto"];
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["presupuesto"]       = ($clients[$x]["cust_presupuesto"] == 1) ? 'SI' : 'NO';
      }

      if(!$x)
      {  ?>
         <tr bgcolor="<?=getRowColor(0)?>">
            <td class="content_row" colspan="8" align="center">
               <br>
               <b class="msg_save_err">No hay datos disponibles.</b>
               <br><br>
            </td>
         </tr>
         <?
      }
      ?>
      </table>
      <?=Nifty_printF()?>
      <br>
   </td>
</tr>
</table>
<?
//----------------------------------------------------------------------------------
if($_REQUEST["printpdf"])
  $pdffile = doc_createStatsCustomers($CON);

if($_REQUEST["printxls"])
  $xlsfile = xls_createStatsCustomers($CON);

if($pdffile != "")
{
   $doctitle = "Lista-clientes.pdf";
   $pdflink = "./libs/modules/structure/document_file.php?type=0&hash={$pdffile}.pdf&name={$doctitle}&path=../../../docs.print/";
   ?>
   <iframe height="0" width="0" frameborder="0" src="<?=$pdflink?>"></iframe>
   <?
}
?>
<?
if($xlsfile != "")
{
   $doctitle = "Lista-clientes.xls";
   $xlslink = "./libs/modules/structure/document_file.php?type=0&hash={$xlsfile}.xls&name={$doctitle}&path=../../../docs.print/";
   ?>
   <iframe height="0" width="0" frameborder="0" src="<?=$xlslink?>"></iframe>
   <?
}
?>
<iframe id="idxifrsrc" height="0" width="0" frameborder="0"></iframe>