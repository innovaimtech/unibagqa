<?
//----------------------------------------------------------------------------------
// Author:        1BIT LTDA
// Copyright:     2021 by 1BIT LTDA. All Rights Reserved.
// Any unauthorized redistribution, reselling, modifying or reproduction of part
// or all of the contents in any form is strictly prohibited.
//----------------------------------------------------------------------------------
//----------------------------------------------------------------------------------
// echo("-".$_REQUEST["fab_mat_fabric_color"]."-".$_REQUEST["fab_mat_fabric_color_hidden"]);
if((int)$_REQUEST["clonexec"])
{
   $sql = " insert into orders
            (
               req_desc, req_desc_intern, req_number, req_company_id, req_shop_id, req_cust_id,
               req_hash, req_status, req_total_netto, req_total_taxes, req_total_brutto,
               req_crtdat, req_crtusr, req_upddat, req_updusr, req_paymentid,
               req_userid_seller, req_userid_cashing, req_invoiced, req_order_shipped,
               req_cust_delivid, req_transportid, req_taxes, req_weightprice_netto, req_oc_number,
               req_oc_dat, req_discount_perc, req_discount_amt, req_discount_amount_netto,
               req_isinvcbrutto, req_custnameprov, req_isreserva, req_crtdat_first, req_isfabricate,
               req_offerid, req_despacho_desc, req_trazlogoprice_netto, req_embalaje_desc, req_pie_imprenta,
               req_isfabricate_extern, req_design_blocked_uid, req_production_act, req_production_initdate,
               req_caja_impresa, req_tipo_moi,req_medida_de_caja,req_cubicaje,req_id_clon
            )
            select req_desc, req_desc_intern, req_number, req_company_id, req_shop_id, req_cust_id,
                   req_hash, req_status, req_total_netto, req_total_taxes, req_total_brutto,
                   req_crtdat, req_crtusr, req_upddat, req_updusr, req_paymentid,
                   req_userid_seller, req_userid_cashing, req_invoiced, req_order_shipped,
                   req_cust_delivid, req_transportid, req_taxes, req_weightprice_netto, req_oc_number,
                   req_oc_dat, req_discount_perc, req_discount_amt, req_discount_amount_netto,
                   req_isinvcbrutto, req_custnameprov, req_isreserva, req_crtdat_first, req_isfabricate,
                   req_offerid, req_despacho_desc, req_trazlogoprice_netto, req_embalaje_desc, req_pie_imprenta,
                   req_isfabricate_extern, req_design_blocked_uid, req_production_act, req_production_initdate,
                   req_caja_impresa, req_tipo_moi,req_medida_de_caja,req_cubicaje,{$_REQUEST["id"]}
            from orders
            where
            id = {$_REQUEST["id"]}";
   $res = $CON->no_result($sql);
   if($res)
   {

      $sql = "";

      $neworderid = mysql_insert_id();

      $sql = " select *
               from orders
               where
               id = {$neworderid}";
      $neworder = $CON->select($sql);
      $neworder = $neworder[0];

      if(!(int)$neworder["req_isfabricate"])
         $req_num = createTransactionNumber($CON, $neworder["req_company_id"], "invoice");
      else
         $req_num  = createInternalAltaNumberOrder($CON, 1);
         
      $currtme  = time();
      $sql = " update orders
               set
               req_status              = 1,
               req_number              = '{$req_num}',
               req_crtdat_first        = {$currtme},
               req_crtdat              = {$currtme},
               req_crtusr              = {$_SESSION["user_id"]},
               req_upddat              = 0,
               req_updusr              = 0,
               req_hash                = '',
               req_production_act      = 0,
               req_production_initdate = 0,
               req_invoiced            = 0,
               req_order_shipped       = 0,
               req_oc_number           = '',
               req_oc_dat              = 0
               where
               id = {$neworderid}";
      $CON->no_result($sql);
      $sql = " insert into orders_items
               (
                  req_id,
                  item_id, item_pos, item_amount, item_amount_shipped, item_type, item_sellprice_brutto,
                  item_sellprice_taxes_perc, item_sellprice_netto, item_sellprice_netto_dsc,
                  item_sellprice_brutto_dsc, item_sellprice_taxes, item_discount, item_discount_type,
                  item_pcat_dsc_act, item_pcat_dsc1, item_pcat_dsctype1, item_pcat_dsc2, item_pcat_dsctype2,
                  item_pcat_dsc3, item_pcat_dsctype3, item_pcat_dsc4, item_pcat_dsctype4, item_vol_act,
                  item_vol_dsc, item_vol_dsctype, item_value_act, item_value_dsc, item_value_dsctype,
                  item_desc, item_promid, item_promdsc, item_amount_shipped_stop, item_order_genamount,
                  item_amount_shipped_comment, item_compdesc, item_img_hash, fab_type, fab_printtype,
                  fab_med_width, fab_med_height, fab_med_fuelle, fab_print_width, fab_print_height,
                  fab_manilla_length, fab_mat_fabric_color, fab_mat_manilla_color, 
                  fab_print_colors_front_1,
                  fab_print_colors_back_1,
                  fab_print_colors_front_2,
                  fab_print_colors_back_2,
                  fab_print_colors_front_3,
                  fab_print_colors_back_3,
                  fab_print_colors_front_4,
                  fab_print_colors_back_4,
                  fab_print_colors_front_5,
                  fab_print_colors_back_5,
                  fab_print_colors_front_6, 
                  fab_print_colors_back_6,
                  fab_print_colors_front_7, 
                  fab_print_colors_back_7,
                  fab_print_colors_front_8, 
                  fab_print_colors_back_8,
                  fab_print_colors_front_9, 
                  fab_print_colors_back_9,
                  fab_print_colors_front_10, 
                  fab_print_colors_back_10,
                  fab_print_colordesc_1,
                  fab_print_colordesc_2,
                  fab_print_colordesc_3,
                  fab_print_colordesc_4,
                  fab_print_colordesc_5,
                  fab_print_colordesc_6,
                  fab_print_colordesc_7,
                  fab_print_colordesc_8,
                  fab_print_colordesc_9,
                  fab_print_colordesc_10,
                  fab_design_imagehash,
                  fab_design_desc,
                  item_sellprice_trazado,
                  item_sellprice_barcode,
                  item_sellprice_barcodenumber,
                  fab_mat_gramms, 
                  fab_cod_pro_dis_version
               )
               select '{$neworderid}' AS 'req_id',
                      item_id, item_pos, item_amount, item_amount_shipped, item_type, item_sellprice_brutto,
                      item_sellprice_taxes_perc, item_sellprice_netto, item_sellprice_netto_dsc,
                      item_sellprice_brutto_dsc, item_sellprice_taxes, item_discount, item_discount_type,
                      item_pcat_dsc_act, item_pcat_dsc1, item_pcat_dsctype1, item_pcat_dsc2, item_pcat_dsctype2,
                      item_pcat_dsc3, item_pcat_dsctype3, item_pcat_dsc4, item_pcat_dsctype4, item_vol_act,
                      item_vol_dsc, item_vol_dsctype, item_value_act, item_value_dsc, item_value_dsctype,
                      item_desc, item_promid, item_promdsc, item_amount_shipped_stop, item_order_genamount,
                      item_amount_shipped_comment, item_compdesc, item_img_hash, fab_type, fab_printtype,
                      fab_med_width, fab_med_height, fab_med_fuelle, fab_print_width, fab_print_height,
                      fab_manilla_length, fab_mat_fabric_color, fab_mat_manilla_color,
                      fab_print_colors_front_1,
                      fab_print_colors_back_1,
                      fab_print_colors_front_2,
                      fab_print_colors_back_2,
                      fab_print_colors_front_3,
                      fab_print_colors_back_3,
                      fab_print_colors_front_4,
                      fab_print_colors_back_4,
                      fab_print_colors_front_5,
                      fab_print_colors_back_5,
                      fab_print_colors_front_6,
                      fab_print_colors_back_6,
                      fab_print_colors_front_7,
                      fab_print_colors_back_7,
                      fab_print_colors_front_8,
                      fab_print_colors_back_8,
                      fab_print_colors_front_9,
                      fab_print_colors_back_9,
                      fab_print_colors_front_10,
                      fab_print_colors_back_10,
                      fab_print_colordesc_1,
                      fab_print_colordesc_2,
                      fab_print_colordesc_3,
                      fab_print_colordesc_4,
                      fab_print_colordesc_5,
                      fab_print_colordesc_6,
                      fab_print_colordesc_7,
                      fab_print_colordesc_8,
                      fab_print_colordesc_9,
                      fab_print_colordesc_10,
                      fab_design_imagehash,
                      fab_design_desc,
                      item_sellprice_trazado,
                      item_sellprice_barcode,
                      item_sellprice_barcodenumber,
                      fab_mat_gramms,
                      fab_cod_pro_dis_version
               from orders_items
               where
               req_id = {$_REQUEST["id"]}";
      $CON->no_result($sql);
      $sql = " select *
               from orders_items
               where
               req_id = {$neworderid}";
      $temppos = $CON->select($sql);
      foreach($temppos AS $tempposrow)
      {
         $item_img_hash = "";
         $fab_design_imagehash = "";

         if($tempposrow["item_img_hash"] != "")
         {
            $doc_dir  = "{$_SESSION["_CONF"]["conf_shopadmin_path"]}docs.offer/";
            $doc_file = $doc_dir.$tempposrow["item_img_hash"];
            
            $item_img_hash = "{$neworderid}_".$tempposrow["item_img_hash"];
            copy($doc_file, $doc_dir.$item_img_hash);
         }
         if($tempposrow["fab_design_imagehash"] != "")
         {
            $doc_dir  = "{$_SESSION["_CONF"]["conf_shopadmin_path"]}docs.order/";
            $doc_file = $doc_dir.$tempposrow["fab_design_imagehash"];
            
            $fab_design_imagehash = "{$neworderid}_".$tempposrow["fab_design_imagehash"];
            copy($doc_file, $doc_dir.$fab_design_imagehash);
         }
         $sql = " update orders_items
                  set
                  item_amount_shipped  = 0,
                  item_img_hash        = '{$item_img_hash}',
                  fab_design_imagehash = '{$fab_design_imagehash}',
                  fab_print_colors_front_1  = {$fab_print_colors_front_1},
                      fab_print_colors_front_2  = {$fab_print_colors_front_2},
                      fab_print_colors_front_3  = {$fab_print_colors_front_3},
                      fab_print_colors_front_4  = {$fab_print_colors_front_4},
                      fab_print_colors_front_5  = {$fab_print_colors_front_5},
                      fab_print_colors_front_6  = {$fab_print_colors_front_6},
                      fab_print_colors_front_7  = {$fab_print_colors_front_7},
                      fab_print_colors_front_8  = {$fab_print_colors_front_8},
                      fab_print_colors_front_9  = {$fab_print_colors_front_9},
                      fab_print_colors_front_10 = {$fab_print_colors_front_10},
                      fab_cod_pro_dis_version   = {$fab_cod_pro_dis_version}
                  where
                  req_id      = {$tempposrow["req_id"]} and
                  item_id     = {$tempposrow["item_id"]} and
                  item_pos    = {$tempposrow["item_pos"]}";
         $CON->no_result($sql);
                  
      }
      ?>
      <script language="JavaScript">
         alert('Folio <?=$req_num?> generado exitosamente.\nRedireccionando a la nueva CC...');
         location.href = '/index.php?mid=<?=$_REQUEST["mid"]?>&exec=edit&id=<?=$neworderid?>';
      </script>
      <?
      exit;
   }
}

//----------------------------------------------------------------------------------
$_HIDETAXES = true;

if($_REQUEST["showfullcust"] == "1")
   $_SESSION["xorders"]["fullcust"] = "1";
if($_REQUEST["showfullcust"] == "0")
   $_SESSION["xorders"]["fullcust"] = "";

//----------------------------------------------------------------------------------
$sql = " select *
         from user
         where
         id = {$_SESSION["user_id"]}";
$userdata = $CON->select($sql);
$userdata = $userdata[0];

//----------------------------------------------------------------------------------
$sql = " select t2.id, t2.add_name
         from tran_comments t1
         INNER JOIN tran_comments_vals t2 ON t2.add_com_id = t1.id
         where
         t1.id          = {$_CONFIG["TELA_COLOR_CHARACTID"]} and
         t2.add_status  = 1
         order by t2.add_name";
$colors = $CON->select($sql);

//----------------------------------------------------------------------------------
if($_REQUEST["delnvrevx"] != "")
{
   $sql = " delete from orders_rels
            where
            req_id_1 = {$_REQUEST["id"]} and
            req_id_2 = {$_REQUEST["delnvrevx"]}";
   $CON->no_result($sql);
   
   $sql = " delete from orders_rels
            where
            req_id_2 = {$_REQUEST["id"]} and
            req_id_1 = {$_REQUEST["delnvrevx"]}";
   $CON->no_result($sql);
}

//----------------------------------------------------------------------------------
if($_REQUEST["cancelshp"] == "1")
{
   $currtme = time();

   $sql = " update orders
            set
            req_order_shipped = 1,
            req_status        = 4,
            req_updusr        = {$_SESSION["user_id"]},
            req_upddat        = {$currtme}
            where
            id = {$_REQUEST["id"]}";
   $res = $CON->no_result($sql);

   $savemsg = getSaveMessage($res);
}

//----------------------------------------------------------------------------------
if((int)$_REQUEST["restablecer"])
{
   $currtme = time();
   $sql = " update orders
            set
            req_status           = 1,
            req_updusr           = {$_SESSION["user_id"]},
            req_upddat           = {$currtme},
            req_fecha_aprobacion = 0
            where
            id = {$_REQUEST["id"]}";
   $res = $CON->no_result($sql);

   $savemsg = getSaveMessage($res);
}

//----------------------------------------------------------------------------------
if($_REQUEST["revertshp"] == "1")
{
   $currtme = time();

   $sql = " update orders
            set
            req_order_shipped = 0,
            req_status        = 3,
            req_updusr       = {$_SESSION["user_id"]},
            req_upddat       = {$currtme}
            where
            id = {$_REQUEST["id"]}";
   $res = $CON->no_result($sql);

   $savemsg = getSaveMessage($res);
}

//----------------------------------------------------------------------------------
if($_REQUEST["subexec"] == "prodinitsave" && (int)$_REQUEST["prodact"])
{
   $currtme = time();

   $_REQUEST["prd_plantaid"]  = (int)$_REQUEST["prd_plantaid"];
   $_REQUEST["prd_desc"]      = trim(addslashes($_REQUEST["prd_desc"]));

   $sql = " insert into prod_header
            (prd_crtdat, prd_crtusr, prd_status, prd_desc, prd_plantaid, prd_reqid)
            VALUES
            ({$currtme}, {$_SESSION["user_id"]}, 1, '{$_REQUEST["prd_desc"]}', {$_REQUEST["prd_plantaid"]},
             {$_REQUEST["id"]})";
   $res = $CON->no_result($sql);
   if($res)
   {
      $prodid = mysql_insert_id();
   
      foreach(array_keys($_REQUEST) AS $reqkey)
      {
         if(strpos($reqkey, "prodplan_amt_") !== false && strpos($reqkey, "prodplan_amt_") == 0)
         {
            $idx = substr($reqkey, strrpos($reqkey, "_") +1);

            $prodplan_amt  = getPrice($_REQUEST["prodplan_amt_{$idx}"]);
            $prodplan_date = trim($_REQUEST["prodplan_date_{$idx}"]);

            if($prodplan_amt > 0 && $prodplan_date != "")
            {
               $prodplan_date = explode(".", $prodplan_date);
               $prodplan_date = mktime(15, 0, 0, $prodplan_date[1], $prodplan_date[0], $prodplan_date[2]);
               $sql = " insert into prod_amtplan
                        (prodplan_amt, prodplan_date, prodplan_prdid)
                        VALUES
                        ({$prodplan_amt}, {$prodplan_date}, {$prodid})";
               $CON->no_result($sql);
            }
         }
      }

      $sql = " update orders
               set
               req_production_act = 1,
               req_production_initdate = {$currtme}
               where
               id = {$_REQUEST["id"]}";
      $res = $CON->no_result($sql);

      $_REQUEST['sendprodmail'] = 1;
   }

   $savemsg = getSaveMessage($res);
}
//----------------------------------------------------------------------------------------------------------------------------------------
if($_REQUEST["subexec"] == "create")
{
   $currtme = time();

   $_REQUEST["cust_id_0"]     = (int)$_REQUEST["cust_id_0"];
   $_REQUEST["company_id"]    = (int)$_REQUEST["company_id"];
   $_REQUEST["shop_id"]       = (int)$_REQUEST["shop_id"];
   $_REQUEST["req_taxes"]     = (int)$_REQUEST["req_taxes"];
   $_REQUEST["req_isinvcbrutto"] = (int)$_REQUEST["req_isinvcbrutto"];
   $_REQUEST["req_isreserva"] = (int)$_REQUEST["req_isreserva"];
   $_REQUEST["order_id"]      = (int)$_REQUEST["order_id"];

   //----------------------------------------------------------------------------------
   $sql = " select t1.cust_paymentid, t1.cust_sellerid, t1.cust_transportid, t2.pay_days
            from customer t1
            LEFT OUTER JOIN payments t2 ON t1.cust_paymentid = t2.id
            where
            t1.id = {$_REQUEST["cust_id_0"]}";
   $custdata = $CON->select($sql);
   $custdata = $custdata[0];

   $req_userid_seller   = (int)$custdata["cust_sellerid"];
   $req_userid_cashing  = (int)$custdata["cust_sellerid"];
   $req_paymentid       = (int)$custdata["cust_paymentid"];
   $req_paymentdays     = (int)$custdata["pay_days"];
   $req_transportid     = (int)$custdata["cust_transportid"];

   //----------------------------------------------------------------------------------
   $_SELLRET = sellerHasReplacement($CON, $req_userid_seller, time());
   $seller_repluserid   = $_SELLRET["SELLER"];
   $cashing_repluserid  = $_SELLRET["CASHER"];

   //----------------------------------------------------------------------------------
   if((int)$seller_repluserid)
      $req_userid_seller = $seller_repluserid;
   if((int)$cashing_repluserid)
      $req_userid_cashing = $cashing_repluserid;

   //----------------------------------------------------------------------------------
   $req_num = createTransactionNumber($CON, $_REQUEST["company_id"], "invoice");

   //----------------------------------------------------------------------------------
   $sql = " insert into orders
            (req_number, req_company_id, req_shop_id, req_cust_id, req_paymentid, 
             req_userid_seller, req_userid_cashing, req_taxes, req_transportid,
             req_crtdat, req_crtusr, req_isinvcbrutto, req_isreserva, req_crtdat_first)
            VALUES
            ('{$req_num}', {$_REQUEST["company_id"]}, {$_REQUEST["shop_id"]}, {$_REQUEST["cust_id_0"]},
              {$req_paymentid}, {$req_userid_seller}, {$req_userid_cashing}, {$_REQUEST["req_taxes"]},
              {$req_transportid}, {$currtme}, {$_SESSION["user_id"]}, {$_REQUEST["req_isinvcbrutto"]},
              {$_REQUEST["req_isreserva"]}, {$currtme})";
   $res = $CON->no_result($sql);

   if($res)
   {
      $sql = " select MAX(id) 'thisid'
               from orders
               where
               req_crtusr = {$_SESSION["user_id"]}";
      $sorder = $CON->select($sql);
      $_REQUEST["id"]   = $sorder[0]["thisid"];

      if((int)$_REQUEST["order_id"])
      {
         $sql = " insert into orders_rels
                  (req_id_1, req_id_2)
                  VALUES
                  ({$_REQUEST["id"]}, {$_REQUEST["order_id"]})";
         $CON->no_result($sql);
      }

      ?>
      <script language="JavaScript">
         location.href = 'index.php?mid=689&exec=edit&id=<?=$_REQUEST["id"]?>'
      </script>
      <?
   }

   $savemsg = getSaveMessage($res);
}

//----------------------------------------------------------------------------------
if($_REQUEST["subexec"] == "save")
{
   $currtme = time();
   //----------------------------------------------------------------------------------
   $sql = " select *
            from orders
            where
            id = {$_REQUEST["id"]}";
   $headdata = $CON->select($sql);
   $headdata = $headdata[0];

   $_REQUEST["order_id"] = (int)$_REQUEST["order_id"];
   if((int)$_REQUEST["order_id"] && $_REQUEST["order_id"] != $_REQUEST["id"])
   {
      $sql = " insert into orders_rels
               (req_id_1, req_id_2)
               VALUES
               ({$_REQUEST["id"]}, {$_REQUEST["order_id"]})";
      $CON->no_result($sql);
   }
  
   //----------------------------------------------------------------------------------
   $_REQUEST["req_desc"]            = trim(addslashes($_REQUEST["req_desc"]));
   $_REQUEST["req_desc_intern"]     = trim(addslashes($_REQUEST["req_desc_intern"]));
   $_REQUEST["req_number"]          = trim(addslashes($_REQUEST["req_number"]));
   $_REQUEST["req_crtdat"]          = trim(addslashes($_REQUEST["req_crtdat"]));
   $_REQUEST["req_custnameprov"]    = trim(addslashes($_REQUEST["req_custnameprov"]));
   $_REQUEST["req_paymentid"]       = (int)$_REQUEST["req_paymentid"];
   $_REQUEST["req_userid_seller"]   = (int)$_REQUEST["req_userid_seller"];
   $_REQUEST["req_userid_cashing"]  = (int)$_REQUEST["req_userid_cashing"];
   $_REQUEST["req_transportid"]     = (int)$_REQUEST["req_transportid"];
   $_REQUEST["req_cust_delivid"]    = (int)$_REQUEST["req_cust_delivid"];
   $_REQUEST["req_isreserva"]       = (int)$_REQUEST["req_isreserva"];
   $_REQUEST["req_cust_aviso_months"] = (int)$_REQUEST["req_cust_aviso_months"];
   $_REQUEST["req_despacho_desc"]   = trim(addslashes($_REQUEST["req_despacho_desc"]));
   $_REQUEST["req_oc_dat"]          = trim(addslashes($_REQUEST["req_oc_dat"]));
   $_REQUEST["req_oc_number"]       = trim(addslashes($_REQUEST["req_oc_number"]));
   $_REQUEST["req_embalaje_desc"]   = trim(addslashes($_REQUEST["req_embalaje_desc"]));
   $_REQUEST["req_pie_imprenta"]    = trim(addslashes($_REQUEST["req_pie_imprenta"]));
   $_REQUEST["req_discount_perc"]   = getPrice($_REQUEST["req_discount_perc"],2);
   $_REQUEST["req_discount_amt"]    = getPrice($_REQUEST["req_discount_amt"]);
   $_REQUEST["req_caja_impresa"]    = trim(addslashes($_REQUEST["req_caja_impresa"]));
   $_REQUEST["req_tipo_moi"]        = trim(addslashes($_REQUEST["req_tipo_moi"]));
   $_REQUEST["req_medida_de_caja"]  = trim(addslashes($_REQUEST["req_medida_de_caja"]));
   $_REQUEST["req_cubicaje"]        = trim(addslashes($_REQUEST["req_cubicaje"]));
   $_REQUEST["fab_cod_pro_dis_version"] = trim(addslashes($_REQUEST["fab_cod_pro_dis_version"]));
   //----------------------------------------------------------------------------------
   $_REQUEST["req_crtdat"]          = explode(".", $_REQUEST["req_crtdat"]);
   $_REQUEST["req_crtdat"]          = (int)mktime(date('H'), date('i'), date('s'), $_REQUEST["req_crtdat"][1], $_REQUEST["req_crtdat"][0], $_REQUEST["req_crtdat"][2]);
   $_REQUEST["req_oc_dat"]          = explode(".", $_REQUEST["req_oc_dat"]);
   $_REQUEST["req_oc_dat"]          = (int)mktime(date('H'), date('i'), date('s'), $_REQUEST["req_oc_dat"][1], $_REQUEST["req_oc_dat"][0], $_REQUEST["req_oc_dat"][2]);
   $_REQUEST["req_fec_despacho"]    = (int)$_REQUEST["req_fec_despacho"];

      /* Envio informacion a CRM */
   
   if($_REQUEST["req_status"] == 2)
   {
      $sql       = "select * from customer where id = '{$headdata["req_cust_id"]}'";
 
      $idcliente = $CON->select($sql);
      $idcliente = $idcliente[0];
      $idcrm     = $idcliente['cust_id_crm'];

      $sql         = "select * from parametros where tabla = 'CANAL' and codigo = {$idcliente["cust_canal"]}";
      $canal       = $CON->select($sql);
      $canal       = $canal[0];
      $canal       = $canal["descripcion"];

      $sql       = "select min(item_sellprice_netto_dsc) as monto from offers_items where req_id = {$_REQUEST["id"]}";
      $monto     = $CON->select($sql);
      $monto     = $monto[0]['monto'];

      $sql        = "select nombre from comunas where id = {$idcliente['cust_comunaid']}";
      $comunas    = $CON->select($sql);
      $comuna     = $comunas[0]['nombre'];

      $sql        = "select * from regions where id = {$idcliente['cust_regionid']}";
      $regiones   = $CON->select($sql);
      $region     = $regiones[0]['name'];

      $sql        = "select * from country where id = {$idcliente['cust_countryid']}";
      $paises     = $CON->select($sql);
      $pais       = $paises[0]['country_name'];
      // echo($sql);

      $sql         = "select * from parametros where tabla = 'CRM_SELLER' and codigo = {$custvendedor['id']}";
      $vendedor    = $CON->select($sql);
      $vendedor    = $vendedor[0];
      $vendedor    = $vendedor["descripcion"];

      $sql = "select id, cat_name, cat_crtdat from customer_cats where id = {$idcliente['cust_catid']}";
      $categorias = $CON->select($sql);
      $categoria  = $categorias[0]['cat_name'];

      $sql        = "select * from giros where id = {$idcliente['cust_giroid']}";
      $giros      = $CON->select($sql);
      $giro       = $giros[0]['giro_name'];

      $sql = "select * from customer_contacts where id = {$attachfile[0]["req_id_contacto"]}";
      $cus_contacto = $CON->select($sql);
      $cus_contacto = $cus_contacto[0];
      if($cus_contacto["add_id_crm"]=="")
         $idcrm      = $idcliente['cust_id_crm'];
      else
         $idcrm      = $cus_contacto["add_id_crm"];
     
      $nombre      = $cus_contacto['add_firstname'].' '.$cus_contacto["add_lastname"];
      $rut         = $idcliente['cust_rut'];
      $direccion   = $idcliente['cust_street'];
      $empresa     = $idcliente['cust_company'];
      $email       = $cus_contacto['add_email'];
      $celular     = $cus_contacto['add_cellphone'];
      $iderp       = $idcliente['id'];
      $fechaseg    = date("Y/m/d", strtotime("+{$_REQUEST['req_cust_aviso_months']} months"));
      if($idcrm != "")
      {
         $sql = "insert into log_crm (log_crm_fecha
                                  ,log_crm_cust_id
                                  ,log_crm_cust_id_crm
                                  ,log_crm_identificador
                                  ,log_crm_accion
                                  ,log_crm_respuesta
                                  ,log_crm_idrespuesta
                                  ,log_crm_boton)                                  
              select {$currtme}
                    ,{$idcliente['id']}
                    ,'{$idcliente['cust_id_crm']}'
                    ,{$_REQUEST["id"]}
                    ,'compra'
                    ,'{$respuesta["status"]}'
                    ,'{$respuesta["id"]}'
                    ,'{$_REQUEST["subexec"]}'";

         $CON->no_result($sql);         
      }
 
   }
   if($_REQUEST["req_paymentid"] != $headdata["req_paymentid"])
      $itemfullupdate = true;
   else
      $itemfullupdate = false;

   //----------------------------------------------------------------------------------
   $sql = " select *
            from orders
            where
            id = {$_REQUEST["id"]}";
   $headdata = $CON->select($sql);
   $headdata = $headdata[0];

   $revert  = false;
   $final   = false;
   if($headdata["req_status"] == 1 && $_REQUEST["req_status"] == 2)
      $final = true;
   if($headdata["req_status"] > 1 && $_REQUEST["req_status"] == 1)
      $revert = true;

   $_REQUEST["req_production_initdate"] = ($_REQUEST["req_status"] == 2) ? $currtme : 0;
   
   $sql = " update orders
            set
            req_status              = {$_REQUEST["req_status"]},
            req_desc                = '{$_REQUEST["req_desc"]}',
            req_desc_intern         = '{$_REQUEST["req_desc_intern"]}',
            req_number              = '{$_REQUEST["req_number"]}',
            req_paymentid           = {$_REQUEST["req_paymentid"]},
            req_userid_seller       = {$_REQUEST["req_userid_seller"]},
            req_userid_cashing      = {$_REQUEST["req_userid_cashing"]},
            req_transportid         = {$_REQUEST["req_transportid"]},
            req_cust_delivid        = {$_REQUEST["req_cust_delivid"]},
            req_oc_number           = '{$_REQUEST["req_oc_number"]}',
            req_oc_dat              = {$_REQUEST["req_oc_dat"]},
            req_discount_perc       = {$_REQUEST["req_discount_perc"]},
            req_discount_amt        = {$_REQUEST["req_discount_amt"]},
            req_custnameprov        = '{$_REQUEST["req_custnameprov"]}',
            req_crtdat              = {$_REQUEST["req_crtdat"]},
            req_isreserva           = {$_REQUEST["req_isreserva"]},
            req_despacho_desc       = '{$_REQUEST["req_despacho_desc"]}',
            req_embalaje_desc       = '{$_REQUEST["req_embalaje_desc"]}',
            req_pie_imprenta        = '{$_REQUEST["req_pie_imprenta"]}',
            req_cust_aviso_months   = {$_REQUEST["req_cust_aviso_months"]},
            req_updusr              = {$_SESSION["user_id"]},
            req_caja_impresa        = '{$_REQUEST["req_caja_impresa"]}',
            req_tipo_moi            = '{$_REQUEST["req_tipo_moi"]}',
            req_medida_de_caja      = '{$_REQUEST["req_medida_de_caja"]}',
            req_cubicaje            = '{$_REQUEST["req_cubicaje"]}',
            req_upddat              = {$currtme},
            req_fec_despacho        = {$_REQUEST["req_fec_despacho"]},
            req_fecha_aprobacion    = 0,
            req_production_initdate = {$_REQUEST["req_production_initdate"]}
            where id = {$_REQUEST["id"]}";
   $res = $CON->no_result($sql);
   $savemsg = getSaveMessage($res);

   if($_REQUEST["req_status"] == 2)
   {
      $sql = " update orders
                  set req_fecha_aprobacion = {$currtme}
               where id = {$_REQUEST["id"]}";
      $CON->no_result($sql);
   }


   $sql = "select * from item where item_number_prod = '{$_REQUEST["item_number_prod"]}'";
   $ite = $CON->select($sql);
   $ite = $ite[0];
   //----------------------------------------------------------------------------------
   $sql = " delete from orders_comments_item_vals
            where
            orders_item_id = {$ite["id"]}";
   $CON->no_result($sql);

   foreach(array_keys($_REQUEST) AS $reqkey)
   {

      if(strpos($reqkey, "comvals_") !== false && strpos($reqkey, "comvals_") == 0)
      {
         $idxarr        = explode("_", $reqkey);
         $com_id        = $idxarr[1];
         $val_id        = $_REQUEST[$reqkey];

         if((int)$val_id && (int)$com_id)
         {
            $sql = " insert into orders_comments_item_vals
                     ( orders_id
                     , orders_item_id
                     , orders_com_id
                     , orders_val_id)
                     VALUES
                     ( {$_REQUEST["id"]}
                     , {$ite["id"]}
                     , {$com_id}
                     , {$val_id}
                     )";
            $CON->no_result($sql);
         }
      }
   }

   //----------------------------------------------------------------------------------
   $poscounter = 0;
   foreach(array_keys($_REQUEST) AS $reqkey)
   {
      if(strpos($reqkey, "item_id_") !== false && strpos($reqkey, "item_id_") == 0)
      {
         $idx           = substr($reqkey, strrpos($reqkey, "_") +1);
         $existing_id   = (int)$_REQUEST["existing_id_{$idx}"];
         $existing_pos  = (int)$_REQUEST["existing_pos_{$idx}"];
         $genamount     = getPrice($_REQUEST["item_order_genamount_{$idx}"],2);
         
         $_REQUEST["item_amount_{$idx}"]  = getPrice($_REQUEST["item_amount_{$idx}"],4);

         //if($_REQUEST["item_id_{$idx}"] != "" && $_REQUEST["item_amount_{$idx}"] > 0.00 && ($_REQUEST["item_amount_{$idx}"] <= (float)$_REQUEST["stkdisponosave_{$idx}"] || $revert == true))
         if($_REQUEST["item_id_{$idx}"] != "" && $_REQUEST["item_amount_{$idx}"] > 0.00 && $revert == false)
         {
            $itemvalues    = explode("#", $_REQUEST["item_id_{$idx}"]);
            $sql_id        = (int)$itemvalues[0];
            $sql_type      = $itemvalues[1];

            if((int)$headdata["req_taxes"])
               $sql_taxesperc = getPrice($_REQUEST["item_sellprice_taxes_perc_{$idx}"], 2);
            else
               $sql_taxesperc = 0;

            //----------------------------------------------------------------------------------
            if(!(int)$headdata["req_isinvcbrutto"])
            {
               $sql_sellnetto = getPrice($_REQUEST["item_sellprice_netto_{$idx}"]);
               $sql_taxes     = (float)sprintf("%.{$_SESSION["_CONF"]["conf_number_decimal_places"]}f", $sql_sellnetto / 100 * $sql_taxesperc);
               $sql_sellprice = (float)sprintf("%.{$_SESSION["_CONF"]["conf_number_decimal_places"]}f", $sql_sellnetto + $sql_taxes);
            }
            else
            {
               $sql_sellprice = getPrice($_REQUEST["item_sellprice_brutto_{$idx}"]);
               $sql_taxes     = (float)sprintf("%.{$_SESSION["_CONF"]["conf_number_decimal_places"]}f", $sql_sellprice / (100 + $sql_taxesperc) * $sql_taxesperc);
               $sql_sellnetto = (float)sprintf("%.{$_SESSION["_CONF"]["conf_number_decimal_places"]}f", $sql_sellprice - $sql_taxes);
            }

            //----------------------------------------------------------------------------------
            //$sql_sellnetto = getPrice($_REQUEST["item_sellprice_netto_{$idx}"]);
            //$sql_taxes     = (float)sprintf("%.{$_SESSION["_CONF"]["conf_number_decimal_places"]}f", $sql_sellnetto / 100 * $sql_taxesperc);
            //$sql_sellprice = (float)sprintf("%.{$_SESSION["_CONF"]["conf_number_decimal_places"]}f", $sql_sellnetto + $sql_taxes);

            //----------------------------------------------------------------------------------
            if((int)$_REQUEST["manual_pos_{$idx}"])
               $_REQUEST["item_desc_{$idx}"] = trim(addslashes($_REQUEST["item_desc_{$idx}"]));
            else
               $_REQUEST["item_desc_{$idx}"] = "";

            //----------------------------------------------------------------------------------
            $_REQUEST["item_compdesc_{$idx}"] = str_replace("\r", "", $_REQUEST["item_compdesc_{$idx}"]);
            $_REQUEST["item_compdesc_{$idx}"] = str_replace("\n", "", $_REQUEST["item_compdesc_{$idx}"]);
            $_REQUEST["item_compdesc_{$idx}"] = str_replace("<div>", "\n", $_REQUEST["item_compdesc_{$idx}"]);
            $_REQUEST["item_compdesc_{$idx}"] = str_replace("<br>", "\n", $_REQUEST["item_compdesc_{$idx}"]);
            $_REQUEST["item_compdesc_{$idx}"] = str_replace("</div>", "", $_REQUEST["item_compdesc_{$idx}"]);
            $_REQUEST["item_compdesc_{$idx}"] = str_replace("&nbsp;", " ", $_REQUEST["item_compdesc_{$idx}"]);
            $_REQUEST["item_compdesc_{$idx}"] = strip_tags($_REQUEST["item_compdesc_{$idx}"],'<b><i></b></i>');
            $_REQUEST["item_compdesc_{$idx}"] = trim(addslashes($_REQUEST["item_compdesc_{$idx}"]));
            $_REQUEST["fab_print_colordesc_1"]  = trim(addslashes($_REQUEST["fab_print_colordesc_1"]));
            $_REQUEST["fab_print_colordesc_2"]  = trim(addslashes($_REQUEST["fab_print_colordesc_2"]));
            $_REQUEST["fab_print_colordesc_3"]  = trim(addslashes($_REQUEST["fab_print_colordesc_3"]));
            $_REQUEST["fab_print_colordesc_4"]  = trim(addslashes($_REQUEST["fab_print_colordesc_4"]));
            $_REQUEST["fab_print_colordesc_5"]  = trim(addslashes($_REQUEST["fab_print_colordesc_5"]));
            $_REQUEST["fab_print_colordesc_6"]  = trim(addslashes($_REQUEST["fab_print_colordesc_6"]));
            $_REQUEST["fab_print_colordesc_7"]  = trim(addslashes($_REQUEST["fab_print_colordesc_7"]));
            $_REQUEST["fab_print_colordesc_8"]  = trim(addslashes($_REQUEST["fab_print_colordesc_8"]));
            $_REQUEST["fab_print_colordesc_9"]  = trim(addslashes($_REQUEST["fab_print_colordesc_9"]));
            $_REQUEST["fab_print_colordesc_10"]  = trim(addslashes($_REQUEST["fab_print_colordesc_10"]));
            $_REQUEST["fab_design_desc"]        = trim(addslashes($_REQUEST["fab_design_desc"]));


               $_REQUEST["fab_print_colors_front_1"] =  (int)$_REQUEST["fab_print_colors_front_1"];
               $_REQUEST["fab_print_colors_front_2"] =  (int)$_REQUEST["fab_print_colors_front_2"];
               $_REQUEST["fab_print_colors_front_3"] =  (int)$_REQUEST["fab_print_colors_front_3"];
               $_REQUEST["fab_print_colors_front_4"] =  (int)$_REQUEST["fab_print_colors_front_4"];
               $_REQUEST["fab_print_colors_front_5"] =  (int)$_REQUEST["fab_print_colors_front_5"];
               $_REQUEST["fab_print_colors_front_6"] =  (int)$_REQUEST["fab_print_colors_front_6"];
               $_REQUEST["fab_print_colors_front_7"] =  (int)$_REQUEST["fab_print_colors_front_7"];
               $_REQUEST["fab_print_colors_front_8"] =  (int)$_REQUEST["fab_print_colors_front_8"];
               $_REQUEST["fab_print_colors_front_9"] =  (int)$_REQUEST["fab_print_colors_front_9"];
               $_REQUEST["fab_print_colors_front_10"] =  (int)$_REQUEST["fab_print_colors_front_10"];

               $_REQUEST["fab_print_colors_back_1"] = (int)$_REQUEST["fab_print_colors_back_1"];
               $_REQUEST["fab_print_colors_back_2"] = (int)$_REQUEST["fab_print_colors_back_2"];
               $_REQUEST["fab_print_colors_back_3"] = (int)$_REQUEST["fab_print_colors_back_3"];
               $_REQUEST["fab_print_colors_back_4"] = (int)$_REQUEST["fab_print_colors_back_4"];
               $_REQUEST["fab_print_colors_back_5"] = (int)$_REQUEST["fab_print_colors_back_5"];
               $_REQUEST["fab_print_colors_back_6"] = (int)$_REQUEST["fab_print_colors_back_6"];
               $_REQUEST["fab_print_colors_back_7"] = (int)$_REQUEST["fab_print_colors_back_7"];
               $_REQUEST["fab_print_colors_back_8"] = (int)$_REQUEST["fab_print_colors_back_8"];
               $_REQUEST["fab_print_colors_back_9"] = (int)$_REQUEST["fab_print_colors_back_9"];
               $_REQUEST["fab_print_colors_back_10"] = (int)$_REQUEST["fab_print_colors_back_10"];


            /*
            $_REQUEST["fab_mat_fabric_color"] = $_REQUEST["fab_mat_fabric_color_hidden"];
            $_REQUEST["fab_mat_manilla_color"] = $_REQUEST["fab_mat_manilla_color_hidden"];
            */
            //----------------------------------------------------------------------------------
            $_REQUEST["fab_print_width"]        = (int)$_REQUEST["fab_print_width"];
            $_REQUEST["fab_print_height"]       = (int)$_REQUEST["fab_print_height"];
            $_REQUEST["fab_manilla_length"]     = (int)$_REQUEST["fab_manilla_length"];
            $_REQUEST["fab_mat_fabric_color"]   = (int)$_REQUEST["fab_mat_fabric_color"];
            $_REQUEST["fab_mat_manilla_color"]  = (int)$_REQUEST["fab_mat_manilla_color"];
            $_REQUEST["fab_mat_gramms"]         = (int)$_REQUEST["fab_mat_gramms"];
            $_REQUEST["fab_mat_dispositivo"]    = trim(addslashes($_REQUEST["fab_mat_dispositivo"]));

            //----------------------------------------------------------------------------------
            $_REQUEST["item_sellprice_trazado_{$idx}"] = getPrice($_REQUEST["item_sellprice_trazado_{$idx}"]);
            $_REQUEST["item_sellprice_barcode_{$idx}"] = getPrice($_REQUEST["item_sellprice_barcode_{$idx}"]);
            $_REQUEST["item_sellprice_barcodenumber_{$idx}"] = trim(addslashes($_REQUEST["item_sellprice_barcodenumber_{$idx}"]));

            if((int)$headdata["req_isfabricate"])
            {
               $_REQUEST["item_discount_{$idx}"]         = 0.00;
               $_REQUEST["item_discount_type_{$idx}"]    = 0;

               if($_REQUEST["item_sellprice_trazado_{$idx}"] > 0.00 || $_REQUEST["item_sellprice_barcode_{$idx}"] > 0.00)
               {
                  $_REQUEST["item_discount_{$idx}"]      = -1 * $_REQUEST["item_amount_{$idx}"] * ($_REQUEST["item_sellprice_trazado_{$idx}"] + $_REQUEST["item_sellprice_barcode_{$idx}"]);
                  $_REQUEST["item_discount_type_{$idx}"] = 1;
               }
            }

            //----------------------------------------------------------------------------------
            $newitemimg = "";
            if($_FILES["itemimage_{$idx}"]["name"] != "" &&
               $_FILES["itemimage_{$idx}"]["tmp_name"] != "" &&
               $_FILES["itemimage_{$idx}"]["error"] == 0 &&
               $_FILES["itemimage_{$idx}"]["size"] > 0)
            {
               $doc_type = substr($_FILES["itemimage_{$idx}"]["name"], strrpos($_FILES["itemimage_{$idx}"]["name"], ".") +1);
               if(strtoupper($doc_type) == "JPG" || strtoupper($doc_type) == "JPEG")
               {
                  $doc_hash = md5(microtime());
                  $doc_name = "{$_REQUEST["id"]}_{$doc_hash}.{$doc_type}";
                  $doc_dir  = "{$_SESSION["_CONF"]["conf_shopadmin_path"]}docs.offer/";
                  $ftres    = move_uploaded_file($_FILES["itemimage_{$idx}"]["tmp_name"], "{$doc_dir}{$doc_name}");
                  if($ftres)
                  {
                     resizeImage("{$doc_dir}{$doc_name}", 300, "", "{$doc_dir}{$doc_name}");
                     $newitemimg = $doc_name;
                  }
               }
            }

            //----------------------------------------------------------------------------------
            $newitemimgdesign = "";

            // Destino : /home/unibagqa/public_html/docs-order/3529_15f596b963560bf05a7feaf33dc46596.png Origen :/home/unibagqa/public_html/docs.tran/versiones/3529_15f596b963560bf05a7feaf33dc46596.png

            $_REQUEST["fab_design_imagehash"] = $_REQUEST["fab_design_imagehash_hidden"];
            // echo("fab_design_imagehash   :".$_REQUEST["fab_design_imagehash"]);
            // echo("fab_design_imagehash 2  :".$_REQUEST["fab_design_imagehash_hidden"]);

            // echo("marca de colores : ".$_REQUEST["fab_print_colordesc_10"]." marca front  1 : ".$_REQUEST["fab_print_colors_front_1"]." frente  10 ".$_REQUEST["fab_print_colors_front_10"]);
            
            $destino = $_SERVER['DOCUMENT_ROOT'] . "/docs.order/".$_REQUEST["fab_design_imagehash"];
            $origen  = $_SERVER['DOCUMENT_ROOT'] . "/docs.tran/versiones/".$_REQUEST["fab_design_imagehash"];
            $newitemimgdesign = $_REQUEST["fab_design_imagehash"];
            copy($origen, $destino);

            //----------------------------------------------------------------------------------
            if($existing_id)
            {



               $sql = " update orders_items
                        set
                        item_amount                = {$_REQUEST["item_amount_{$idx}"]},
                        item_sellprice_brutto      = {$sql_sellprice},
                        item_sellprice_taxes_perc  = {$sql_taxesperc},
                        item_sellprice_netto       = {$sql_sellnetto},
                        item_sellprice_taxes       = {$sql_taxes},
                        item_order_genamount       = {$genamount},
                        item_pos                   = {$poscounter},
                        item_desc                  = '{$_REQUEST["item_desc_{$idx}"]}',
                        item_compdesc              = '{$_REQUEST["item_compdesc_{$idx}"]}',
                        fab_printtype              = '{$_REQUEST["fab_printtype"]}',
                        fab_print_colors_front_1   = {$_REQUEST["fab_print_colors_front_1"]},
                        fab_print_colors_front_2   = {$_REQUEST["fab_print_colors_front_2"]},
                        fab_print_colors_front_3   = {$_REQUEST["fab_print_colors_front_3"]},
                        fab_print_colors_front_4   = {$_REQUEST["fab_print_colors_front_4"]},
                        fab_print_colors_front_5   = {$_REQUEST["fab_print_colors_front_5"]},
                        fab_print_colors_front_6   = {$_REQUEST["fab_print_colors_front_6"]},
                        fab_print_colors_front_7   = {$_REQUEST["fab_print_colors_front_7"]},
                        fab_print_colors_front_8   = {$_REQUEST["fab_print_colors_front_8"]},
                        fab_print_colors_front_9   = {$_REQUEST["fab_print_colors_front_9"]},
                        fab_print_colors_front_10  = {$_REQUEST["fab_print_colors_front_10"]},
                        fab_print_colors_back_1    = {$_REQUEST["fab_print_colors_back_1"]},
                        fab_print_colors_back_2    = {$_REQUEST["fab_print_colors_back_2"]},
                        fab_print_colors_back_3    = {$_REQUEST["fab_print_colors_back_3"]},
                        fab_print_colors_back_4    = {$_REQUEST["fab_print_colors_back_4"]},
                        fab_print_colors_back_5    = {$_REQUEST["fab_print_colors_back_5"]},
                        fab_print_colors_back_6    = {$_REQUEST["fab_print_colors_back_6"]},
                        fab_print_colors_back_7    = {$_REQUEST["fab_print_colors_back_7"]},
                        fab_print_colors_back_8    = {$_REQUEST["fab_print_colors_back_8"]},
                        fab_print_colors_back_9    = {$_REQUEST["fab_print_colors_back_9"]},
                        fab_print_colors_back_10    = {$_REQUEST["fab_print_colors_back_10"]},
                        fab_print_colordesc_1      = '{$_REQUEST["fab_print_colordesc_1"]}',
                        fab_print_colordesc_2      = '{$_REQUEST["fab_print_colordesc_2"]}',
                        fab_print_colordesc_3      = '{$_REQUEST["fab_print_colordesc_3"]}',
                        fab_print_colordesc_4      = '{$_REQUEST["fab_print_colordesc_4"]}',
                        fab_print_colordesc_5      = '{$_REQUEST["fab_print_colordesc_5"]}',
                        fab_print_colordesc_6      = '{$_REQUEST["fab_print_colordesc_6"]}',
                        fab_print_colordesc_7      = '{$_REQUEST["fab_print_colordesc_7"]}',
                        fab_print_colordesc_8      = '{$_REQUEST["fab_print_colordesc_8"]}',
                        fab_print_colordesc_9      = '{$_REQUEST["fab_print_colordesc_9"]}',
                        fab_print_colordesc_10      = '{$_REQUEST["fab_print_colordesc_10"]}',
                        fab_design_desc            = '{$_REQUEST["fab_design_desc"]}',
                        item_sellprice_trazado     = {$_REQUEST["item_sellprice_trazado_{$idx}"]},
                        item_sellprice_barcode     = {$_REQUEST["item_sellprice_barcode_{$idx}"]},
                        item_sellprice_barcodenumber = '{$_REQUEST["item_sellprice_barcodenumber_{$idx}"]}',
                        fab_print_width            = {$_REQUEST["fab_print_width"]},
                        fab_print_height           = {$_REQUEST["fab_print_height"]},
                        fab_manilla_length         = {$_REQUEST["fab_manilla_length"]},
                        fab_mat_fabric_color       = {$_REQUEST["fab_mat_fabric_color"]},
                        fab_mat_manilla_color      = {$_REQUEST["fab_mat_manilla_color"]},
                        fab_mat_gramms             = {$_REQUEST["fab_mat_gramms"]},
                        fab_mat_dispositivo        = '{$_REQUEST["fab_mat_dispositivo"]}'
                        where
                        req_id   = {$_REQUEST["id"]} and
                        item_id  = {$existing_id} and
                        item_pos = {$existing_pos}";
               $CON->no_result($sql);

               if($newitemimg != "")
               {
                  $sql = " update orders_items
                           set
                           item_img_hash = '{$newitemimg}'
                           where
                           req_id   = {$_REQUEST["id"]} and
                           item_id  = {$existing_id} and
                           item_pos = {$existing_pos}";
                  $CON->no_result($sql);      
               }

               if($newitemimgdesign != "")
               {
                  $sql = " update orders_items
                           set
                           fab_design_imagehash = '{$newitemimgdesign}'
                           where
                           req_id   = {$_REQUEST["id"]} and
                           item_id  = {$existing_id} and
                           item_pos = {$existing_pos}";
                  $CON->no_result($sql);      
               }

               recalcOrderItem($CON, $_REQUEST["id"], $existing_id, $poscounter, $itemfullupdate, "");

               //----------------------------------------------------------------------------------
               $_TABLENAME    = "orders_items";
               $_TABLENAMEHD  = "orders";
               $_COLPREFIX    = "req";
               $_AMOUNTFIELD  = "item_amount";

               //----------------------------------------------------------------------------------
               if(!$itemfullupdate)
               {
                  $_REQUEST["item_pcat_dsc_act_{$idx}"]     = (int)$_REQUEST["item_pcat_dsc_act_{$idx}"];
                  $_REQUEST["item_vol_act_{$idx}"]          = (int)$_REQUEST["item_vol_act_{$idx}"];
                  $_REQUEST["item_value_act_{$idx}"]        = (int)$_REQUEST["item_value_act_{$idx}"];

                  $_REQUEST["item_discount_{$idx}"]         = getPrice($_REQUEST["item_discount_{$idx}"],2);
                  $_REQUEST["item_discount_type_{$idx}"]    = (int)$_REQUEST["item_discount_type_{$idx}"];

                  for($y = 1; $y <= 4; $y++)
                     $_REQUEST["item_pcat_dsc_{$idx}_{$y}"] = getPrice($_REQUEST["item_pcat_dsc_{$idx}_{$y}"],2);

                  $sql = " update {$_TABLENAME}
                           set
                           item_discount        = {$_REQUEST["item_discount_{$idx}"]},
                           item_discount_type   = {$_REQUEST["item_discount_type_{$idx}"]},
                           item_pcat_dsc_act    = {$_REQUEST["item_pcat_dsc_act_{$idx}"]},
                           item_pcat_dsc1       = {$_REQUEST["item_pcat_dsc_{$idx}_1"]},
                           item_pcat_dsc2       = {$_REQUEST["item_pcat_dsc_{$idx}_2"]},
                           item_pcat_dsc3       = {$_REQUEST["item_pcat_dsc_{$idx}_3"]},
                           item_pcat_dsc4       = {$_REQUEST["item_pcat_dsc_{$idx}_4"]},
                           item_vol_act         = {$_REQUEST["item_vol_act_{$idx}"]},
                           item_value_act       = {$_REQUEST["item_value_act_{$idx}"]}
                           where
                           {$_COLPREFIX}_id     = {$_REQUEST["id"]} and
                           item_pos             = {$poscounter}";
                  $CON->no_result($sql);
               }
            }
            else
            {
               $sql = " insert into orders_items
                        (req_id, item_id, item_pos, item_amount, item_type, item_sellprice_brutto,
                         item_sellprice_taxes_perc, item_sellprice_netto, item_sellprice_taxes, item_desc,
                         item_order_genamount, item_compdesc)
                        VALUES
                        ({$_REQUEST["id"]}, {$sql_id}, {$poscounter}, {$_REQUEST["item_amount_{$idx}"]}, '{$sql_type}',
                         {$sql_sellprice}, {$sql_taxesperc}, {$sql_sellnetto}, {$sql_taxes}, '{$_REQUEST["item_desc_{$idx}"]}',
                         {$genamount}, '{$_REQUEST["item_compdesc_{$idx}"]}')";
               $CON->no_result($sql);

               recalcOrderItem($CON, $_REQUEST["id"], $sql_id, $poscounter, true, "");
            }

            $poscounter++;
         }
         else
         {
            if($existing_id)
            {
               $sql = " delete from orders_items
                        where
                        req_id   = {$_REQUEST["id"]} and
                        item_id  = {$existing_id} and
                        item_pos = {$existing_pos}";
               $CON->no_result($sql);
            }

            if($_REQUEST["item_id_{$idx}"] != "" && $_REQUEST["item_amount_{$idx}"] > 0.00 && $_REQUEST["item_amount_{$idx}"] > (float)$_REQUEST["stkdisponosave_{$idx}"])
            {
               $sql = " select *
                        from item
                        where
                        id = {$_REQUEST["item_id_{$idx}"]}";
               $titem = $CON->select($sql);
               $titem = $titem[0];

               $titem["item_title"] = str_replace("'", "", $titem["item_title"]);

               $alertdesc = "EL PRODUCTO \'{$titem["item_number_prod"]} - {$titem["item_title"]}\' NO TIENE SUFICIENTE STOCK. ";
               ?>
               <script language="JavaScript">
                  alert('<?=$alertdesc?>');
               </script>
               <?
            }
         }
      }
   }

   //----------------------------------------------------------------------------------
   if($_REQUEST["delposimg"] != "")
   {
      $delposimgarr = explode("-", $_REQUEST["delposimg"]);

      $sql = " update orders_items
               set
               item_img_hash = ''
               where
               req_id   = {$_REQUEST["id"]} and
               item_id  = {$delposimgarr[0]} and
               item_pos = {$delposimgarr[1]}";
      $CON->no_result($sql);
   }

   //----------------------------------------------------------------------------------
   if($_REQUEST["deldesignimg"] != "")
   {
      $delposimgarr = explode("-", $_REQUEST["deldesignimg"]);

      $sql = " update orders_items
               set
               fab_design_imagehash = ''
               where
               req_id   = {$_REQUEST["id"]} and
               item_id  = {$delposimgarr[0]} and
               item_pos = {$delposimgarr[1]}";
      $CON->no_result($sql);
   }

   //----------------------------------------------------------------------------------
   $_REQUEST["dlv_weightprice_netto"]     = getPrice($_REQUEST["dlv_weightprice_netto"]);
   $_REQUEST["req_trazlogoprice_netto"]   = getPrice($_REQUEST["req_trazlogoprice_netto"]);
   
   $sql = " update orders
            set
            req_weightprice_netto   = {$_REQUEST["dlv_weightprice_netto"]},
            req_trazlogoprice_netto = {$_REQUEST["req_trazlogoprice_netto"]}
            where
            id = {$_REQUEST["id"]}";
   $CON->no_result($sql);

   //----------------------------------------------------------------------------------
   $sql = " select count(*) 'cc'
            from orders t1
            INNER JOIN orders t2 ON (t1.req_status > 0 and t2.req_status > 0 and t1.req_number = t2.req_number)
            where
            t1.id = {$_REQUEST["id"]}";
   $shpdoccheck = $CON->select($sql);
   if((int)$shpdoccheck[0]["cc"] > 1)
      $_SESSION["JSEXEC"] .= ";alert('EL NUMERO DE YA EXISTE');";

   recalcOrder($CON, $_REQUEST["id"]);

   //----------------------------------------------------------------------------------
   if($final)
   {
      //

      if((int)$headdata["req_isfabricate"])
      {
         $pdflink = "{$_SESSION["_CONF"]["conf_shopadmin_url"]}libs/modules/orders/data.pdf.php?id={$_REQUEST["id"]}";
         $pdfdata = file_get_contents($pdflink);

         $hash       = md5(microtime());
         $filedir    = "{$_SESSION["_CONF"]["conf_shopadmin_path"]}docs.order/";
         $doctype    = "ncorder";
         $filename   = "{$filedir}{$_REQUEST["id"]}-{$doctype}-{$hash}.pdf";
         file_put_contents($filename, $pdfdata);

          //----------------------------------------------------------------------------------
         $sql = " update orders
                  set
                  req_hash   = '{$_REQUEST["id"]}-{$doctype}-{$hash}.pdf'
                  where
                  id          = {$_REQUEST["id"]}";
         $CON->no_result($sql);
      }
      else
      {
         doc_createOrder($CON, $_REQUEST["id"]);
      }
   }

}

//----------------------------------------------------------------------------------
if($_REQUEST["subexec"] == "send")
{
   foreach($_REQUEST["xcco"] AS $xccouid)
   {
      $sql = " select *
               from user
               where
               id = {$xccouid}";
      $ccouser = $CON->select($sql);
      $ccouser = $ccouser[0];

      $temp["NAME"] = $ccouser["user_firstname"]." ".$ccouser["user_lastname"];
      $temp["ADDR"] = $ccouser["user_mail"];
      $_CCOADDR[]   = $temp;
   }

   $currtme = time();

   $pdflink = "{$_SESSION["_CONF"]["conf_shopadmin_url"]}libs/modules/orders/data.pdf.php?id={$_REQUEST["id"]}";
   $pdfdata = file_get_contents($pdflink);

   $hash       = md5(microtime());
   $filedir    = "{$_SESSION["_CONF"]["conf_shopadmin_path"]}docs.print/";
   $doctype    = "ncorder";
   $filename   = "{$filedir}{$_REQUEST["id"]}-{$doctype}-{$hash}.pdf";

   //----------------------------------------------------------------------------------
   if($handle = opendir($filedir))
   {
      while (false !== ($file = readdir($handle)))
         if ($file != "." && $file != ".." && strpos($file,"{$_REQUEST["id"]}-{$doctype}-") !== false)
            unlink("{$filedir}{$file}");
      closedir($handle);
   }

   file_put_contents($filename, $pdfdata);

   //----------------------------------------------------------------------------------
   $sql = " select *
            from orders
            where
            id = {$_REQUEST["id"]}";
   $headdata = $CON->select($sql);
   $headdata = $headdata[0];
   
   $temp["NAME"]     = "{$headdata["req_number"]}.pdf";
   $temp["FILE"]     = $filename;
   $attachfiles[0]   = $temp;

   $text    = '<html>
               <head><style type="text/css">body{font-family:Arial;font-size:12px;}</style></head>
               <body style="margin:10px" class="page">'.$_REQUEST["msg_body"].'</body></html>';

   $sentmails = sendExternalMail($_REQUEST["msg_header"],
                                 $text,
                                 $_REQUEST["msg_toaddr"],
                                 $_REQUEST["msg_toname"],
                                 "",
                                 "",
                                 $attachfiles);
   if($sentmails <= 0)
      $savemsg = getSaveMessage(false);
   else
      $savemsg = getSaveMessage(true);
}

//----------------------------------------------------------------------------------
$sql = " select t1.*, t2.cust_name, t2.cust_email, t3.company_short, t4.shop_name, t1.req_cust_id, t2.cust_notes, t7.pay_title,
                t5.user_firstname 'upd_firstname', t5.user_lastname 'upd_lastname',
                t6.user_firstname 'crt_firstname', t6.user_lastname 'crt_lastname',
                t8.user_firstname 'seller_firstname', t8.user_lastname 'seller_lastname',
                t9.user_firstname 'cashing_firstname', t9.user_lastname 'cashing_lastname',
                t10.trans_name
         from orders t1
         LEFT OUTER JOIN customer t2         ON t1.req_cust_id          = t2.id
         LEFT OUTER JOIN company_data t3     ON t1.req_company_id       = t3.id
         LEFT OUTER JOIN company_shops t4    ON t1.req_shop_id          = t4.id
         LEFT OUTER JOIN user t5             ON t1.req_updusr           = t5.id
         LEFT OUTER JOIN user t6             ON t1.req_crtusr           = t6.id
         LEFT OUTER JOIN payments t7         ON t1.req_paymentid        = t7.id
         LEFT OUTER JOIN user t8             ON t1.req_userid_seller    = t8.id
         LEFT OUTER JOIN user t9             ON t1.req_userid_cashing   = t9.id
         LEFT OUTER JOIN transports t10      ON t1.req_transportid      = t10.id
         where
         t1.id = {$_REQUEST["id"]}";
$headdata = $CON->select($sql);
$headdata = $headdata[0];

//----------------------------------------------------------------------------------
$sql = " select *
         from user
         where
         id = {$_SESSION["user_id"]}";
$userdata = $CON->select($sql);
$userdata = $userdata[0];

if($_REQUEST["id"] != "" && $userdata["user_orderlimit_perm"] && $_SESSION["user_id"] != $headdata["req_crtusr"])
{  ?>
   <script language="JavaScript">
      location.href = 'index.php?exec=logout';
   </script>
   <?
   exit;
}
//----------------------------------------------------------------------------------
$sql = " select t1.*, t2.country_name, t3.name, t4.nombre, t5.pro_name
         from customer t1
         LEFT OUTER JOIN country t2 ON t1.cust_countryid = t2.id
         LEFT OUTER JOIN regions t3 ON t1.cust_regionid  = t3.id
         LEFT OUTER JOIN comunas t4 ON t1.cust_comunaid  = t4.id
         LEFT OUTER JOIN provincias t5 ON t1.cust_provinciaid  = t5.id
         where
         t1.id = {$headdata["req_cust_id"]}";
$customer = $CON->select($sql);
$customer = $customer[0];

//----------------------------------------------------------------------------------
if($headdata["req_status"] >= 2)
{
   $sql = " select t1.*, t2.country_name, t3.name, t4.nombre
            from customer_deliveryaddr t1
            LEFT OUTER JOIN country t2 ON t1.delivery_countryid = t2.id
            LEFT OUTER JOIN regions t3 ON t1.delivery_regionid  = t3.id
            LEFT OUTER JOIN comunas t4 ON t1.delivery_comunaid  = t4.id
            where
            t1.id = {$headdata["req_cust_delivid"]}
            order by t1.id asc";
   $deliveryaddr = $CON->select($sql);
   $deliveryaddr = $deliveryaddr[0];
}
else
{
   $sql = " select t1.*, t2.country_name, t3.name, t4.nombre
            from customer_deliveryaddr t1
            LEFT OUTER JOIN country t2 ON t1.delivery_countryid = t2.id
            LEFT OUTER JOIN regions t3 ON t1.delivery_regionid  = t3.id
            LEFT OUTER JOIN comunas t4 ON t1.delivery_comunaid  = t4.id
            where
            t1.cust_id = {$headdata["req_cust_id"]} and
            t1.delivery_status = 1
            order by t1.id asc";
   $deliveryaddrs = $CON->select($sql);
}

//----------------------------------------------------------------------------------
$payments   = getPayments($CON, $headdata["req_shop_id"]);
$sellers    = getSellers($CON);
$posdata    = getOrderPos($CON, $_REQUEST["id"], $_REQUEST["setPosOrder"]);
$transports = getTransports($CON);

//------------------------------------------------------------------------------------------------------------------------------------


//----------------------------------------------------------------------------------------------------------------------------------------
   $sql = "select * from item where item_number_prod = '{$posdata[0]["item_number_prod"]}'";
   $ite = $CON->select($sql);
   $ite = $ite[0];

   $sql = " select count(*) as contador from orders_comments_item_vals where orders_id = {$_REQUEST["id"]} and orders_item_id = {$ite["id"]}";
   $find = $CON->select($sql);

   if((int)$find[0]["contador"] == 0)
   {
      $sql = " select *
               from tran_comments_item_vals
               where item_id = {$ite["id"]}";
   }
   else
   {
      $sql = " select orders_id
                    , orders_item_id as item_id
                    , orders_com_id as com_id
                    , orders_val_id as val_id
               from orders_comments_item_vals
               where orders_id = {$_REQUEST["id"]} and orders_item_id = {$ite["id"]}";
   }
   $comvals = $CON->select($sql);
   foreach($comvals AS $comval)
     $_COMVALS[$comval["com_id"]] = $comval["val_id"];

     $sql = " select t2.id, t2.cat_title
            from item_productcats t1, productcats t2
            where
            t1.cat_id      = t2.id and 
            t1.item_id     = {$ite["id"]} and
            t2.cat_status  = 1";
     $selitemcatid = $CON->select($sql);
     $selitemcatidstr = $selitemcatid[0]["id"];
     $selitemcatname  = $selitemcatid[0]["cat_title"];

     $sql = " select *
            from productcats
            where
            id = {$selitemcatid[0]["id"]}";
     $pcatdata = $CON->select($sql);
     $pcatdata = $pcatdata[0];

     $sql = " select t1.com_name, t3.*
               from tran_comments t1
               INNER JOIN tran_comments_cats t2 ON t1.id = t2.com_id
               INNER JOIN tran_comments_vals t3 ON t1.id = t3.add_com_id
               where
               t1.com_status  > 0 and
               t2.cat_id      = {$pcatdata["id"]} and
               t3.add_status  > 0 and 
               t1.com_atrib_cc = 1
               order by t1.com_name, t3.add_name";
      
      $trancoms = $CON->select($sql);

      foreach($trancoms AS $trancom)
      {
         $_TRANSCOM[$trancom["add_com_id"]]["NAME"] = $trancom["com_name"];
         $_TRANSCOM[$trancom["add_com_id"]]["OPTS"][$trancom["id"]] = $trancom["add_name"];
      }


//----------------------------------------------------------------------------------
$rowcount = 0;
if($posdata != false && count($posdata))
   $rowcount = count($posdata);

if($rowcount <= 6)
   $rowcount = 10;
else
   $rowcount += 5;

if($headdata["req_status"] >= 2)
{
   $rdlo       = " readonly ";
   $dabl       = " disabled ";
   $rowcount   = count($posdata);

   if(!$posdata)
      $rowcount = 0;
}

//----------------------------------------------------------------------------------
if((int)$_SESSION["user_pricesell_perm"] || (int)$_REQUEST["user_pricesell_perm"])
   $hasprcsellperm = true;
else
   $hasprcsellperm = false;


//----------------------------------------------------------------------------------
$custselarr = Array();
   
$custname = str_replace(",","", str_replace("'","", str_replace('"',"", trim($headdata["cust_name"]))));
$custmail = str_replace(",","", str_replace("'","", str_replace('"',"", trim($headdata["cust_email"]))));
if($custmail != "")
{
   $temp["NAME"] = $custname;
   $temp["MAIL"] = $custmail;

   array_push($custselarr, $temp);
}
//----------------------------------------------------------------------------------
$sql = " select add_email, add_firstname, add_lastname
         from customer_contacts
         where
         add_cust_id = {$headdata["req_cust_id"]}
         order by add_pos asc";
$suppcontacts = $CON->select($sql);

//----------------------------------------------------------------------------------
for($x = 0; $x < count($suppcontacts) && $suppcontacts != false; $x++)
{
   $custname = str_replace(",","", str_replace("'","", str_replace('"',"", trim($suppcontacts[$x]["add_firstname"]." ".$suppcontacts[$x]["add_lastname"]))));
   $custmail = str_replace(",","", str_replace("'","", str_replace('"',"", trim($suppcontacts[$x]["add_email"]))));

   if($custmail != "")
   {
      $temp["NAME"] = $custname;
      $temp["MAIL"] = $custmail;

      array_push($custselarr, $temp);
   }
}

//----------------------------------------------------------------------------------
if($_SESSION["xorders"]["fullcust"] == "1")
   $cdatastyle = 'style="border-top-width:3px;border-top-style:solid"';

$proms = getActivePromotions($CON, $headdata["req_shop_id"]);

//----------------------------------------------------------------------------------
if((int)$_REQUEST["senddesignmail"])
{
   $currtme = time() + 86400;
   $sql = " update orders
            set
            req_design_blocked_uid = 0,
            req_designupload_act   = 1,
            req_designupload_alertdate = {$currtme}
            where
            id = {$_REQUEST["id"]}";
   $CON->no_result($sql);
   
   generateDesignMail($CON, $headdata, $posdata);
}

if((int)$_REQUEST["sendprodmail"])
   generateDesignFabricationMail($CON, $headdata, $posdata);
/* ------------------------------------------------------ */
/* CARGAR PIE DE IMPRENTA */
$sql = "select * from parametros where tabla = 'PIEIMPRENTA'";
$pieimprenta = $CON->select($sql);
/* ------------------------------------------------------ */
/* CARGAR CAJA POR PALLET */
$sql = "select * from parametros where tabla = 'CAJAXPALLET'";
$cajasporpallets = $CON->select($sql);
/* ------------------------------------------------------ */
/* CARGAR  medidas por caja */
$sql = "select id as codigo, med_name as descripcion
            from prod_medidas
         where med_status > 0";
$medidasporcajas = $CON->select($sql);
/* ------------------------------------------------------ */
/* CARGAR CUBICAJE */
$sql = "select * from parametros where tabla = 'CUBICAJE'";
$cubicajes = $CON->select($sql);
/* ------------------------------------------------------ */
/* CARGAR DISPOTIVOS */
$sql = "select * from parametros where tabla = 'DISPOSITIVO'";
$dispositivos = $CON->select($sql);
/* ------------------------------------------------------ */
/* CARGAR CODIGO DE BARRAS */
$sql = "select * from parametros where tabla = 'BARRA' order by codigo";
$codigobarras = $CON->select($sql);
/*---------------------------------------------------------------*/
$sql = " select id, user_firstname, user_lastname, user_mail
         from user
         where
         user_status > 0 and
         user_mail like '%@%'
         order by user_firstname, user_lastname";
$ccousers = $CON->select($sql);
/*---------------------------------------------------------------*/
$sql = "select td.id
              ,td.doc_crtdat
              ,td.doc_name
              ,td.doc_file
              ,td.doc_tran_id
              ,pdi.pro_dis_items_descripcion
              ,pdi.pro_dis_items_materialidad
              ,pdi.pro_dis_items_color1
              ,pdi.pro_dis_items_color2
              ,pdi.pro_dis_items_color3
              ,pdi.pro_dis_items_color4
              ,pdi.pro_dis_items_color5
              ,pdi.pro_dis_items_color6
              ,pdi.pro_dis_items_color7
              ,pdi.pro_dis_items_color8
              ,pdi.pro_dis_items_color9
              ,pdi.pro_dis_items_color10
              ,pdi.pro_dis_items_color_manilla
              ,pdi.pro_dis_items_color_tela
              ,pdi.pro_dis_items_codigo_barra
         	  ,pdi.pro_dis_items_tipo_impresion
              ,pdi.pro_dis_items_print_alto
              ,pdi.pro_dis_items_print_ancho
              ,pdi.pro_dis_items_frente1
              ,pdi.pro_dis_items_frente2
              ,pdi.pro_dis_items_frente3
              ,pdi.pro_dis_items_frente4
              ,pdi.pro_dis_items_frente5
              ,pdi.pro_dis_items_frente6
              ,pdi.pro_dis_items_frente7
              ,pdi.pro_dis_items_frente8
              ,pdi.pro_dis_items_frente9
              ,pdi.pro_dis_items_frente10
              ,pdi.pro_dis_items_dorso1
              ,pdi.pro_dis_items_dorso2
              ,pdi.pro_dis_items_dorso3
              ,pdi.pro_dis_items_dorso4
              ,pdi.pro_dis_items_dorso5
              ,pdi.pro_dis_items_dorso6
              ,pdi.pro_dis_items_dorso7
              ,pdi.pro_dis_items_dorso8
              ,pdi.pro_dis_items_dorso9
              ,pdi.pro_dis_items_dorso10              
         from pro_dis pd
            inner join pro_dis_items pdi on pd.id = pdi.pro_dis_items_pro_id and pdi.pro_dis_items_status = 3
            inner join pro_dis_detalle pdd on pdd.pro_dis_detalle_items_id = pdi.pro_dis_items_id /* and pro_dis_detalle_status = 3 */
            inner join tran_docs td on td.doc_tran_id = pdd.pro_dis_detalle_id and td.doc_tran_type = 'versiones'              
         where pd.pro_dis_custid = {$headdata["req_cust_id"]} and pdi.pro_dis_items_materialidad = '{$posdata[0]["fab_type"]}'";
$versiones = $CON->select($sql);
// echo($sql);

/*---------------------------------------------------------------*/
$sql = "select td.id
            ,td.doc_crtdat
            ,td.doc_name
            ,td.doc_file
            ,td.doc_tran_id
            ,pdi.pro_dis_items_descripcion
            ,pdi.pro_dis_items_materialidad
            ,pdi.pro_dis_items_color1
            ,pdi.pro_dis_items_color2
            ,pdi.pro_dis_items_color3
            ,pdi.pro_dis_items_color4
            ,pdi.pro_dis_items_color5
            ,pdi.pro_dis_items_color6
            ,pdi.pro_dis_items_color7
            ,pdi.pro_dis_items_color8
            ,pdi.pro_dis_items_color9
            ,pdi.pro_dis_items_color10
            ,pdi.pro_dis_items_color_manilla
            ,pdi.pro_dis_items_color_tela
            ,pdi.pro_dis_items_codigo_barra
        	   ,pdi.pro_dis_items_tipo_impresion
            ,pdi.pro_dis_items_print_alto
            ,pdi.pro_dis_items_print_ancho
            ,pdi.pro_dis_items_frente1
            ,pdi.pro_dis_items_frente2
            ,pdi.pro_dis_items_frente3
            ,pdi.pro_dis_items_frente4
            ,pdi.pro_dis_items_frente5
            ,pdi.pro_dis_items_frente6
            ,pdi.pro_dis_items_frente7
            ,pdi.pro_dis_items_frente8
            ,pdi.pro_dis_items_frente9
            ,pdi.pro_dis_items_frente10
            ,pdi.pro_dis_items_dorso1
            ,pdi.pro_dis_items_dorso2
            ,pdi.pro_dis_items_dorso3
            ,pdi.pro_dis_items_dorso4
            ,pdi.pro_dis_items_dorso5
            ,pdi.pro_dis_items_dorso6
            ,pdi.pro_dis_items_dorso7
            ,pdi.pro_dis_items_dorso8
            ,pdi.pro_dis_items_dorso9
            ,pdi.pro_dis_items_dorso10              
         from pro_dis pd
            inner join pro_dis_items pdi on pd.id = pdi.pro_dis_items_pro_id and pdi.pro_dis_items_status = 3
            inner join pro_dis_detalle pdd on pdd.pro_dis_detalle_items_id = pdi.pro_dis_items_id /* and pro_dis_detalle_status = 3 */
            inner join tran_docs td on td.doc_tran_id = pdd.pro_dis_detalle_id and td.doc_tran_type = 'versiones'
         where pd.pro_dis_custid in(124,1328) and pdi.pro_dis_items_materialidad = '{$posdata[0]["fab_type"]}' ";
$version_generico = $CON->select($sql);
/*---------------------------------------------------------------*/
?>
<script language="JavaScript">
   document.all.idx_status_msg.innerHTML = "<?=$savemsg?>";

   function detectEvent (event, rowcount, reqid)
   {
      var xurl = './libs/modules/orders/searchitem.fancy.php?rowcount=' +rowcount + '&reqid=' +reqid;
      var keyCode = ('which' in event) ? event.which : event.keyCode;
      if(keyCode == 112)
         showFancybox(xurl, 'iframe', 1000, 450, 'auto');
   }

   function showStockAct(idx, itemid)
   {
      var dataString = "itemid="+itemid+"&req_shop_id=<?=$headdata["req_shop_id"]?>";
      $.ajax({
         type:       "POST",
         cache:      false,
         url:        "/libs/modules/orders_offers/jquery.stockact.php",
         data:       dataString,
         dataType:   "html",
         success: function(res)
         {
            res = res.split('#!#!#!#!');
            $("#stockact_"+idx).html(res[0]);
            $("#stocktrans_"+idx).html(res[1]);
            $("#stockcomp_"+idx).html(res[2]);
            $("#stockres_"+idx).html(res[3]);

            var dspstr = res[4] + ' ';

            dspstr = dspstr + '<input type="hidden" name="stkdisponosave_' +idx +'" id="stkdisponosave_' +idx +'" value="' +res[4].replace('.','') +'">';
            $("#stockdisp_"+idx).html(dspstr);
         }
      });
   }

   function submit()
   {
      document.form_reqpos.submit()
   }
</script>
<?
//----------------------------------------------------------------------------------
$custcredit = checkCustomerCreditLimit($CON, $headdata["req_cust_id"], 0, $headdata["req_company_id"]);
if($custcredit["BLOCKED"])
{  ?>
   <table border="0" cellpadding="0" cellspacing="0" width="1020">
   <tr>
      <td style="border-radius:5px;border:3px solid red">
         <table border="0" cellpadding="3" cellspacing="0" width="100%">
         <colgroup>
            <col width="120">
            <col width="190">
            <col width="120">
            <col width="190">
            <col width="120">
            <col>
         </colgroup>
         <tr>
            <td class="content_rowl" style="background-color:#FFDBDB">Limite Credito</td>
            <td class="content_row">$ <?=printPrice($custcredit["LIMIT"])?></td>
            <td class="content_rowl" style="background-color:#FFDBDB">Deuda Cliente</td>
            <td class="content_row">$ <?=printPrice($custcredit["AMOUNT"])?></td>
            <td class="content_rowl" style="background-color:#FFDBDB">Superado</td>
            <td class="content_row">$ <?=printPrice($custcredit["DIFF"])?></td>
         </tr>
         </table>
      </td>
   </tr>
   </table>
   <br>
   <?
}
?>
<style type="text/css"><!-- @import url(./libs/jscripts/datepicker/datepicker.css); //--></style>
<script language="JavaScript" src="./libs/jscripts/datepicker/datepicker.js"></script>
<script src="./libs/jscripts/classyedit/jquery.classyedit.js"></script>
<link rel="stylesheet" type="text/css" href="./libs/jscripts/classyedit/jquery.classyedit.css" />
<form action="index.php" method="post" name="form_reqpos" id="form_reqpos" enctype="multipart/form-data"
onsubmit="<?
if($rdlo != "")
   echo "return false";
else
   echo "return checkform(new Array(this.req_paymentid,this.req_userid_seller,this.req_number))"?>">
<input type="hidden" name="exec" value="edit">
<input type="hidden" name="subexec" value="save">
<input type="hidden" name="id" value="<?=$_REQUEST["id"]?>">
<input type="hidden" name="mid" value="<?=$_REQUEST["mid"]?>">
<input type="hidden" name="req_status" value="1">
<input type="hidden" name="setPosOrder" value="">
<input type="hidden" name="showDiscounts" value="<?=$_REQUEST["showDiscounts"]?>">
<input type="hidden" name="user_pricesell_perm" value="<?=$_REQUEST["user_pricesell_perm"]?>">
<input type="hidden" name="printxls" value="0">
<input type="hidden" name="delnvrevx" value="">
<input type="hidden" name="delposimg" value="">
<input type="hidden" name="deldesignimg" value="">
<input type="hidden" name="senddesignmail" value="">
<input type="hidden" name="autoopensendmail" value="">
<input type="hidden" name="autoopenpdf" value="">
<input type="hidden" name="openfancymode" value="">
<input type="hidden" name="item_number_prod" value="<?=$posdata[0]["item_number_prod"]?>">

<table border="0" cellpadding="0" cellspacing="0" width="1080">
<tr>
   <td class="content_row_clear" valign="top">
      <?=Nifty_printH("box1", "1020",0)?>
      <table border="0" class="content_table" cellpadding="3" cellspacing="0" width="100%" id="ifx_tblheader">
      <colgroup>
         <col width="130">
         <col width="360">
         <col width="130">
         <col>
      </colgroup>
      <tr>
         <td class="content_tbl_header" colspan="2" style="padding:0px;padding-left:3px">
            <img src="./images/menu/icons/arrow-move.png" height="14" style="cursor:pointer;vertical-align:bottom"
            onclick="var x=0;var brows = $('#ifx_tblheader > tbody');
                     brows.each(function(){x++;if(x > 1)
                     {if($(this).is(':hidden')) $(this).show(); else $(this).hide();}});">
            Datos b�sicos
         </td>
         <td class="content_tbl_header" colspan="2" align="right" style="padding:0px;padding-right:1px">
            <input type="button" class="button" value="Clonar" style="width:100px"
            onclick="if(askDel('')) { location.href = '/index.php?mid=<?=$_REQUEST["mid"]?>&exec=edit&subcatexec=basic&id=<?=$_REQUEST["id"]?>&clonexec=1'; }">
         </td>
      </tr>
      <tr>
         <td class="content_rowl">N�mero</td>
         <td class="content_row">
            <table border="0" cellpadding="0" cellspacing="0">
            <tr>
               <td class="content_row_clear" width="120">
                  <input type="text" class="text" style="width:110px" name="req_number" id="req_number" <?=$rdlo?>
                  value="<?=$headdata["req_number"]?>" onfocus="markfield(this,0)" onblur="markfield(this,1)">
               </td>
               <td class="content_row_clear" width="120">
                  <nobr>
                  OC
                  <input type="text" class="text" style="width:90px" name="req_oc_number" id="req_oc_number" <?=$rdlo?>
                  value="<?=$headdata["req_oc_number"]?>" onfocus="markfield(this,0)" onblur="markfield(this,1)">
                  </nobr>
               </td>
               <td class="content_row_clear">
                  <nobr>
                  <input type="text" style="width:80px" id="req_oc_dat" name="req_oc_dat" <?=$rdlo?>
                  class="text <? if($rdlo == "") echo "format-d-m-y divider-dot highlight-days-67 no-locale no-transparency"?>"
                  onfocus="markfield(this,0)" onblur="markfield(this,1)"
                  value="<? if($headdata["req_oc_dat"] > 0) echo date('d.m.Y', $headdata["req_oc_dat"])?>">
                  </nobr>
               </td>
            </tr>
            </table>
         </td>
         <td class="content_rowl">IVA</td>
         <td class="content_row">
            <table border="0" cellpadding="0" cellspacing="0" width="100%">
            <tr>
               <td class="content_row_clear" width="120">
                  <select class="text" style="width:120px;background-color:<? if((int)$headdata["req_taxes"]) echo "#BFE6C3;"; else echo "#FFD6D8"?>">
                     <?
                     if((int)$headdata["req_taxes"])
                        echo '<option value="">CON IVA</option>';
                     else
                        echo '<option value="">SIN IVA</option>';
                     ?>
                  </select>
               </td>
               <td class="content_row_clear" align="right" style="padding-right:3px">
                  <?
                  if((int)$headdata["req_isinvcbrutto"])
                     echo 'MONTO BRUTO';
                  else
                     echo 'MONTO NETO';
                  ?>
               </td>
            </tr>
            </table> 
         </td>
      </tr>
      <tr>
         <td class="content_rowl">Empresa</td>
         <td class="content_row"><?=$headdata["company_short"]?></td>
         <td class="content_rowl">Sucursal</td>
         <td class="content_row"><?=$headdata["shop_name"]?></td>
      </tr>
      <tbody>
      <tr>
         <td class="content_rowl" <?=$cdatastyle?>>Cliente</td>
         <td class="content_row" <?=$cdatastyle?>>
            <a href="javascript:void(0)" style="text-decoration:none;color:black"
            onclick="location.href='index.php?mid=<?=$_REQUEST["mid"]?>&exec=edit&subexec=edit&id=<?=$headdata["id"]?>&showfullcust=<?
            if($_SESSION["xorders"]["fullcust"] == "") echo "1"; else echo "0"?>'"> <b><?=$customer["cust_name"]?></b></a></td>
         <td class="content_rowl" <?=$cdatastyle?>><?=$_LANG["MODULE"]["ORDER"][13]?></td>
         <td class="content_row" <?=$cdatastyle?>><b><?=$customer["cust_rut"]?></b>&nbsp;</td>
      </tr>
      <tr <? if($_SESSION["xorders"]["fullcust"] == "") echo "style='display:none'"?>>
         <td class="content_rowl">Direcci�n</td>
         <td class="content_row"><?=$customer["cust_street"]?>&nbsp;</td>
         <td class="content_rowl">Tel�fono</td>
         <td class="content_row"><?if($customer["cust_phone"] != "") echo $customer["cust_phone"];?>&nbsp;</td>
      </tr>
      <tr <? if($_SESSION["xorders"]["fullcust"] == "") echo "style='display:none'"?>>
         <td class="content_rowl">Regi�n</td>
         <td class="content_row"><?=$customer["name"]?>&nbsp;</td>
         <td class="content_rowl">Whatsapp</td>
         <td class="content_row"><?=$customer["cust_fax"]?>&nbsp;</td>
      </tr>
      <tr <? if($_SESSION["xorders"]["fullcust"] == "") echo "style='display:none'"?>>
         <td class="content_rowl">Comuna</td>
         <td class="content_row"><?=$customer["pro_name"]?> - <?=$customer["nombre"]?>&nbsp;</td>
         <td class="content_rowl"><?=$_LANG["MODULE"]["ORDER"][12]?></td>
         <td class="content_row"><?=$customer["cust_email"]?>&nbsp;</td>
      </tr>
      <tr <? if($_SESSION["xorders"]["fullcust"] == "") echo "style='display:none'"?>>
         <td class="content_rowl">Pa�s</td>
         <td class="content_row"><?=$customer["country_name"]?>&nbsp;</td>
         <td class="content_rowl">Opciones</td>
         <td class="content_row">
            <table border="0" cellpadding="0" cellspacing="0">
            <tr>
               <td class="content_row_clear">
                  <?
                  printButton("Cambiar datos del cliente", "postnav", "index.php?mid=628&exec=edit&id={$customer["id"]}&registerback={$_REQUEST["mid"]}-{$_REQUEST["id"]}", "", "disk-black", 180);
                  ?>
               </td>
               <td class="content_row_clear" style="padding-left:5px">
                  <?
                  printGooglemapsButton($customer["cust_street"], $customer["name"], $customer["country_name"]);
                  ?>
               </td>
            </tr>
            </table>
         </td>
      </tr>
      <tr style="display:none">
         <td class="content_rowl">Reserva</td>
         <td class="content_row">
            <input type="radio" name="req_isreserva" value="0" <?if(!(int)$headdata["req_isreserva"]) echo "checked"?>>No</b>
            <input type="radio" name="req_isreserva" value="1" <?if((int)$headdata["req_isreserva"]) echo "checked"?>>Si</b>
         </td>
         <td class="content_rowl" <?=$cdatastyle?>>Cliente provisorio</td>
         <td class="content_row" <?=$cdatastyle?>>
            <input type="text" class="text" style="width:350px" name="req_custnameprov" <?=$rdlo?>
            onfocus="markfield(this,0)" onblur="markfield(this,1)" value="<?=$headdata["req_custnameprov"]?>">
         </td>
      </tr>
      <tr>
         <td class="content_rowl">Forma de pago *</td>
         <td class="content_row">
            <select class="text" style="width:350px" name="req_paymentid" id="req_paymentid"
            onmousedown="markfield(this,0)" onblur="markfield(this,1)">
               <?
               if($dabl == "")
               {  ?>
                  <option value="">&lt; <?=$_LANG["FORM"]["OPTION"][0]?> &gt;</option>
                  <?
                  foreach($payments as $payment)
                  {  ?>
                     <option value="<?=$payment["id"]?>"
                     <? if($payment["id"] == $headdata["req_paymentid"]) echo "selected"?>><?=$payment["pay_title"]?></option>
                     <?
                  }
               }
               else
               {  ?>
                  <option value="<?=$headdata["req_paymentid"]?>"><?=$headdata["pay_title"]?></option>
                  <?
               }
               ?>
            </select>
         </td>
         <td class="content_rowl" valign="top">Vendedor *</td>
         <td class="content_row" valign="top">
            <select class="text" style="width:350px" name="req_userid_seller" id="req_userid_seller"
            onmousedown="markfield(this,0)" onblur="markfield(this,1)">
               <?
               if($dabl == "")
               {  ?>
                  <option value="">&lt; <?=$_LANG["FORM"]["OPTION"][0]?> &gt;</option>
                  <?
                  foreach($sellers as $seller)
                  {  ?>
                     <option value="<?=$seller["id"]?>"
                     <? if($seller["id"] == $headdata["req_userid_seller"]) echo "selected"?>><?=$seller["user_firstname"]?> <?=$seller["user_lastname"]?></option>
                     <?
                  }
               }
               else
               {  ?>
                  <option value="<?=$headdata["req_userid_seller"]?>"><?=$headdata["seller_firstname"]?> <?=$headdata["seller_lastname"]?></option>
                  <?
               }
               ?>
            </select>
         </td>
      </tr>
      <tr>
      </tr>
      <tr>
         <td class="content_rowl">Transportista</td>
         <td class="content_row">
            <select class="text" style="width:350px" name="req_transportid" id="req_transportid"
            onmousedown="markfield(this,0)" onblur="markfield(this,1)">
               <?
               if($dabl == "")
               {  ?>
                  <option value="">&lt; <?=$_LANG["FORM"]["OPTION"][0]?> &gt;</option>
                  <?
                  foreach($transports as $transport)
                  {  ?>
                     <option value="<?=$transport["id"]?>"
                     <? if($transport["id"] == $headdata["req_transportid"]) echo "selected"?>><?=$transport["trans_name"]?></option>
                     <?
                  }
               }
               else
               {  ?>
                  <option value="<?=$headdata["req_transportid"]?>"><?=$headdata["trans_name"]?>&nbsp;</option>
                  <?
               }
               ?>
            </select>
         </td>
         <td class="content_rowl">Estado</td>
         <td class="content_row">
            <?
            $statimg = "";
            switch((int)$headdata["req_status"])
            {
               case 1: $statimg = "red_active.gif"; break;
               case 2: $statimg = "green_active.gif"; break;
               case 3: $statimg = "purple_active.gif"; break;
               case 4: $statimg = "blue_active.gif"; break;
            }
            ?>
            <img class="select" src="./images/content/<?=$statimg?>"> <?=getOrderStatus($headdata["req_status"], true);?>
            <?
            if((int)$headdata["req_isreserva"])
            {
               ?>
               <img class="select" src="./images/content/yellow_active.gif"><label style="color:black;">&nbsp;Reserva</label>
               <? 
            }
            ?>
         </td> 
      
         <td class="content_rowl" valign="top" style="display:none">Cobrador</td>
         <td class="content_row" valign="top" style="display:none">
            <select class="text" style="width:350px" name="req_userid_cashing" id="req_userid_cashing"
            onmousedown="markfield(this,0)" onblur="markfield(this,1)">
               <?
               if($dabl == "")
               {  ?>
                  <option value="">&lt; <?=$_LANG["FORM"]["OPTION"][0]?> &gt;</option>
                  <?
                  foreach($sellers as $seller)
                  {  ?>
                     <option value="<?=$seller["id"]?>"
                     <? if($seller["id"] == $headdata["req_userid_cashing"]) echo "selected"?>><?=$seller["user_firstname"]?> <?=$seller["user_lastname"]?></option>
                     <?
                  }
               }
               else
               {  ?>
                  <option value="<?=$headdata["req_userid_cashing"]?>"><?=$headdata["cashing_firstname"]?> <?=$headdata["cashing_lastname"]?></option>
                  <?
               }
               ?>
            </select>
         </td>

      </tr>
      <tr>
         <td class="content_rowl">Despachar a</td>
         <td class="content_row">
            <select class="text" style="width:350px" name="req_cust_delivid" id="req_cust_delivid"
            onmousedown="markfield(this,0)" onblur="markfield(this,1)">
               <?
               if($dabl == "")
               {  ?>
                  <option value="">DIRECCI�N PRINCIPAL</option>
                  <?
                  foreach($deliveryaddrs as $deliveryaddr)
                  {  ?>
                     <option value="<?=$deliveryaddr["id"]?>"
                     <? if($deliveryaddr["id"] == $headdata["req_cust_delivid"]) echo "selected"?>><?=$deliveryaddr["delivery_street"]?>, <?=$deliveryaddr["nombre"]?>, <?=$deliveryaddr["name"]?></option>
                     <?
                  }
               }
               else
               {
                  if(!(int)$headdata["req_cust_delivid"])
                  {  ?>
                     <option value="">DIRECCI�N PRINCIPAL</option>
                     <?
                  }
                  else
                  {  ?>
                     <option value="<?=$headdata["req_cust_delivid"]?>"><?=$deliveryaddr["delivery_street"]?>, <?=$deliveryaddr["nombre"]?>, <?=$deliveryaddr["name"]?></option>
                     <?
                  }
               }
               ?>
            </select>
         </td>
         <td class="content_rowl">Estado dise�o</td>
         <td class="content_row">
            <?
            $statimg = "red_active.gif";
            $stattxt = "<b class=msg_save_err>Pendiente</b>";
            if($posdata[0]["fab_design_imagehash"] != "")
            {
               $statimg = "green_active.gif";
               $stattxt = "<b class=msg_save_ok>Completo</b>";
            }
            ?>
            <img class="select" src="./images/content/<?=$statimg?>"> <?=$stattxt?>
         </td>   
      </tr>
      <tr>
         <td class="content_rowl">Obs. Despacho</td>
         <td class="content_row">
           <input type="text" class="text" style="width:350px" name="req_despacho_desc" <?=$rdlo?>
              onfocus="markfield(this,0)" onblur="markfield(this,1)"
              value="<?=$headdata["req_despacho_desc"]?>">
         </td>
         <td class="content_rowl">Obs. Embalaje</td>
         <td>
            <input type="text" class="text" style="width:350px" name="req_embalaje_desc" <?=$rdlo?>
            onfocus="markfield(this,0)" onblur="markfield(this,1)"
            value="<?=$headdata["req_embalaje_desc"]?>">
         </td>
      </tr>
      <tr>
         <td class="content_rowl">Pie Imprenta</td>
         <td class="content_row">
            <select class="text" style="width:350px" name="req_pie_imprenta">
            <?
               ?>
                   <option value="">&lt; <?=$_LANG["FORM"]["OPTION"][0]?> &gt;</option>
               <?
               foreach($pieimprenta AS $pimprenta)
               {  ?>
                  <option value="<?=$pimprenta["codigo"]?>" <?if($headdata["req_pie_imprenta"] == $pimprenta["codigo"]) echo "selected"?>>
                     <?=$pimprenta["descripcion"]?>
                  </option>
                  <?
               }
            ?>
            </select>
         </td>
         <td class="content_rowl">Cotizaci�n</td>
         <td class="content_row" style="line-height:22px">
            <?
            if((int)$headdata["req_offerid"])
            {
               $sql = " select req_number
                        from offers
                        where
                        id = {$headdata["req_offerid"]}";
               $offernum = $CON->select($sql);
               echo "<b>{$offernum[0]["req_number"]}</b>";
            }
            else
               echo "&nbsp;";
            ?>
            <span style="float:right;padding-right:40px">
               <select class="text" name="req_cust_aviso_months" style="width:150px;">
                  <option value="">Sin notificaci�n al cliente</option>
                  <?
                  for($m = 1; $m <= 12; $m++)
                  {  ?>
                     <option value="<?=$m?>" <?if((int)$headdata["req_cust_aviso_months"] == $m) echo "selected"?>>Notificar en <?=$m?> meses</option>
                     <?
                  }
                  ?>
               </select>
            </span>
         </td>
      </tr>
      <tr>
         <td class="content_rowl" valign="top">Observaciones<br>[cliente]</td>
         <td class="content_row">
               <textarea class="text" style="width:350px; height:45px" name="req_desc" <?=$rdlo?>
                   onfocus="markfield(this,0)" onblur="markfield(this,1)"><?=stripslashes($headdata["req_desc"])?>
               </textarea>
         </td>
         <td class="content_rowl" valign="top">Observaciones<br>[interno]</td>
         <td class="content_row">
            <textarea class="text" style="width:350px; height:45px" name="req_desc_intern" <?=$rdlo?>
            onfocus="markfield(this,0)" onblur="markfield(this,1)"><?=stripslashes($headdata["req_desc_intern"])?></textarea>
         </td>
      </tr>
      <tr>
      <tr style="display:none">
         <td class="content_rowl" height="28">Conectar con Nota</td>
         <td class="content_row" colspan="3">
            <?
            unset($_RESGLBIDS);
            global $_RESGLBIDS;
            getOrdersDirectRelation($CON, $_REQUEST["id"]);

            if(count($_RESGLBIDS) > 0)
            {
               $_MULTIVINVC = true;
               $relNV = array_keys($_RESGLBIDS);
               ?>
               <span style="padding:2px;padding-left:5px;padding-right:5px;border:1px solid green">
                  <b class="msg_save_ok" style="font-weight:normal !important">Conectado con Confirmaci�n de Compra:
                     <?
                     foreach($relNV AS $relNVidx)
                     {
                        $xcolor = "green";
                        if((int)$_RESGLBIDS[$relNVidx]["req_status"] == 1)
                           $xcolor = "red";
                        ?>
                        <b style="cursor:pointer;color:<?=$xcolor?>" class="xselb"
                        onclick="location.href='index.php?mid=689&exec=edit&subcatexec=basic&id=<?=$_RESGLBIDS[$relNVidx]["id"]?>'"><?=$_RESGLBIDS[$relNVidx]["req_number"]?></b>
                        <?
                     }
                     ?>
                  <b>
               </span>
               <style>.xselb:hover { text-decoration:underline; } </style>
               <?
               if($rdlo == "" && count($_RESGLBIDS) == 1)
               {  ?>
                  <input type="button" class="buttonred" value="Eliminar Vinculo" style="margin-left:1px;width:120px"
                  onclick="if(askDel('')) { document.form_reqpos.delnvrevx.value='<?=$_RESGLBIDS[$relNVidx]["id"]?>';submitForm(document.form_reqpos);}">
                  <?
               }
            }
            elseif($rdlo == "")
            {  ?>
               <table border="0" cellpadding="0" cellspacing="0" width="99%">
               <tr>
                  <td width="80">
                     <input type="text" class="text" style="width:98%" onfocus="markfield(this,0)" name="order_search" id="order_search" value="<?=$_REQUEST["order_search"]?>"
                     onblur="markfield(this,1); if(this.value != '') document.getElementById('idxifrsrc2').src='./libs/modules/orders/searchorders.php?search=' +this.value +'&company_id=<?=$headdata["req_company_id"]?>&shop_id=<?=$headdata["req_shop_id"]?>'">
                  </td>
                  <td>
                     <select class="text" name="order_id" id="order_id" style="width:270px"
                     onmousedown="markfield(this,0)" onblur="markfield(this,1)">
                     </select>
                  </td>
               </tr>
               </table>
               <iframe id="idxifrsrc2" height="0" width="0" frameborder="0"></iframe>
               <?
            }
            ?>
         </td>
      </tr>
      <tr>
         <td class="content_rowl">Creado por</td>
         <td class="content_row"><?=$headdata["crt_firstname"]?> <?=$headdata["crt_lastname"]?>&nbsp;</td>
         <td class="content_rowl">Cambiado por</td>
         <td class="content_row"><?=$headdata["upd_firstname"]?> <?=$headdata["upd_lastname"]?>&nbsp;</td>
      </tr>
      <tr>
         <td class="content_rowl">Creado</td>
         <td class="content_row">
            <input type="text" style="width:80px" id="req_crtdat" name="req_crtdat" <?=$rdlo?>
            class="text <? if($rdlo == "") echo "format-d-m-y divider-dot highlight-days-67 no-locale no-transparency"?>"
            onfocus="markfield(this,0)" onblur="markfield(this,1)" value="<?=date('d.m.Y', $headdata["req_crtdat"])?>">
            <?
            $ts = (int)$headdata["req_production_initdate"];
            if ($ts > strtotime("2000-01-01")) {
               echo "Iniciado: " . date("d.m.Y H:i:s", $ts);
            } else {
               echo "Iniciado: ";
            }
            ?>
         </td>
         <td class="content_rowl">Cambiado</td>
         <td class="content_row"><?=displayDate($headdata["req_upddat"])?></td>
      </tr>
      <?
      if(trim($headdata["cust_notes"]) != "")
      {  ?>
         <tr>
            <td class="content_rowl" valign="top">Comentarios</td>
            <td class="content_row" colspan="3" style="color:navy"><?generateCommentToogle($headdata["cust_notes"])?></td>
         </tr>
         <?
      }
      ?>
      </tbody>
      </table>
      <?=Nifty_printF()?>
   <br>
   <script language="Javascript" src="./libs/jscripts/overlib/overlib.js"></script>
   <div id="overDiv" style="position:absolute; visibility:hidden; z-index:1000"></div>



   <?
   if((int)$headdata["req_isfabricate"])
   {
      $thispos = $posdata[0];

      //----------------------------------------------------------------------------------
      $sql = " select add_name
               from tran_comments_vals
               where
               id = {$thispos["fab_mat_fabric_color"]}";
      $fabric_color = $CON->select($sql);
      $fabric_color = $fabric_color[0]["add_name"];

      //----------------------------------------------------------------------------------
      $sql = " select add_name
               from tran_comments_vals
               where
               id = {$thispos["fab_mat_manilla_color"]}";
      $manilla_color = $CON->select($sql);
      $manilla_color = $manilla_color[0]["add_name"];

      //----------------------------------------------------------------------------------
      $_ROWSPANLINES = 11;
      /*
      for($x = 1; $x <= 5; $x++)
      {
         if((int)$thispos["fab_print_colors_front_{$x}"] || (int)$thispos["fab_print_colors_back_{$x}"])
         {
            $_ROWSPANLINES++;
         }
      }
      */
      //----------------------------------------------------------------------------------
      $sql = " select distinct t1.item_reg_gsm
               from item t1
               INNER JOIN item_productcats t2         ON t1.id = t2.item_id
               INNER JOIN tran_comments_item_vals t3  ON t1.id = t3.item_id
               INNER JOIN tran_comments t4            ON t3.com_id = t4.id
               INNER JOIN tran_comments_vals t5       ON t3.val_id = t5.id
               where
               t1.item_status > 0 and
               t2.cat_id      = {$_CONFIG["TELA_CATID"]} and
               t5.add_name    = '{$thispos["fab_type"]}'
               order by t1.item_reg_gsm asc";
      $optsgrams = $CON->select($sql);
      ?>
      <?=Nifty_printH("box2", "1020",0)?>
      <table border="0" class="content_table" cellpadding="3" cellspacing="0" width="100%">
         <colgroup>
            <col width="130">
            <col width="360">
            <col width="130">
            <col>
         </colgroup>
         <tr>
            <td class="content_tbl_header" colspan="4">Registrar caracter�sticas</td>
         </tr>
         <tr>
            <td class="content_rowl">Caja por Pallet</td>
            <td class="content_row">
               <select class="text" name="req_caja_pallet" style="width:350px">
               <?
                  ?>
                     <option value="">&lt; <?=$_LANG["FORM"]["OPTION"][0]?> &gt;</option>
                  <?
                  foreach($cajasporpallets AS $cajaporpallet)
                  {  ?>
                     <option value="<?=$cajaporpallet["codigo"]?>" <?echo "selected"?>>
                        <?=$cajaporpallet["descripcion"]?>
                     </option>
                     <?
                  }
               ?>
               </select>  
            </td>
         </tr>
         <tr>
         <?
            $items = array_keys($_TRANSCOM);
            $total = count($items);

            for ($i = 0; $i < $total; $i += 2) 
            {
               echo "<tr>";

               // Primera columna
               $trancomid1 = $items[$i];
               echo "<td class='content_rowl'>{$_TRANSCOM[$trancomid1]['NAME']}</td>";
               echo "<td class='content_row'>";
               echo "<select class='text' style='width:350px' name='comvals_{$trancomid1}' id='comvals_{$trancomid1}'>";
               echo "<option value=''>< {$_LANG['FORM']['OPTION'][0]} ></option>";
               foreach (array_keys($_TRANSCOM[$trancomid1]["OPTS"]) as $trancomvalid1) {
                  $selected = ((int)$_COMVALS[$trancomid1] == $trancomvalid1) ? "selected" : "";
                  echo "<option value='{$trancomvalid1}' {$selected}>{$_TRANSCOM[$trancomid1]['OPTS'][$trancomvalid1]}</option>";
               }
               echo "</select></td>";

               // Segunda columna (si existe)
               if (($i + 1) < $total) {
                  $trancomid2 = $items[$i + 1];
                  echo "<td class='content_rowl'>{$_TRANSCOM[$trancomid2]['NAME']}</td>";
                  echo "<td class='content_row'>";
                  echo "<select class='text' style='width:350px;' name='comvals_{$trancomid2}' id='comvals_{$trancomid2}'>";
                  echo "<option value=''>< {$_LANG['FORM']['OPTION'][0]} ></option>";
                  foreach (array_keys($_TRANSCOM[$trancomid2]["OPTS"]) as $trancomvalid2) {
                        $selected = ((int)$_COMVALS[$trancomid2] == $trancomvalid2) ? "selected" : "";
                        echo "<option value='{$trancomvalid2}' {$selected}>{$_TRANSCOM[$trancomid2]['OPTS'][$trancomvalid2]}</option>";
                  }
                  echo "</select></td>";
               } else {
                  // Si hay n�mero impar, se deja la segunda columna vac�a
                  echo "<td colspan='2'></td>";
               }

               echo "</tr>";
            }


         ?>
         </tr>
      </table>
      <?=Nifty_printF()?>
      <br>
      <input type="hidden" name="existing_id_0" value="<?=$thispos["item_id"]?>">
      <input type="hidden" name="existing_pos_0" value="<?=$thispos["item_pos"]?>">
      <input type="hidden" name="item_id_0" value="<?=$thispos["item_id"]?>#<?=$thispos["item_type"]?>">
      <input type="hidden" name="item_compdesc_0" value="<?=stripslashes(nl2br($thispos["item_compdesc"]))?>">
      <input type="hidden" name="item_sellprice_taxes_perc_0" value="<?=printPrice($thispos["item_sellprice_taxes_perc"],2)?>">

      <?=Nifty_printH("box2", "1020",0)?>
      <table border="0" class="content_table" cellpadding="3" cellspacing="0" width="100%">
      <colgroup>
         <col width="130">
         <col width="360">
         <col width="130">
         <col>
      </colgroup>
      <tr>
         <td class="content_tbl_header" colspan="4">Especificaciones del producto</td>
      </tr>
      <tr>
         <td class="content_rowl">Material</td>
         <td class="content_row"><?=$thispos["fab_type"]?></td>
         <td class="content_rowl">SKU</td>
         <td class="content_row"><?=$thispos["item_number_prod"]?></td>
      </tr>
      <tr>
         <td class="content_rowl">Medidas</td>
         <td class="content_row">
            <input type="hidden" name="fab_med_height_dorso" value="<?=(int)$thispos["fab_med_height_dorso"]?>">
            <input type="hidden" name="fab_med_doblez" value="<?=(int)$thispos["fab_med_doblez"]?>">
            <?=(int)$thispos["fab_med_width"]?>x<?=(int)$thispos["fab_med_height"]?> cm
            <?
            if((int)$thispos["fab_med_fuelle"])
               echo ", Fuelle ".(int)$thispos["fab_med_fuelle"]." cm";
            ?>
         </td>
         <td class="content_rowl">Producto</td>
         <td class="content_row"><?=$thispos["item_title"]?></td>
      </tr>
      <tr>
         <td class="content_rowl">Tipo impresion</td>
         <td class="content_row">
            <select class="text" style="width:350px" name="fab_printtype" id="fab_printtype">
               <option value="">&lt; <?=$_LANG["FORM"]["OPTION"][0]?> &gt;</option>
               <option value="FLEX" <?if($thispos["fab_printtype"] == "FLEX") echo "selected"?>>Flexografia</option>
               <option value="SERI" <?if($thispos["fab_printtype"] == "SERI") echo "selected"?>>Serigrafia</option>
            </select>
         </td>
         <td class="content_rowl">Area impresion</td>
         <td class="content_row">
            <input type="text" class="text" style="width:60px;text-align:center;background-color:#f0f0f0;"  name="fab_print_width" id="fab_print_width"
            value="<?=(int)$thispos["fab_print_width"]?>" <?=$rdlo?> readonly>
            x
            <input type="text" class="text" style="width:60px;text-align:center;background-color:#f0f0f0;"  name="fab_print_height" id="fab_print_height"
            value="<?=(int)$thispos["fab_print_height"]?>" <?=$rdlo?> readonly  >
            cm
         </td>
      </tr>
      <tr>
         <td class="content_rowl">Color tela</td>
         <td class="content_row">
            <select class="text" 
                style="width:350px; background-color:#f0f0f0; color:#333; font-weight:bold;" 
                name="fab_mat_fabric_color" id="fab_mat_fabric_color" >
               <option value="">&lt; <?=$_LANG["FORM"]["OPTION"][0]?> &gt;</option>
               <?
               foreach($colors AS $color)
               {  ?>
                  <option value="<?=$color["id"]?>" <?if($color["id"] == $thispos["fab_mat_fabric_color"]) echo "selected"?>>
                     <?=$color["add_name"]?>
                  </option>
                  <?
               }
               ?>
            </select>
            <input type="hidden" name="fab_mat_fabric_color_hidden" id="fab_mat_fabric_color_hidden" value="<?=$thispos["fab_mat_fabric_color"]?>">
         </td>
         <td class="content_rowl">Manillas</td>
         <td class="content_row">
            <input type="text" class="text" style="width:60px;text-align:center" name="fab_manilla_length" id="fab_manilla_length"
            value="<?=(int)$thispos["fab_manilla_length"]?>" <?=$rdlo?>>
            cm
         </td>         
      </tr>
      <tr>
         <td class="content_rowl">Color manillas</td>
         <td class="content_row">
            <select class="text" 
               style="width:350px; background-color:#f0f0f0; color:#333; font-weight:bold;" 
               name="fab_mat_manilla_color" id="fab_mat_manilla_color" >
               <option value="">&lt; <?=$_LANG["FORM"]["OPTION"][0]?> &gt;</option>
               <?
               foreach($colors AS $color)
               {  ?>
                  <option value="<?=$color["id"]?>" <?if($color["id"] == $thispos["fab_mat_manilla_color"]) echo "selected"?>>
                     <?=$color["add_name"]?>
                  </option>
                  <?
               }
               ?>
            </select>
            <input type="hidden" name="fab_mat_manilla_color_hidden" id="fab_mat_manilla_color_hidden" value="<?=$thispos["fab_mat_manilla_color"]?>">
         </td>
         <td class="content_rowl" valign="top" rowspan="3">Descripcion</td>
         <td class="content_row" valign="top" rowspan="3"><?=$thispos["item_compdesc"]?>&nbsp;</td>
      </tr>
      <tr>
         <td class="content_rowl">Gramaje tela</td>
         <td class="content_row">
            <select class="text" style="width:350px;" name="fab_mat_gramms">
               <option value="">&lt; <?=$_LANG["FORM"]["OPTION"][0]?> &gt;</option>
               <?
               foreach($optsgrams AS $optsgram)
               {  ?>
                  <option value="<?=(int)$optsgram["item_reg_gsm"]?>" <?if((int)$optsgram["item_reg_gsm"] == $thispos["fab_mat_gramms"]) echo "selected"?>>
                     <?=(int)$optsgram["item_reg_gsm"]?>
                  </option>
                  <?
               }
               ?>
            </select>
         </td>
      </tr>
      <tr>
         <td class="content_rowl" height="1">Dispositivos</td>
         <td class="content_row" height="1">
             <select class="text" style="width:350px;" name="fab_mat_dispositivo">
                  <option value="">&lt; <?=$_LANG["FORM"]["OPTION"][0]?> &gt;</option>
                  <?
                     foreach($dispositivos AS $dispositivo)
                     {  ?>
                        <option value="<?=$dispositivo["codigo"]?>" <?if($thispos["fab_mat_dispositivo"] == $dispositivo["codigo"]) echo "selected"?> >
                           <?=$dispositivo["descripcion"]?>
                        </option>
                        <?
                     }
                  ?>
             </select>
         </td>
<?php
$sw = 1;
for ($fila = 0; $fila < 5; $fila++) {
    $x = $fila + 1;  // Color 1?5
    $y = $fila + 6;  // Color 6?10
    echo '<tr>';
    // Columna izquierda
    ?>
    <td class="content_rowl">Color #<?=$x?></td>
    <td class="content_row">
        <input type="checkbox" id="fab_print_colors_front_<?=$x?>" value="1"
            <?php if ((int)$thispos["fab_print_colors_front_{$x}"]) echo "checked"; ?> > Frente
        <input type="hidden" name="fab_print_colors_front_<?=$x?>" id="fab_print_colors_front_hidden<?=$x?>" value="<?= (int)$thispos["fab_print_colors_front_{$x}"] ?>">

        <input type="checkbox" id="fab_print_colors_back_<?=$x?>" value="1"
            <?php if ((int)$thispos["fab_print_colors_back_{$x}"]) echo "checked"; ?> > Dorso
        <input type="hidden" name="fab_print_colors_back_<?=$x?>"  name="fab_print_colors_back_hidden<?=$x?>" value="<?= (int)$thispos["fab_print_colors_back_{$x}"] ?>">

        <input type="text" class="text" style="width:200px; background-color:#f0f0f0;"
            id="fab_print_colordesc_<?=$x?>" name="fab_print_colordesc_<?=$x?>"
            value="<?=$thispos["fab_print_colordesc_{$x}"]?>" <?=$rdlo?> >
    </td>
    <?php
    if ($thispos["fab_print_colors_front_{$x}"] == 0 && $thispos["fab_print_colors_back_{$x}"] == 0)
        $sw = 0;

    // Columna derecha
    ?>
    <td class="content_rowl">Color #<?=$y?></td>
    <td class="content_row">
        <input type="checkbox" id="fab_print_colors_front_<?=$y?>" value="1"
            <?php if ((int)$thispos["fab_print_colors_front_{$y}"]) echo "checked"; ?> > Frente
        <input type="hidden" name="fab_print_colors_front_<?=$y?>" id="fab_print_colors_front_hidden<?=$y?>" value="<?= (int)$thispos["fab_print_colors_front_{$y}"] ?>">

        <input type="checkbox" id="fab_print_colors_back_<?=$y?>" value="1"
            <?php if ((int)$thispos["fab_print_colors_back_{$y}"]) echo "checked"; ?> > Dorso
        <input type="hidden" name="fab_print_colors_back_<?=$y?>" id="fab_print_colors_back_hidden<?=$y?>" value="<?= (int)$thispos["fab_print_colors_back_{$y}"] ?>">

        <input type="text" class="text" style="width:200px; background-color:#f0f0f0;"
            id="fab_print_colordesc_<?=$y?>" name="fab_print_colordesc_<?=$y?>"
            value="<?=$thispos["fab_print_colordesc_{$y}"]?>" <?=$rdlo?> >
    </td>
    <?php
    if ($thispos["fab_print_colors_front_{$y}"] == 0 && $thispos["fab_print_colors_back_{$y}"] == 0)
        $sw = 0;

    echo '</tr>';
}
?>
      </tr>
      <tr>
         <td class="content_rowl">Cantidad</td>
         <td class="content_row">
            <input type="text" class="text" name="item_amount_0" style="width:100px;"
            value="<?=printPrice($thispos["item_amount"],2)?>" <?=$rdlo?>>
         </td>
         <td class="content_rowl">Precio / Unitario</td>
         <td class="content_row">
            <nobr>
            $ <input type="text" name="item_sellprice_netto_0" class="text" style="width:55px;" <?=$rdlo?>
               value="<?=printPrice($thispos["item_sellprice_netto"])?>">
            &nbsp;&nbsp;&nbsp;
            <span style="display:none">
            Trazado logo
            $ <input type="text" name="item_sellprice_trazado_0" class="text" style="width:55px;" <?=$rdlo?>
               value="<?=printPrice($thispos["item_sellprice_trazado"])?>">
            &nbsp;&nbsp;&nbsp;
            </span>
            C�d. barra                 
            $ <input type="text" name="item_sellprice_barcode_0" class="text" style="width:60px;" <?=$rdlo?>
               value="<?=printPrice($thispos["item_sellprice_barcode"])?>">
            &nbsp;                
            <select class="text" style="width:100px;" name="item_sellprice_barcodenumber_0" id="item_sellprice_barcodenumber_0">
               <option value="">&lt; <?=$_LANG["FORM"]["OPTION"][0]?> &gt;</option>
               <?
                  foreach($codigobarras AS $codigobarra)
                  {  ?>
                       <option value="<?=$codigobarra["codigo"]?>" <?if($codigobarra["codigo"] == $thispos["item_sellprice_barcodenumber"]) echo "selected"?>>
                          <?=$codigobarra["codigo"]?>
                       </option>
                       <?
                  }
                  ?>
            </select>
            <!--
            <input type="text" name="item_sellprice_barcodenumber_0" class="text" style="width:122px;" <?=$rdlo?>
            value="<?=$thispos["item_sellprice_barcodenumber"]?>" placeholder="Codigo">
               -->
         </nobr> 
         </td>
      </tr>
      <tr>
         <td class="content_rowl" valign="center">Dise�o</td>
         <td id="diseno" name="diseno" class="content_row" valign="top">
            <table border="0" class="content_table" cellpadding="3" cellspacing="0" width="100%" height="100px">
            <?
            if($thispos["fab_design_imagehash"] != "")
            {  ?>
               <!-- <a href="./docs.order/<?=$thispos["fab_design_imagehash"]?>" target="_blank"><img border="0" src="./docs.order/<?=$thispos["fab_design_imagehash"]?>" width="50" height="50"  style="float:left"></a> -->
               <?
               if($headdata["req_status"] == 1)
               {  ?>
                  <input type="button" class="buttonred" value="Eliminar" style="margin-left:10px;margin-top:20px;width:80px"
                  onclick="if(askDel('')) { document.form_reqpos.deldesignimg.value = '<?=$thispos["item_id"]?>-0'; submitForm(document.form_reqpos); }">
                  <div style="height:5px;clear:both"></div>
                  <?
               }
            }
            else 
            {
            ?>
            <tr>
               <td>
                  <input type="radio" onchange="mostrarTD('Si')" value="Si" name="req_caja_impresa" <? if($headdata["req_caja_impresa"] == " " || $headdata["req_caja_impresa"] == "Si")?> checked>Cliente
                  <input type="radio" onchange="mostrarTD('No')" value="No" name="req_caja_impresa" <? if($headdata["req_caja_impresa"] == "No") echo "checked"?>>Generico
               </td>
            </tr>
            <tr>
               <input type="hidden" id="fab_design_imagehash_hidden" name="fab_design_imagehash_hidden">               
               <td id="tdCliente" style="display: table-cell;">
                  <select id="fab_design_imagehash" name="fab_design_imagehash" onchange="mostrarImagen(this);MostarDatosPantalla(this)">
                     <option value="" data-img="">-- Selecciona --</option>
                     <?php foreach($versiones as $version)
                     {
                     ?>
                        <option value="<?= $version['doc_file'] ?>" 
                                data-img            = "<?=$version['doc_file']?>"
                                data-name           = "<?=$version['pro_dis_items_descripcion']?>"
                                data-color01        = "<?=$version["pro_dis_items_color1"]?>"
                                data-color02        = "<?=$version["pro_dis_items_color2"]?>"
                                data-color03        = "<?=$version["pro_dis_items_color3"]?>"
                                data-color04        = "<?=$version["pro_dis_items_color4"]?>"
                                data-color05        = "<?=$version["pro_dis_items_color5"]?>"
                                data-color06        = "<?=$version["pro_dis_items_color6"]?>"
                                data-color07        = "<?=$version["pro_dis_items_color7"]?>"
                                data-color08        = "<?=$version["pro_dis_items_color8"]?>"
                                data-color09        = "<?=$version["pro_dis_items_color9"]?>"
                                data-color10        = "<?=$version["pro_dis_items_color10"]?>"
                                data-color-manilla  = "<?=$version["pro_dis_items_color_manilla"]?>"
                                data-color-tela     = "<?=$version["pro_dis_items_color_tela"]?>"
                                data-codigo-barra   = "<?=$version["pro_dis_items_codigo_barra"]?>"
                                data-tipo-print     = "<?=$version["pro_dis_items_tipo_impresion"]?>"
                                data-print-alto     = "<?=$version["pro_dis_items_print_alto"]?>"
                                data-print-ancho    = "<?=$version["pro_dis_items_print_ancho"]?>"
                                data-print-frente01 = "<?=$version["pro_dis_items_frente1"]?>"
                                data-print-frente02 = "<?=$version["pro_dis_items_frente2"]?>"
                                data-print-frente03 = "<?=$version["pro_dis_items_frente3"]?>"
                                data-print-frente04 = "<?=$version["pro_dis_items_frente4"]?>"
                                data-print-frente05 = "<?=$version["pro_dis_items_frente5"]?>"
                                data-print-frente06 = "<?=$version["pro_dis_items_frente6"]?>"
                                data-print-frente07 = "<?=$version["pro_dis_items_frente7"]?>"
                                data-print-frente08 = "<?=$version["pro_dis_items_frente8"]?>"
                                data-print-frente09 = "<?=$version["pro_dis_items_frente9"]?>"
                                data-print-frente10 = "<?=$version["pro_dis_items_frente10"]?>"
                                data-print-dorso01  = "<?=$version["pro_dis_items_dorso1"]?>"
                                data-print-dorso02  = "<?=$version["pro_dis_items_dorso2"]?>"
                                data-print-dorso03  = "<?=$version["pro_dis_items_dorso3"]?>"                                
                                data-print-dorso04  = "<?=$version["pro_dis_items_dorso4"]?>"
                                data-print-dorso05  = "<?=$version["pro_dis_items_dorso5"]?>"
                                data-print-dorso06  = "<?=$version["pro_dis_items_dorso6"]?>"
                                data-print-dorso07  = "<?=$version["pro_dis_items_dorso7"]?>"
                                data-print-dorso08  = "<?=$version["pro_dis_items_dorso8"]?>"
                                data-print-dorso09  = "<?=$version["pro_dis_items_dorso9"]?>"
                                data-print-dorso10  = "<?=$version["pro_dis_items_dorso10"]?>" 
                        ><?= $version['doc_name'] ?>
                        </option>
                     <?php } ?>
                  </select>
                  
               </td>
               <td id="tdGenerico" style="display: none;">
                  <select id="fab_design_imagehash" name="fab_design_imagehash" onchange="mostrarImagen2(this);MostarDatosPantalla(this)">
                     <option value="" data-img="">-- Selecciona--</option>
                     <?php  foreach($version_generico as $version)
                     {
                     ?>
                        <option value="<?= $version['doc_file'] ?>" 
                                data-img            = "<?= $version['doc_file'] ?>"
                                data-name           = "<?=$version['pro_dis_items_descripcion']?>"
                                data-color01        = "<?=$version["pro_dis_items_color1"]?>"
                                data-color02        = "<?=$version["pro_dis_items_color2"]?>"
                                data-color03        = "<?=$version["pro_dis_items_color3"]?>"
                                data-color04        = "<?=$version["pro_dis_items_color4"]?>"
                                data-color05        = "<?=$version["pro_dis_items_color5"]?>"
                                data-color06        = "<?=$version["pro_dis_items_color6"]?>"
                                data-color07        = "<?=$version["pro_dis_items_color7"]?>"
                                data-color08        = "<?=$version["pro_dis_items_color8"]?>"
                                data-color09        = "<?=$version["pro_dis_items_color9"]?>"
                                data-color10        = "<?=$version["pro_dis_items_color10"]?>"
                                data-color-manilla  = "<?=$version["pro_dis_items_color_manilla"]?>"
                                data-color-tela     = "<?=$version["pro_dis_items_color_tela"]?>"
                                data-codigo-barra   = "<?=$version["pro_dis_items_codigo_barra"]?>"
                                data-tipo-print     = "<?=$version["pro_dis_items_tipo_impresion"]?>"
                                data-print-alto     = "<?=$version["pro_dis_items_print_alto"]?>"
                                data-print-ancho    = "<?=$version["pro_dis_items_print_ancho"]?>"
                                data-print-frente01 = "<?=$version["pro_dis_items_frente1"]?>"
                                data-print-frente02 = "<?=$version["pro_dis_items_frente2"]?>"
                                data-print-frente03 = "<?=$version["pro_dis_items_frente3"]?>"
                                data-print-frente04 = "<?=$version["pro_dis_items_frente4"]?>"
                                data-print-frente05 = "<?=$version["pro_dis_items_frente5"]?>"
                                data-print-frente06 = "<?=$version["pro_dis_items_frente6"]?>"
                                data-print-frente07 = "<?=$version["pro_dis_items_frente7"]?>"
                                data-print-frente08 = "<?=$version["pro_dis_items_frente8"]?>"
                                data-print-frente09 = "<?=$version["pro_dis_items_frente9"]?>"
                                data-print-frente10 = "<?=$version["pro_dis_items_frente10"]?>"
                                data-print-dorso01  = "<?=$version["pro_dis_items_dorso1"]?>"
                                data-print-dorso02  = "<?=$version["pro_dis_items_dorso2"]?>"
                                data-print-dorso03  = "<?=$version["pro_dis_items_dorso3"]?>"                                
                                data-print-dorso04  = "<?=$version["pro_dis_items_dorso4"]?>"
                                data-print-dorso05  = "<?=$version["pro_dis_items_dorso5"]?>"
                                data-print-dorso06  = "<?=$version["pro_dis_items_dorso6"]?>"
                                data-print-dorso07  = "<?=$version["pro_dis_items_dorso7"]?>"
                                data-print-dorso08  = "<?=$version["pro_dis_items_dorso8"]?>"
                                data-print-dorso09  = "<?=$version["pro_dis_items_dorso9"]?>"
                                data-print-dorso10  = "<?=$version["pro_dis_items_dorso10"]?>"      
                              ><?= $version['doc_name'] ?>
                        </option>
                     <?php } 
                     ?>
                  </select>
                  <br>
                  
               </td>
               </tr>
               <script>
                     function mostrarImagen(select) 
                     {
                        let img = document.getElementById("preview");
                        let inputHash = document.getElementById("fab_design_imagehash_hidden");
                        let selectedOption = select.options[select.selectedIndex];
                        let imgSrc = selectedOption.getAttribute("data-img");

                        if (imgSrc) {
                           img.src = "./docs.tran/versiones/" + imgSrc;
                           img.style.display = "block";
                           inputHash.value = imgSrc; // Guarda el nombre del archivo en el input oculto
                        } else {
                           img.style.display = "none";
                           inputHash.value = ""; // Limpia el valor si no hay imagen
                        }
                     }

                     function mostrarImagen2(select)
                     {
                        let img = document.getElementById("preview2");
                        let inputHash = document.getElementById("fab_design_imagehash_hidden");
                        let selectedOption = select.options[select.selectedIndex]; // Obtiene la opci�n seleccionada
                        let imgSrc = selectedOption.getAttribute("data-img"); // Obtiene la imagen asociada
                        if (imgSrc) {
                            img.src = "./docs.tran/versiones/" + imgSrc; // Ajusta la ruta donde est�n las im�genes
                            img.style.display = "block"; // Muestra la imagen
                            inputHash.value = imgSrc; // Guarda el nombre del archivo en el input oculto
                         } else {
                            img.style.display = "none"; // Oculta si no hay selecci�n
                            inputHash.value = ""; // Limpia el valor si no hay imagen
                         }
                     }

                     function mostrarTD(valor) 
                     {
                        if (valor === "Si") {
                           document.getElementById("tdCliente").style.display = "table-cell";
                           document.getElementById("tdGenerico").style.display = "none";
                           document.getElementById("tdClienteI").style.display = "table-cell";
                           document.getElementById("tdGenericoI").style.display = "none";
                        } else {
                           document.getElementById("tdCliente").style.display = "none";
                           document.getElementById("tdGenerico").style.display = "table-cell";
                           document.getElementById("tdClienteI").style.display = "none";
                           document.getElementById("tdGenericoI").style.display = "table-cell";

                        }
                     }

                     function MostarDatosPantalla(select)
                     {
                        const selectedOption = select.options[select.selectedIndex];
                        const manilla = selectedOption.getAttribute('data-color-manilla');
                        const tela    = selectedOption.getAttribute('data-color-tela'); 
                        const barra   = selectedOption.getAttribute('data-codigo-barra');
                        const tipop   = selectedOption.getAttribute('data-tipo-print'); 
                        const alto    = selectedOption.getAttribute('data-print-alto'); 
                        const ancho   = selectedOption.getAttribute('data-print-ancho');
                        
                       

                        for (let i = 1; i <= 10; i++) {
                           const index = String(i).padStart(2, '0'); // "01", "02", ..., "10"
                           const color = selectedOption.getAttribute(`data-color${index}`);
                           const front = selectedOption.getAttribute(`data-print-frente${index}`);
                           const back  = selectedOption.getAttribute(`data-print-dorso${index}`);

                           // Descripci�n del color
                           const descInput = document.getElementById(`fab_print_colordesc_${i}`);
                           if (descInput && color !== null) {
                              descInput.value = color;
                           }

                           // Checkbox Frente
                           const frontCheckbox = document.getElementById(`fab_print_colors_front_${i}`);
                           if (frontCheckbox && front !== null) {
                              frontCheckbox.checked = front === "1";
                           }

                           // Hidden Frente
                           const frontHidden = document.getElementById(`fab_print_colors_front_hidden${i}`);
                           if (frontHidden && front !== null) {
                              frontHidden.value = front;
                           }

                           // Checkbox Dorso
                           const backCheckbox = document.getElementById(`fab_print_colors_back_${i}`);
                           if (backCheckbox && back !== null) {
                              backCheckbox.checked = back === "1";
                           }

                           // Hidden Dorso
                           const backHidden = document.getElementById(`fab_print_colors_back_hidden${i}`);
                           if (backHidden && back !== null) {
                              backHidden.value = back;
                           }
                        }                        

                        document.getElementById('fab_printtype').value = tipop;
                        document.getElementById('fab_print_width').value = ancho;
                        document.getElementById('fab_print_height').value = alto;
                        document.getElementById('fab_mat_manilla_color').value = manilla;
                        document.getElementById('fab_mat_fabric_color').value = tela;
                        document.getElementById('item_sellprice_barcodenumber_0').value = barra;
                        document.getElementById('fab_mat_manilla_color_hidden').value = document.getElementById('fab_mat_manilla_color').value;
                        document.getElementById('fab_mat_fabric_color_hidden').value = document.getElementById('fab_mat_fabric_color').value;
                        document.getElementById('fab_mat_fabric_color_hidden').value = document.getElementById('fab_mat_fabric_color').value;
                     }
               </script>
               <?
            }
            ?>
         </table>         
         </td>
         <td class="content_rowl" valign="center">Imagen</td>
            <?
            if($thispos["fab_design_imagehash"] != "")
            {  ?>
               <td valign="center">
                   <a href="./docs.order/<?=$thispos["fab_design_imagehash"]?>" target="_blank"><img border="0" src="./docs.order/<?=$thispos["fab_design_imagehash"]?>" width="100px" height="100px"  style="float:left"></a>
              </td>
              <?
            }
            else
            {
            ?>
               <td id="tdClienteI" style="display: table-cell;">
                  <img id="preview" src="" style="display:none; width:100px; height:auto; object-fit:contain; margin-top:10px;">
               </td>
               <td id="tdGenericoI" style="display: none;">
                  <img id="preview2" src="" style="display:none; width:100px; margin-top:10px;">
               </td>
            <?
            }
            ?>
         </td>
      </tr>
      <tr>
         <td class="content_rowl" valign="top">Comentarios dise�o</td>
         <td class="content_row" id="diseno2" name="diseno2" colspan="3">
            <textarea type="text" class="text" style="width:100%;height:100%" 
            id="fab_design_desc" name="fab_design_desc"><?=stripslashes($thispos["fab_design_desc"])?></textarea>
         </td>
      </tr>
      </table>
      <?=Nifty_printF(false)?>
      <br>
      <?
   }
   else
   {  ?>
      <?=Nifty_printH("box2", "1020")?>
      <table border="0" class="content_table" cellpadding="3" cellspacing="0" width="100%">
      <colgroup>
         <col width="20">
         <col width="90">
         <col width="28">
         <col width="380">
         <col>
         <col>
         <col width="50">
         <col width="75">
         <col width="45" <?if($_HIDETAXES) echo 'style="display:none"'?>>
         <?
         if($_REQUEST["showDiscounts"] == "1")
         {  ?>
            <col>
            <col>
            <col>
            <col>
            <col>
            <?
         }
         else
         {  ?>
            <col>
            <col>
            <col>
            <col>
            <?
         }
         ?>
         <col width="80">
         <col width="50" style="display:none">
      </colgroup>
      <tr>
         <td class="content_tbl_header" colspan="15">
            <table border="0" cellpadding="0" cellspacing="0" width="100%">
            <tr>
               <td class="content_tbl_header" style="padding:0px">Art�culos</td>
               <?
               if(!(int)$_SESSION["user_pricesell_perm"] && !(int)$_REQUEST["user_pricesell_perm"] && $headdata["req_status"] == 1)
               {  ?>
                  <td class="content_tbl_header" style="padding:0px" width="190">
                     <img src="./images/menu/icons/currency.png" style="vertical-align:bottom">
                     <a class="link" style="color:#333333" href="javascript: deactivateFormChange()"
                     onclick="showFancybox('/libs/modules/orders/auth.pricechange.fancy.php?frmname=form_reqpos', 'iframe', 450, 160, 'no')">Activar cambio de precios</a>
                  </td>
                  <?
               }
               if($headdata["req_status"] == 1 && count($posdata) && $posdata != false)
               {  ?>
                  <td class="content_tbl_header" style="padding:0px" width="150">
                     <img src="./images/menu/icons/arrow-270-medium.png" style="vertical-align:bottom">
                     <a class="link" style="color:#333333" href="javascript: deactivateFormChange()"
                     onclick="document.form_reqpos.setPosOrder.value='prodnumber'; submitForm(document.form_reqpos);">Ordenar por codigo</a>
                  </td>
                  <?
               }
               ?>
               <td class="content_tbl_header" style="padding:0px" width="140">
                  <nobr>
                  <img src="./images/menu/icons/calculator.png" style="vertical-align:bottom">
                  <?
                  if((int)$_REQUEST["showDiscounts"])
                  {
                     $newshowDiscountsTxt = "Ocultar";
                     $newshowDiscounts    = "";
                  }
                  else
                  {
                     $newshowDiscountsTxt = "Mostrar";
                     $newshowDiscounts    = 1;
                  }
                  if($headdata["req_status"] == 1)
                  {  ?>
                     <a class="link" style="color:#333333" href="javascript: deactivateFormChange()"
                     onclick="document.form_reqpos.showDiscounts.value='<?=$newshowDiscounts?>'; submitForm(document.form_reqpos);"><?=$newshowDiscountsTxt?> condiciones</a>
                     <?
                  }
                  else
                  {  ?>
                     <a class="link" style="color:#333333" href="javascript: deactivateFormChange()"
                     onclick="location.href='index.php?mid=<?=$_REQUEST["mid"]?>&exec=edit&subcatexec=basic&id=<?=$_REQUEST["id"]?>&showDiscounts=<?=$newshowDiscounts?>';"><?=$newshowDiscountsTxt?> condiciones</a>
                     <?
                  }
                  ?>
                  </nobr>
               </td>
            </tr>
            </table>
         </td>
      </tr>
      <tr>
         <?
         $coltitle = "Precio/Neto";
         if((int)$headdata["req_isinvcbrutto"])
            $coltitle = "Precio/Bruto";
         ?>
         <td class="content_tbl_subheader" valign="top" align="center">Pos</td>
         <td class="content_tbl_subheader" valign="top">Busqueda</td>
         <td class="content_tbl_subheader" valign="top">Act.</td>
         <td class="content_tbl_subheader" valign="top">Art�culos</td>
   <!--       <td class="content_tbl_subheader" valign="top" align="center">Embal.</td> -->
         <td class="content_tbl_subheader" valign="top" align="right">Cantidad</td>
         <td class="content_tbl_subheader" valign="top" align="right"><?=$coltitle?></td>
         <td class="content_tbl_subheader" valign="top" align="right" <?if($_HIDETAXES) echo 'style="display:none"'?>>IVA %</td>
         <?
         if($_REQUEST["showDiscounts"] == "1")
         {  ?>
            <td class="content_tbl_subheader" align="right"><nobr>Subtotal</nobr></td>
            <td class="content_tbl_subheader" align="center"><nobr>Desc-Global</nobr></td>
            <td class="content_tbl_subheader" align="center"><nobr>Descuentos-Familia</nobr></td>
            <td class="content_tbl_subheader" align="center"><nobr>Desc-Vol.</nobr></td>
            <td class="content_tbl_subheader" align="center"><nobr>Desc-Monto</nobr></td>
            <?
         }
         else
         {  ?>
            <td class="content_tbl_subheader" valign="top" align="center"><nobr>S/Act</nobr></td>
            <td class="content_tbl_subheader" valign="top" align="center"><nobr>S/Tran</nobr></td>
            <td class="content_tbl_subheader" valign="top" align="center"><nobr>S/Res</nobr></td>
            <td class="content_tbl_subheader" valign="top" align="center"><nobr>S/Com</nobr></td>
            <td class="content_tbl_subheader" valign="top" align="center"><nobr>S/Disp</nobr></td>
            <?
         }
         ?>
         <td class="content_tbl_subheader" valign="top" align="right"><nobr>Precio Total</nobr></td>
         <td class="content_tbl_subheader" valign="top" align="right" style="display:none"><nobr>Comprar</nobr></td>
      </tr>
      <?
      $hasItems = false;
      //----------------------------------------------------------------------------------
      for($x = 0; $x < $rowcount; $x++)
      {
         $showmanual = false;
         if((int)$posdata[$x]["item_id"] && $posdata[$x]["item_type"] == "manual")
            $showmanual = true;

         if(!$_FIELDREGS[$x]) $_FIELDREGS[$x] = Array(); $_FIELDREGS[$x][] = "xf_search_{$x}";
         if(!$_FIELDREGS[$x]) $_FIELDREGS[$x] = Array(); $_FIELDREGS[$x][] = "item_id_{$x}";
         if(!$_FIELDREGS[$x]) $_FIELDREGS[$x] = Array(); $_FIELDREGS[$x][] = "item_amount_{$x}";
         if(!$_FIELDREGS[$x]) $_FIELDREGS[$x] = Array(); $_FIELDREGS[$x][] = "item_sellprice_netto_{$x}";
         if(!$_HIDETAXES)
         {
            if(!$_FIELDREGS[$x]) $_FIELDREGS[$x] = Array(); $_FIELDREGS[$x][] = "item_sellprice_taxes_perc_{$x}";
         }
         ?>
         <tr bgcolor="<?=getRowColor($x)?>"<?
         if((int)$posdata[$x]["item_promid"])
         {  ?>
            style="background-color:#C4EEFF"
            onmouseover="return overlib('PROMOCION', WIDTH, 350, RIGHT, FGCOLOR, '#FFFFFF', BGCOLOR, '#698988', ABOVE)"
            onmouseout="return nd()"
            <?
         }
         ?>>
            <td class="content_row" valign="top" align="center"><?=($x +1)?></td>
            <td class="content_row" valign="top">
               <?if($showmanual) { echo "&nbsp;"; $_FIELDIGNORES["xf_search_{$x}"] = 1; } ?>
               <table border="0" cellpadding="0" cellspacing="0" width="100%" id="idx_tdcol1_<?=$x?>" <? if($showmanual) echo "style='display:none'" ?>>
               <tr>
                  <td width="20"><img src="./images/menu/icons/magnifier-zoom.png"></td>
                  <td>
                     <input type="text" class="text" style="width:60px" name="xf_search_<?=$x?>" id="xf_search_<?=$x?>"
                     onfocus="markfield(this,0)" <?=$rdlo?> autocomplete="off"
                     <?
                     if(!(int)$posdata[$x]["item_id"])
                     {  ?>
                        onblur="markfield(this,1);if(this.value!=''){document.all.idxifrsrc.src='./libs/modules/orders/searchitem.php?rowcount=<?=$x?>&reqid=<?=$headdata["id"]?>&search=' +this.value;} this.value='';"
                        onkeyup="detectEvent(event, '<?=$x?>', '<?=$_REQUEST["id"]?>')"
                        <?
                     }
                     else
                     {  ?>
                        onblur="markfield(this,1)"
                        <?
                        $hasItems = true;

                        $item_weight       = $posdata[$x]["item_amount"] * $posdata[$x]["item_weight"];
                        $ges_weight       += $item_weight;
                        $ges_weight_price += ($posdata[$x]["item_amount"] * (float)$posdata[$x]["item_weight_price"]);
                     }
                     ?>>
                  </td>
               </tr>
               </table>
            </td>
            <td class="content_row" valign="top">
               <?
               if((int)$posdata[$x]["item_id"])
               {  ?>
                  <input type="hidden" name="existing_id_<?=$x?>" value="<?=$posdata[$x]["item_id"]?>">
                  <input type="hidden" name="existing_pos_<?=$x?>" value="<?=$posdata[$x]["item_pos"]?>">
                  <input type="button" class="buttonred" value="x" style="width:20px"
                  onmouseover="markbtn(this,0)" onmouseout="markbtn(this,1)" <?=$dabl?>
                  onclick="if(askDel('')) { document.form_reqpos.item_amount_<?=$x?>.value='0'; submitForm(document.form_reqpos); }">
                  <?
               }
               else
               {  ?>
                  <img src="/images/menu/icons/notebook--plus.png" border="0" style="cursor:pointer"
                  onclick="showOrderPartPosManualEdit('<?=$x?>')">
                  <?
               }
               ?>
            </td>
            <td class="content_row" valign="top">
               <?
               $overlibover   = "";
               $overlibover2  = "";
               $selwidth = "355px";
               $noHasMinAmount = false;
               if((int)$posdata[$x]["item_id"])
               {
                  $posdata[$x]["item_costprice_netto"] = precalcSupplierCost($CON, $posdata[$x]["item_id"], $posdata[$x]["item_type"]);

                  if((float)$posdata[$x]["item_sell_amountmin"] && $posdata[$x]["item_amount"] < $posdata[$x]["item_sell_amountmin"])
                     $noHasMinAmount = true;
                  $itemrealsellprice = $posdata[$x]["item_sellprice_netto_dsc"] /  $posdata[$x]["item_amount"];
                  if(!(int)$posdata[$x]["item_promid"] && ($itemrealsellprice < $posdata[$x]["item_costprice_netto"] || $posdata[$x]["item_invoice_note"] != "" || $noHasMinAmount))
                  {
                     if($posdata[$x]["item_invoice_note"] != "")
                        $overlibover .= "<b class=msg_save_err>".str_replace("'","",str_replace('"',"",$posdata[$x]["item_invoice_note"]))."</b>";
                     if($overlibover != "")
                     {  ?>
                        <img src="/images/menu/icons/exclamation-button.png" style="vertical-align:middle"
                        onmouseover="return overlib('<?=$overlibover?>', WIDTH, 350, RIGHT, FGCOLOR, '#FFFFFF', BGCOLOR, '#FF0000', ABOVE)"
                        onmouseout="return nd()">
                        <?
                        $selwidth = "355px";
                     }
                  }
               }
               ?>
               <select class="text" style="width:<?=$selwidth?>;<? if($showmanual) echo "display:none" ?>"
               name="item_id_<?=$x?>" id="item_id_<?=$x?>"
               onblur="markfield(this,1);removeSelStyle(this);removeUnSelected(this)"
               onfocus="<? if(!(int)$posdata[$x]["item_id"]) echo "addSelStyle(this);" ?>"
               onchange="setItemInfosOrderEmbal('<?=$x?>', this.value);showStockAct(<?=$x?>, this.value);">
                  <?
                  if((int)$posdata[$x]["item_id"])
                  {
                     $desc = trim(addslashes($posdata[$x]["item_title"]));
                     ?>
                     <option value="<?=$posdata[$x]["item_id"]?>#<?=$posdata[$x]["item_type"]?>"><?=$posdata[$x]["item_number_prod"]?> - <?=$desc?></option>
                     <?
                  }
                  ?>
               </select>
               <? if($overlibover2 != "") echo "<br><img src='/images/menu/icons/exclamation-red.png' style='valign:bottom'>&nbsp;{$overlibover2}" ?>
               <textarea class="text" name="item_desc_<?=$x?>" id="item_desc_<?=$x?>"
               onfocus="markfield(this,0)" onblur="markfield(this,1)" <?=$rdlo?>
               style="width:<?=$selwidth?>;height:30px;<? if(!$showmanual) echo "display:none" ?>"><?=$posdata[$x]["item_desc"]?></textarea>
               <input type="hidden" name="manual_pos_<?=$x?>" id="manual_pos_<?=$x?>"
               value="<? if($showmanual) echo "1"; else echo "0" ?>">
               <?
               if((int)$posdata[$x]["item_id"] && (int)$posdata[$x]["item_fabricate_act"])
               {  ?>
                  <div style="height:3px"></div>
                  <textarea class="text classy-editor" name="item_compdesc_<?=$x?>" id="item_compdesc_<?=$x?>"
                  style="width:<?=$selwidth?>;height:120px;" placeholder="Registrar detalles del producto"
                  onfocus="markfield(this,0)" onblur="markfield(this,1)" <?=$rdlo?>><?=stripslashes(nl2br($posdata[$x]["item_compdesc"]))?></textarea>
                  <div style="height:3px;clear:both"></div>
                  <?
                  if($posdata[$x]["item_img_hash"] != "")
                  {  ?>
                     <img src="/docs.offer/<?=$posdata[$x]["item_img_hash"]?>" height="100" style="float:left">
                     <input type="button" value="Mostrar" class="button" style="margin-left:15px;margin-top:25px;width:120px"
                     onclick="showFancybox('/docs.offer/<?=$posdata[$x]["item_img_hash"]?>','image', 400, 400, 'no')">
                     <?
                     if($rdlo == "")
                     {  ?>
                        <br>
                        <input type="button" value="Eliminar" class="buttonred" style="margin-left:15px;margin-top:5px;width:120px"
                        onclick="if(askDel('')) { document.form_reqpos.delposimg.value = '<?=$posdata[$x]["item_id"]?>-<?=$x?>'; submitForm(document.form_reqpos); } ">
                        <?
                     }
                  }
                  else
                  {  ?>
                     <input type="file" name="itemimage_<?=$x?>" style="width:90%">
                     <?
                  }
               }
               ?>
            </td>
            <td class="content_row" valign="top" align="center" id="idx_embalval_<?=$x?>" style="display:none">
               <?
               if((int)$posdata[$x]["item_id"])
                  echo printPrice($posdata[$x]["item_unitembalaje_amount"],2);
               echo "&nbsp;";
               ?>
            </td>
            <td class="content_row" align="right" valign="top">
               <input type="text" class="text" style="width:50px;text-align:right"
               onfocus="markfield(this,0)" onblur="markfield(this,1)" autocomplete="off"
               name="item_amount_<?=$x?>" id="item_amount_<?=$x?>" <?=$rdlo?>
               value="<? if((int)$posdata[$x]["item_id"]) echo printPrice($posdata[$x]["item_amount"],2)?>">
            </td>
            <td class="content_row" align="right" valign="top">
               <?
               if(!$hasprcsellperm || $_SESSION["user_type"] != 1)
                  $dscrdlo = " readonly ";
               else
                  $dscrdlo = $rdlo;
               ?>
               <nobr>
               <input type="text" class="text"
               style="width:70px;text-align:right;<?if((int)$headdata["req_isinvcbrutto"]) echo "display:none"?>" <?=$dscrdlo?>
               name="item_sellprice_netto_<?=$x?>" id="item_sellprice_netto_<?=$x?>" autocomplete="off"
               value="<? if((int)$posdata[$x]["item_id"]) echo printPrice($posdata[$x]["item_sellprice_netto"])?>"
               onfocus="markfield(this,0)" onblur="markfield(this,1)">
               </nobr>
               <nobr>
               <input type="text" class="text"
               style="width:70px;text-align:right;<?if(!(int)$headdata["req_isinvcbrutto"]) echo "display:none"?>" <?=$dscrdlo?>
               name="item_sellprice_brutto_<?=$x?>" id="item_sellprice_brutto_<?=$x?>" autocomplete="off"
               value="<? if((int)$posdata[$x]["item_id"]) echo printPrice($posdata[$x]["item_sellprice_brutto"])?>"
               onfocus="markfield(this,0)" onblur="markfield(this,1)">
               </nobr>
            </td>
            <td class="content_row" align="right" valign="top" <?if($_HIDETAXES) echo 'style="display:none"'?>>
               <?
               if(!$hasprcsellperm)
                  $dscrdlo = " readonly ";
               else
                  $dscrdlo = $rdlo;
               ?>
               <input type="text" class="text" style="width:38px;text-align:right" <?=$dscrdlo?>
               name="item_sellprice_taxes_perc_<?=$x?>" id="item_sellprice_taxes_perc_<?=$x?>" autocomplete="off"
               value="<?
                      if((int)$posdata[$x]["item_id"])
                         echo printPrice($posdata[$x]["item_sellprice_taxes_perc"],2);
                      elseif((int)$headdata["req_taxes"])
                         echo printPrice($_SESSION["_CONF"]["conf_taxes"], 2);
                      else
                         echo "0";
                      ?>"
               onfocus="markfield(this,0);" onblur="markfield(this,1)">
            </td>
            <td class="content_row" valign="top" align="right" <? if($_REQUEST["showDiscounts"] != "1") echo "style='display:none'"?>>
               <?
               if((int)$posdata[$x]["item_id"])
               {
                  $ges_line = $posdata[$x]["item_sellprice_netto"] * $posdata[$x]["item_amount"];
                  ?>
                  <input type="text" class="text" tabindex="-1" readonly
                  style="width:65px;text-align:right;"
                  value="<? if((int)$posdata[$x]["item_id"]) echo printPrice($ges_line)?>">
                  <?
               }
               else
                  echo "&nbsp;";
               ?>
            </td>
            <td class="content_row" valign="top" align="center" <? if($_REQUEST["showDiscounts"] != "1") echo "style='display:none'"?>>
               <?
               if((int)$posdata[$x]["item_id"])
               {
                  if(!$hasprcsellperm)
                  {
                     $dscrdlo = " readonly ";
                     $dscdabl = " disabled ";
                  }
                  else
                  {
                     $dscrdlo = $rdlo;
                     $dscdabl = $dabl;
                  }
                  ?>
                  <nobr>
                  <input name="item_discount_<?=$x?>" type="text" tabindex="-1" class="text" style="width:26px;text-align:center;<?
                  if($posdata[$x]["item_discount"] != 0.00) echo "background-color:#E1FFD6"; else echo "background-color:#FFD6D8";?>"
                  value="<? if($posdata[$x]["item_discount"] != 0.00) echo printPrice($posdata[$x]["item_discount"],2);?>" <?=$dscrdlo?>>

                  <select class="text" style="width:35px" tabindex="-1" name="item_discount_type_<?=$x?>" readonly
                  onfocus="markfield(this,0)" onblur="markfield(this,1)" <?=$dscdabl?>>
                     <option value="0" <? if(!(int)$posdata[$x]["item_discount_type"]) echo "selected" ?>>%</option>
                     <option value="1" <? if( (int)$posdata[$x]["item_discount_type"]) echo "selected" ?>><?=$_SESSION["_CONF"]["conf_currency"]?></option>
                  </select>
                  </nobr>
                  <?
               }
               else
                  echo "&nbsp;";
               ?>
            </td>
            <td class="content_row" valign="top" align="center" <? if($_REQUEST["showDiscounts"] != "1") echo "style='display:none'"?>>
               <?
               if((int)$posdata[$x]["item_id"])
               {
                  if(!$hasprcsellperm)
                     $dscrdlo = " readonly ";
                  else
                     $dscrdlo = $rdlo;
                  ?>
                  <nobr>
                  <input type="checkbox" class="checkbox" tabindex="-1" name="item_pcat_dsc_act_<?=$x?>" value="1"
                  <? if(!$hasprcsellperm) echo 'onclick="return false"'?>
                  <? if((int)$posdata[$x]["item_pcat_dsc_act"]) echo "checked"?> <? if($dabl != "") echo "onclick='this.checked=!this.checked'"?>>
                  <?
                  $isfirst = false;
                  for($y = 1; $y <= 4; $y++)
                  {  ?>
                     <input type="text" class="text" tabindex="-1" name="item_pcat_dsc_<?=$x?>_<?=$y?>" style="width:25px;text-align:center;<?
                     if((int)$posdata[$x]["item_pcat_dsc_act"] && $posdata[$x]["item_pcat_dsc{$y}"] > 0.00)
                        echo "background-color:#E1FFD6";
                     else
                        echo "background-color:#FFD6D8";?>"
                     value="<?=printPrice($posdata[$x]["item_pcat_dsc{$y}"],2)?>" <?=$dscrdlo?>>
                     <?
                  }
                  ?>
                  </nobr>
                  <?
               }
               else
                  echo "&nbsp;";
               ?>
            </td>
            <td class="content_row" valign="top" align="center" <? if($_REQUEST["showDiscounts"] != "1") echo "style='display:none'"?>>
               <?
               if((int)$posdata[$x]["item_id"])
               {  ?>
                  <nobr>
                  <input type="checkbox" class="checkbox" name="item_vol_act_<?=$x?>" value="1" tabindex="-1"
                  <? if(!$hasprcsellperm) echo 'onclick="return false"'?>
                  <? if((int)$posdata[$x]["item_vol_act"]) echo "checked"?> <? if($dabl != "") echo "onclick='this.checked=!this.checked'"?>>

                  <input name="item_vol_dsc_<?=$x?>" type="text" class="text" tabindex="-1" style="width:30px;text-align:center;<?
                  if((int)$posdata[$x]["item_vol_act"] && $posdata[$x]["item_vol_dsc"] > 0.00)
                     echo "background-color:#E1FFD6";
                  else
                     echo "background-color:#FFD6D8";?>"
                  value="<? if($posdata[$x]["item_vol_dsc"] > 0.00) echo printPrice($posdata[$x]["item_vol_dsc"],2);?>" readonly>

                  <?
                  if((int)$posdata[$x]["item_vol_dsctype"])
                     echo $_SESSION["_CONF"]["conf_currency"];
                  else
                     echo "%";
                  ?>
                  </nobr>
                  <?
               }
               else
                  echo "&nbsp;";
               ?>
            </td>
            <td class="content_row" valign="top" align="center" <? if($_REQUEST["showDiscounts"] != "1") echo "style='display:none'"?>>
               <?
               if((int)$posdata[$x]["item_id"])
               {
                  ?>
                  <nobr>
                  <input type="checkbox" class="checkbox" name="item_value_act_<?=$x?>" value="1" tabindex="-1"
                  <? if(!$hasprcsellperm) echo 'onclick="return false"'?>
                  <? if((int)$posdata[$x]["item_value_act"]) echo "checked"?> <? if($dabl != "") echo "onclick='this.checked=!this.checked'"?>>
                  <input name="item_value_dsc_<?=$x?>" type="text" tabindex="-1" class="text" style="width:26px;text-align:center;<?
                  if((int)$posdata[$x]["item_value_act"] && $posdata[$x]["item_value_dsc"] > 0.00)
                     echo "background-color:#E1FFD6";
                  else
                     echo "background-color:#FFD6D8";?>"
                  value="<? if($posdata[$x]["item_value_dsc"] > 0.00) echo printPrice($posdata[$x]["item_value_dsc"],2);?>" readonly>
                  <?
                  if((int)$posdata[$x]["item_value_dsctype"])
                     echo $_SESSION["_CONF"]["conf_currency"];
                  else
                     echo "%";
                  ?>
                  </nobr>
                  <?
               }
               else
                  echo "&nbsp;";
               ?>
            </td>
            <td id="stockact_<?=$x?>" class="content_row" align="center" valign="top" <? if($_REQUEST["showDiscounts"] == "1") echo "style='display:none'"?>>
               <?
               if((int)$posdata[$x]["item_id"])
                  printFancyBoxStock($CON, $headdata["req_shop_id"], $posdata[$x]["item_id"], $posdata[$x]["item_type"], "storehousestock");
               else
                  echo "&nbsp;";
               ?>
            </td>
            <td id="stocktrans_<?=$x?>" class="content_row" align="center" valign="top" <? if($_REQUEST["showDiscounts"] == "1") echo "style='display:none'"?>>
               <?
               if((int)$posdata[$x]["item_id"])
                  printFancyBoxStock($CON, $headdata["req_shop_id"], $posdata[$x]["item_id"], $posdata[$x]["item_type"], "transstock");
               else
                  echo "&nbsp;";
               ?>
            </td>
            <td id="stockres_<?=$x?>" class="content_row" align="center" valign="top" <? if($_REQUEST["showDiscounts"] == "1") echo "style='display:none'"?>>
               <?
               if((int)$posdata[$x]["item_id"])
               {
                  $shareamount = getStockShared($CON, $posdata[$x]["item_id"], $posdata[$x]["item_type"], $headdata["req_shop_id"]);
                  echo printPrice($shareamount, 2);
               }
               else
                  echo "&nbsp;";
               ?>
            </td>
            <td id="stockcomp_<?=$x?>" class="content_row" align="center" valign="top" <? if($_REQUEST["showDiscounts"] == "1") echo "style='display:none'"?>>
               <?
               if((int)$posdata[$x]["item_id"])
               {
                  $shareComp = getItemStockComp($CON, $headdata["req_shop_id"], $posdata[$x]["item_id"], $posdata[$x]["item_type"]);
                  echo printPrice($shareComp, 2);
               }
               else
                  echo "&nbsp;";
               ?>
            </td>
            <td id="stockdisp_<?=$x?>" class="content_row" align="center" valign="top" <? if($_REQUEST["showDiscounts"] == "1") echo "style='display:none'"?>>
               <?
               $stock_dispo = 0;
               if((int)$posdata[$x]["item_id"])
               {
                  $stock = getItemShopCurrentStock($CON, $headdata["req_shop_id"], $posdata[$x]["item_id"], $posdata[$x]["item_type"], true, 2);
                  $stock_dispo = $stock - $shareamount - $shareComp;

                  if(!$showmanual && $posdata[$x]["item_amount"] > $stock_dispo)
                     echo "<div style='color:red;border:2px solid red; border-radius: 3px;padding:2px'><blink>";
                  echo printPrice($stock_dispo, 2);
                  if(!$showmanual && $posdata[$x]["item_amount"] > $stock_dispo)
                     echo "</blink></div>";

                  if(!$showmanual && $posdata[$x]["item_amount"] > $stock_dispo)
                  {
                     $_ALERTS[$x]["PRODNAME"] = $posdata[$x]["item_number_prod"]." - ".$desc;
                     $_ALERTS[$x]["STOCKMAX"] = $stock_dispo;
                     $stkdisponosave = 1;
                  }
               }
               else
                  echo "&nbsp;";
               ?>
               <input type="hidden" name="stkdisponosave_<?=$x?>" id="stkdisponosave_<?=$x?>" value="<?=$stock_dispo?>">
            </td>
            <td class="content_row" align="right" valign="top">
               <nobr>
               <input type="text" class="text" readonly tabindex="-1"
               style="<?if((int)$headdata["req_isinvcbrutto"]) echo "display:none"?>;width:65px;text-align:right;background-color:<?if((int)$posdata[$x]["item_id"]) echo "#E1FFD6"; else echo "#FFD6D8"?>"
               value="<? if((int)$posdata[$x]["item_id"]) echo printPrice($posdata[$x]["item_sellprice_netto_dsc"])?>">
               </nobr>
               <nobr>
               <input type="text" class="text" readonly tabindex="-1"
               style="<?if(!(int)$headdata["req_isinvcbrutto"]) echo "display:none"?>;width:65px;text-align:right;background-color:<?if((int)$posdata[$x]["item_id"]) echo "#E1FFD6"; else echo "#FFD6D8"?>"
               value="<? if((int)$posdata[$x]["item_id"]) echo printPrice($posdata[$x]["item_sellprice_brutto_dsc"])?>">
               </nobr>
            </td>
            <td class="content_row" align="right" valign="top" style="display:none">
               <nobr>
               <input type="text" class="text"  name="item_order_genamount_<?=$x?>"
               style="width:50px;text-align:right;background-color:<?if((int)$posdata[$x]["item_order_genamount"]) echo "#E1FFD6"; else echo "#FFD6D8"?>"
               value="<? if((int)$posdata[$x]["item_id"]) echo printPrice($posdata[$x]["item_order_genamount"])?>">
               </nobr>
            </td>
         </tr>
         <?
         if(!(int)$posdata[$x]["item_id"] && $_REQUEST["subexec"] == "save" && !$focusexec)
         {
            $_SESSION["JSEXEC"] .= "document.form_reqpos.xf_search_{$x}.focus();$('html,body').animate({scrollTop:$(window).scrollTop() + 100}, 200);";
            $focusexec = true;
         }
      }
      ?>
      </table>
      <?=Nifty_printF()?>
      <br>
      <?
   }
   ?>
   <table border="0" cellpadding="0" cellspacing="0">
   <tr>
      <td valign="top">
         <?
         if($_REQUEST["showDiscounts"] == "1")
            $ftablewidth = 645;
         else
            $ftablewidth = 1020;

         $headdata["req_discount_amount_netto"] = $headdata["req_discount_amount_netto"] + $headdata["req_weightprice_netto"] + $headdata["req_trazlogoprice_netto"];
         ?>
         <?=Nifty_printH("box1", $ftablewidth,0)?>
         <table border="0" class="content_table" cellpadding="3" cellspacing="0" width="100%" style="padding:1px">
         <colgroup>
            <col>
            <col width="55">
            <col width="100">
         </colgroup>
         <tr bgcolor="<?=getRowColor(0)?>">
            <td class="content_row_clear" colspan="2">SUBTOTAL</td>
            <td class="content_row_clear" align="right">
               <input type="text" class="text" style="width:120px;text-align:right" readonly
               value="<?=printPrice($headdata["req_total_netto"] + $headdata["req_discount_amount_netto"] - $headdata["req_weightprice_netto"] - $headdata["req_trazlogoprice_netto"])?>">
            </td>
         </tr>
         <tr bgcolor="<?=getRowColor(0)?>">
            <td class="content_row_clear" colspan="2">
               <table border="0" class="content_table" cellpadding="0" cellspacing="0" width="100%">
               <tr>
                  <?

                     if($_SESSION["user_type"] != "1")
                     {
                        $blo_descuento =  'readonly'; //
                     }
                     else
                     {
                        $blo_descuento = '';
                     }
        
                  ?>               
                  <td class="content_row_clear">DESCUENTOS</td>
                  <td class="content_row_clear" width="140">
                     <nobr>
                     <input type="text" class="text" style="text-align:center;width:100px;" <?=$blo_descuento?>
                     id="req_discount_perc" name="req_discount_perc"
                     value="<?=printPrice($headdata["req_discount_perc"],2)?>" <?=$rdlo?>> %
                     </nobr>
                  </td>
                  <td class="content_row_clear" align="right" width="1">
                     <nobr>
                     <input type="text" class="text" style="text-align:center;width:100px;" <?=$blo_descuento?>
                     id="req_discount_amt" name="req_discount_amt"
                     value="<?=printPrice($headdata["req_discount_amt"],2)?>" <?=$rdlo?>> $
                     </nobr>
                  </td>
               </tr>
               </table>
            </td>
            <td class="content_row_clear" align="right">
               <input type="text" class="text" style="width:120px;text-align:right" readonly
               value="<?=printPrice($headdata["req_discount_amount_netto"])?>">
            </td>
         </tr>
         <tr bgcolor="<?=getRowColor(0)?>">
            <td class="content_row">
               TRAZADO LOGO
            </td>
            <td class="content_row" align="right">&nbsp;</td>
            <td class="content_row" align="right">
               <nobr>
               <input type="text" class="text" style="width:120px;text-align:right" <?=$rdlo?>
               name="req_trazlogoprice_netto" id="dlv_weightprice_netto"
               value="<?=printPrice($headdata["req_trazlogoprice_netto"])?>"
               onfocus="markfield(this,0)" onblur="markfield(this,1)">
               </nobr>
            </td>
         </tr>
         <tr bgcolor="<?=getRowColor(0)?>">
            <td class="content_row">
               COSTO DESPACHO
            </td>
            <td class="content_row" align="right">&nbsp;</td>
            <td class="content_row" align="right">
               <nobr>
               <input type="text" class="text" style="width:120px;text-align:right" <?=$rdlo?>
               name="dlv_weightprice_netto" id="dlv_weightprice_netto"
               value="<?=printPrice($headdata["req_weightprice_netto"])?>"
               onfocus="markfield(this,0)" onblur="markfield(this,1)">
               </nobr>
            </td>
         </tr>
         <?
         if($headdata["req_total_taxes"] > 0.00)
         {  ?>
            <tr bgcolor="<?=getRowColor(0)?>">
               <td class="content_row_totals content_rowl" colspan="2">NETO</td>
               <td class="content_row_totals content_row" align="right">
                  <input type="text" class="text" style="width:120px;text-align:right;font-weight:bold" readonly
                  value="<?=printPrice($headdata["req_total_netto"])?>">
               </td>
            </tr>
            <tr bgcolor="<?=getRowColor(0)?>">
               <td class="content_row content_rowl" colspan="2">IVA</td>
               <td class="content_row" align="right">
                  <input type="text" class="text" style="width:120px;text-align:right;font-weight:bold" readonly
                  value="<?=printPrice($headdata["req_total_taxes"])?>">
               </td>
            </tr>
            <?
         }
         ?>
         <tr bgcolor="<?=getRowColor(0)?>">
            <td class="content_row_totals content_rowl" colspan="2">TOTAL</td>
            <td class="content_row_totals content_row" align="right">
               <input type="text" class="text" style="width:120px;text-align:right;font-weight:bold;background-color:#E1FFD6" readonly
               value="<?=printPrice($headdata["req_total_brutto"])?>">
            </td>
         </tr>
         </table>
         <?=Nifty_printF(false)?>
      </td>
      <td width="15" class="content_row_clear">&nbsp;</td>
      <td valign="top">
         <script language="JavaScript">
            function setCalcDiscountsGLB()
            {
               var val = document.getElementById('glb_item_discount').value;
               var mod = document.getElementById('glb_item_discount_type').value;

               var $inputs = $('#form_reqpos :input');
               $inputs.each(function()
               {
                  var objname = $(this).attr('name');
                  if(objname.indexOf('item_discount_') > -1)
                     $(this).val(val);
               });

               var $inputs = $('#form_reqpos select');
               $inputs.each(function()
               {
                  var objname = $(this).attr('name');
                  if(objname.indexOf('item_discount_type_') > -1)
                     $(this).val(mod);
               });
            }

            function setCalcDiscountsCAT()
            {
               var val1 = document.getElementById('glb_item_pcat_dsc_1').value;
               var val2 = document.getElementById('glb_item_pcat_dsc_2').value;
               var val3 = document.getElementById('glb_item_pcat_dsc_3').value;
               var val4 = document.getElementById('glb_item_pcat_dsc_4').value;

               var $inputs = $('#form_reqpos :input');
               $inputs.each(function()
               {
                  var objname = $(this).attr('name');
                  if(objname.indexOf('item_pcat_dsc_') > -1 && objname.indexOf('item_pcat_dsc_act_') == -1 && objname.lastIndexOf('_1') == objname.length - 2)
                     $(this).val(val1);
                  if(objname.indexOf('item_pcat_dsc_') > -1 && objname.indexOf('item_pcat_dsc_act_') == -1 && objname.lastIndexOf('_2') == objname.length - 2)
                     $(this).val(val2);
                  if(objname.indexOf('item_pcat_dsc_') > -1 && objname.indexOf('item_pcat_dsc_act_') == -1 && objname.lastIndexOf('_3') == objname.length - 2)
                     $(this).val(val3);
                  if(objname.indexOf('item_pcat_dsc_') > -1 && objname.indexOf('item_pcat_dsc_act_') == -1 && objname.lastIndexOf('_4') == objname.length - 2)
                     $(this).val(val4);
               });
            }

            function setCalcDiscountsACT(mode)
            {
               var sfield = '';
               var ofield = '';
               if(mode == 'CAT') { ofield = 'glb_item_pcat_act';  sfield = 'item_pcat_dsc_act_'; }
               if(mode == 'VOL') { ofield = 'glb_item_vol_act';   sfield = 'item_vol_act_'; }
               if(mode == 'VAL') { ofield = 'glb_item_val_act';   sfield = 'item_value_act_'; }

               var act  = document.getElementById(ofield).checked;
               var $inputs = $('#form_reqpos :checkbox');
               $inputs.each(function()
               {
                  var objname = $(this).attr('name');
                  if(objname.indexOf(sfield) > -1)
                     $(this).attr('checked', act);
               });
            }
         </script>
         <?
         if($headdata["req_status"] < 2 && $_REQUEST["showDiscounts"] == "1" && $hasprcsellperm)
         {  ?>
            <?=Nifty_printH("box1", "525")?>
            <table border="0" class="content_table" cellpadding="3" cellspacing="0" width="100%" style="padding:1px">
            <colgroup>
               <col>
               <col width="180">
               <col width="75">
            </colgroup>
            <tr bgcolor="<?=getRowColor(0)?>">
               <td class="content_rowl" style="border-top:0px">DESCUENTOS GLOBALES</td>
               <td class="content_row" style="border-top:0px" align="right">
                  <input id="glb_item_discount" type="text" class="text" style="width:75px;text-align:center;">

                  <select class="text" style="width:35px" id="glb_item_discount_type"
                  onfocus="markfield(this,0)" onblur="markfield(this,1)">
                     <option value="0">%</option>
                     <option value="1"><?=$_SESSION["_CONF"]["conf_currency"]?></option>
                  </select>
               </td>
               <td class="content_row" style="border-top:0px" align="right">
                  <input type="button" class="button" value="&gt;&gt;" style="width:65px"
                  onmouseover="markbtn(this,0)" onmouseout="markbtn(this,1)"
                  onclick="setCalcDiscountsGLB()">
               </td>
            </tr>
            <tr bgcolor="<?=getRowColor(0)?>">
               <td class="content_rowl">DESCUENTOS POR FAMILIA / COND.</td>
               <td class="content_row" align="right">
                  <?
                  for($y = 1; $y <= 4; $y++)
                  {  ?>
                     <input type="text" class="text" id="glb_item_pcat_dsc_<?=$y?>" style="width:26px;text-align:center;" value="">
                     <?
                  }
                  ?>
               </td>
               <td class="content_row" align="right">
                  <input type="button" class="button" value="&gt;&gt;" style="width:65px"
                  onmouseover="markbtn(this,0)" onmouseout="markbtn(this,1)"
                  onclick="setCalcDiscountsCAT()">
               </td>
            </tr>
            <tr bgcolor="<?=getRowColor(0)?>">
               <td class="content_rowl" valign="top">ACTIVACI�N DESCUENTOS</td>
               <td class="content_row" align="right">
                  POR FAMILIA / CONDICI�N
                  <input type="checkbox" class="checkbox" id="glb_item_pcat_act" value="1" checked>
               </td>
               <td class="content_row" align="right" valign="top">
                  <input type="button" class="button" value="&gt;&gt;" style="width:65px"
                  onmouseover="markbtn(this,0)" onmouseout="markbtn(this,1)"
                  onclick="setCalcDiscountsACT('CAT')">
               </td>
            </tr>
            <tr bgcolor="<?=getRowColor(0)?>">
               <td class="content_rowl" valign="top">ACTIVACI�N DESCUENTOS</td>
               <td class="content_row" align="right">
                  POR VOLUMEN
                  <input type="checkbox" class="checkbox" id="glb_item_vol_act" value="1" checked>
               </td>
               <td class="content_row" align="right" valign="top">
                  <input type="button" class="button" value="&gt;&gt;" style="width:65px"
                  onmouseover="markbtn(this,0)" onmouseout="markbtn(this,1)"
                  onclick="setCalcDiscountsACT('VOL')">
               </td>
            </tr>
            <tr bgcolor="<?=getRowColor(0)?>">
               <td class="content_rowl" valign="top">ACTIVACI�N DESCUENTOS</td>
               <td class="content_row" align="right">
                  POR MONTO
                  <input type="checkbox" class="checkbox" id="glb_item_val_act" value="1" checked>
               </td>
               <td class="content_row" align="right" valign="top">
                  <input type="button" class="button" value="&gt;&gt;" style="width:65px"
                  onmouseover="markbtn(this,0)" onmouseout="markbtn(this,1)"
                  onclick="setCalcDiscountsACT('VAL')">
               </td>
            </tr>
            </table>
            <?=Nifty_printF(false)?>
            <?
         }
         else
            echo "&nbsp;";
         ?>
      </td>
   </tr>
   </table>
   </td>
</tr>
</table>
<br>
<?
if($_REQUEST["showDiscounts"] == "1")
   $ftablewidth = 1180;
else
   $ftablewidth = 1020;
?>
<?=Nifty_printH("boxopt_b", $ftablewidth,0)?>
<?
if($_REQUEST["openfancymode"] == "offeraddfabitempre")
{  ?>
   <script language="JavaScript">
   $(document).ready(function()
   {
     showFancybox('/iframe.fancy.php?module=offeraddagregacolor&id=<?=$_REQUEST["id"]?>', 'iframe', 750, 500, 'yes');
   });
   </script>
   <?
}

if($_REQUEST["openfancymode"] == "diseno")
{  ?>
   <script language="JavaScript">
   $(document).ready(function()
   {
     // showFancybox('/iframe.fancy.php?module=offeraddagregacolor&id=<?=$_REQUEST["id"]?>', 'iframe', 750, 500, 'yes');
     showFancybox('/libs/modules/orders/seleccion.diseno.fancy.php?id=<?=$_REQUEST["id"]?>', 'iframe', 980, 300, 'yes');
   });
   </script>
   <?
}
?>
<table border="0" cellspacing="0" cellpadding="0" width="100%">
<tr>
   <td width="130">
      <?
      printButton($_LANG["FORM"]["BUTTON"][1], "postnav", "index.php?mid={$_REQUEST["mid"]}", "", "arrow-180");
      ?>
   </td>
   <td>&nbsp;</td>
   <?
   $sql = " select count(*) 'cc'
            from orders_delivery
            where
            dlv_order_id = {$headdata["id"]} and
            dlv_status > 1";
   $hasshipments = $CON->select($sql);
   $hasshipments = (int)$hasshipments[0]["cc"];

   if($headdata["req_status"] >= 2 && !(int)$headdata["req_invoiced"] && !$hasshipments)
   {  ?>
      <td width="130" style="padding-right:5px">
         <?
         printButton("Editar", "postnav_del", "javascript: deactivateFormChange()", "if(askDel('')){ location.href = 'index.php?mid={$_REQUEST["mid"]}&exec=edit&id={$_REQUEST["id"]}&restablecer=1'; }", "arrow-circle-045-left");
         ?>
      </td>
      <?
   }
   if(($headdata["req_status"] == 2 || $headdata["req_status"] == 3) &&
      (!(int)$headdata["req_order_shipped"]))
   {  ?>
      <td align="right" width="190" style="padding-right:5px">
         <?
         printButton("Cerrar nota para despachos", "postnav_del", "javascript: deactivateFormChange()", "askDel('index.php?mid={$_REQUEST["mid"]}&exec=edit&id={$_REQUEST["id"]}&cancelshp=1')", "tick-circle-frame");
         ?>
      </td>
      <?
   }
   if($headdata["req_status"] == 1)
   {  ?>
      <td align="right" width="130" style="padding-right:5px">
         <?
         printButton($_LANG["FORM"]["BUTTON"][2], "postnav_del", "javascript: deactivateFormChange()", "askDel('index.php?mid={$_REQUEST["mid"]}&subexec=del&id={$_REQUEST["id"]}')", "cross-circle-frame");
         ?>
      </td>
      <td align="right" width="130" style="padding-right:5px">
         <?
         printButton($_LANG["FORM"]["BUTTON"][0], "postnav", "javascript: deactivateFormChange()", "submitForm(document.form_reqpos)", "disk-black");
         ?>
      </td>
      <?
      if(!(int)$headdata["req_isfabricate"] || ((int)$headdata["req_isfabricate"] && $thispos["fab_design_imagehash"] != ""))
      {
         if((int)$userdata["user_orderaprob_perm"])
         {  ?>
            <td align="right" width="130" style="padding-right:5px">
               <?
               printButton("Aprobar", "postnav_save", "javascript: deactivateFormChange()", "if(askDel('')){document.form_reqpos.req_status.value='2';submitForm(document.form_reqpos);}", "tick-circle-frame");
               ?>
            </td>
            <?
         }
      }
      if($thispos["fab_design_imagehash"] != "" && (int)$userdata["user_orderaprob_perm"])
      {  ?>
         <td width="130">
            <?
            printButton("Imprimir 3", "postnav", "javascript: deactivateFormChange()", "document.form_reqpos.autoopenpdf.value='1';submitForm(document.form_reqpos);", "document-pdf");
            ?>
         </td>
         <?
      }
   }
   if((int)$headdata["req_order_shipped"] && $headdata["req_status"] >= 2 && (int)$userdata["user_orderaprob_perm"])
   {  ?>
      <td align="right" width="190" style="padding-right:5px">
         <?
         printButton("Abrir nota para despachos", "postnav_save", "javascript: deactivateFormChange()", "askDel('index.php?mid={$_REQUEST["mid"]}&exec=edit&id={$_REQUEST["id"]}&revertshp=1')", "tick-circle-frame");
         ?>
      </td>
      <?
   }
   if($headdata["req_status"] >= 2 && $headdata["req_hash"] != "" && (int)$userdata["user_orderaprob_perm"])
   {
      if(!(int)$headdata["req_order_shipped"])
      {  ?>
         <td width="130" style="padding-right:5px">
            <?
            printButton("Generar Factura", "postnav_save", "javascript: deactivateFormChange()", "if(askDel('')) { location.href='index.php?mid={$_REQUEST["mid"]}&exec=edit&id={$_REQUEST["id"]}&generateInvoices=1'}", "gear");
            ?>
         </td>
         <?
      }
      ?>
      <td width="130" style="padding-right:5px">
         <?
         if((int)$headdata["req_isfabricate"])
            printButton("Imprimir 1", "postnav", "javascript: deactivateFormChange()", "document.all.idxifrsrc.src = './libs/modules/structure/document_file.php?type=0&hash={$headdata["req_hash"]}&name={$headdata["req_number"]}.pdf&path=../../../docs.order/'", "script");
         else
            printButton("Imprimir 2", "postnav", "javascript: deactivateFormChange()", "document.all.idxifrsrc.src = './libs/modules/structure/document_file.php?type=0&hash={$headdata["id"]}.{$headdata["req_hash"]}.pdf&name={$headdata["req_number"]}.pdf&path=../../../docs.order/'", "script");
         ?>
      </td>
      <?
   }
   if($headdata["req_status"] >= 1 && count($custselarr) && $thispos["fab_design_imagehash"] != "" && (int)$userdata["user_orderaprob_perm"])
   {  ?>
      <td width="130" style="padding-left:5px">
         <?
         if($headdata["req_status"] == 1)
            printButton("Enviar", "postnav_save", "javascript: deactivateFormChange()", "document.form_reqpos.autoopensendmail.value='1';submitForm(document.form_reqpos)", "mail");
         else
            printButton("Enviar", "postnav_save", "javascript:document.all.idx_mail.style.display='';$('html,body').animate({scrollTop:$('#idx_mail').offset().top}, 600);void(0)", "", "mail");
         ?>
      </td>
      <?
   }
   ?>
</tr>
</table>
<?
if($rdlo == "")
   $_SESSION["JSEXEC"] .= "addFormListeners('form_reqpos');";
?>
<?=Nifty_printF(false)?>
</form>

<?
if($headdata["req_status"] >= 1)
{
   if(count($custselarr))
   {  ?>
      <div id="idx_mail" style="display:none">
      <script type="text/javascript" src="./libs/jscripts/tinymce_3_2_2_3/jscripts/tiny_mce/tiny_mce.js"></script>
      <script type="text/javascript">
         tinyMCE.init({
            mode : "specific_textareas",
            editor_selector : "mceEditor",
            theme : "advanced",
            plugins : "safari,pagebreak,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template",
            theme_advanced_buttons1 : "bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,bullist,numlist,outdent,indent,blockquote,|,forecolor,backcolor,tablecontrols",
            theme_advanced_buttons2 : "", theme_advanced_buttons3 : "", theme_advanced_buttons4 : "",
            theme_advanced_toolbar_location : "top", theme_advanced_toolbar_align : "left",
            content_css : "css/content.css", template_external_list_url : "lists/template_list.js", external_link_list_url : "lists/link_list.js", external_image_list_url : "lists/image_list.js", media_external_list_url : "lists/media_list.js",
            width: "810px", height: "150px", force_br_newlines: true, forced_root_block: ''
         });
      </script>
      <form action="index.php" method="post" name="xform_docsend" onsubmit="return checkform(new Array(this.msg_header, this.msg_body))">
      <input type="hidden" name="exec" value="<?=$_REQUEST["exec"]?>">
      <input type="hidden" name="subexec" value="send">
      <input type="hidden" name="id" value="<?=$_REQUEST["id"]?>">
      <input type="hidden" name="mid" value="<?=$_REQUEST["mid"]?>">
      <?=Nifty_printH("box2", "1020",0)?>
      <table border="0" class="content_table" cellpadding="3" cellspacing="0" width="100%">
      <colgroup>
         <col width="150">
         <col>
      </colgroup>
      <tr>
         <td class="content_tbl_header" colspan="2">Enviar correo</td>
      </tr>
      <tr>
         <td class="content_rowl" valign="top"><?=$_LANG["MODULE"]["MSG"][19]?></td>
         <td class="content_row">
            <?
            $msg_header1 = "Confirmaci�n de Compra de Unibag a ";
            $msg_header2 = $headdata["req_number"];
            
            for($yy = 0; $yy < count($custselarr); $yy++)
            {  ?>
               <input type="radio" name="xrecpt" <? if($yy == 0) echo "checked"?>
               onclick="document.xform_docsend.msg_toname.value='<?=$custselarr[$yy]["NAME"]?>';
                        document.xform_docsend.msg_toaddr.value='<?=$custselarr[$yy]["MAIL"]?>';
                        $('#msg_header').val('<?=$msg_header1?><?=$custselarr[$yy]["NAME"]?>: N� <?=$msg_header2?>');
                        ">
               <?=$custselarr[$yy]["NAME"]?> &lt;<?=$custselarr[$yy]["MAIL"]?>&gt;
               <br>
               <?
            }
            $msg_header = "{$msg_header1}{$custselarr[0]["NAME"]}: N� {$msg_header2}";

            $sql = " select user_mail_signature_html
                     from user
                     where
                     id = {$_SESSION["user_id"]}";
            $mailsig = $CON->select($sql);
            $mailsig = $mailsig[0]["user_mail_signature_html"];
            if(trim($mailsig) != "")
               $msg_body = "<br><br>".$mailsig;
            ?>
         </td>
      </tr>
      <tr>
         <td class="content_rowl">Nombre *</td>
         <td class="content_row">
            <input type="text" name="msg_toname" class="text" style="width:280px" value="<?=$custselarr[0]["NAME"]?>"
            onfocus="markfield(this,0)" onblur="markfield(this,1)">
         </td>
      </tr>
      <tr>
         <td class="content_rowl">E-Mail *</td>
         <td class="content_row">
            <input type="text" name="msg_toaddr" class="text" style="width:280px" value="<?=$custselarr[0]["MAIL"]?>"
            onfocus="markfield(this,0)" onblur="markfield(this,1)">
         </td>
      </tr>
      <tr>
         <td class="content_rowl" valign="top">CCO</td>
         <td class="content_row">
            <?
            for($yy = 0; $yy < count($ccousers); $yy++)
            {  ?>
               <input type="checkbox" name="xcco[]" value="<?=$ccousers[$yy]["id"]?>">
               <?=$ccousers[$yy]["user_firstname"]?> <?=$ccousers[$yy]["user_lastname"]?> &lt;<?=$ccousers[$yy]["user_mail"]?>&gt;
               <br>
               <?
            }
            ?>
         </td>
      </tr>
      <tr>
         <td class="content_rowl"><?=$_LANG["MODULE"]["MSG"][29]?> *</td>
         <td class="content_row">
            <input type="text" class="text" style="width:810px" maxlength="254" name="msg_header" id="msg_header" value="<?=$msg_header?>"
            onfocus="markfield(this,0)" onblur="markfield(this,1)">
         </td>
      </tr>
      <tr>
         <td class="content_rowl" valign="top"><?=$_LANG["MODULE"]["MSG"][30]?> *</td>
         <td class="content_row">
            <textarea class="text mceEditor" style="width:810px; height:150px" name="msg_body"
            onfocus="markfield(this,0)" onblur="markfield(this,1)">
Estimado/a Cliente;
<br><br>
Junto con saludar y agradeciendo su preferencia, env�o adjunto Confirmaci�n de Compra para su aprobaci�n.<br>
Solicitamos revisar con atenci�n cada detalle y devolver firmada para poder enviar su pedido a producci�n.
<br><br>
Tambi�n necesitamos recibir el pago por el 50 % del pedido total. Importe a depositar: $<?=printPrice(round($headdata["req_total_brutto"] / 2))?>
<br><br>
Los datos para el dep�sito son:<br>
<li>UNIBAG SPA
<li>RUT: 76.283.675-0
<li>BANCO BCI
<li>CTA CTE. 70122202
<li>Mail: <?=$_SESSION["user_mail"]?>
<br><br>
Una vez recibido el pago del anticipo y el archivo firmado comenzamos con la producci�n.
<br><br>
Adem�s, necesitamos que por favor nos env�e los siguientes datos para la facturaci�n y entrega:<br><br>
<b>Datos facturaci�n</b>
<li>Raz�n social
<li>RUT
<li>Giro
<li>Direcci�n
<li>Persona encargada de recibir factura electr�nica.
<li>Mail de la persona que recibe las facturas
<li>Tel�fono de persona que recibe las facturas
<br><br>
<b>Datos para la entrega</b>
<li>Domicilio de entrega (aclarar si tiene estacionamiento)
<li>Horario de descarga permitido
<li>Persona encargada de recepci�n y tel�fono
<li>Confirmar si se debe agendar la recepci�n con anticipaci�n y datos de contacto con quien hacerlo.
<br><br>
<b>Contacto Finanzas</b>
<li>Persona encargada de pagos
<li>Mail
<li>Tel�fono
<li>D�as de pago
<li>Forma de pago: Cheque, transferencia, vale vista (especificar banco)
<br><br>
Quedo atento/a a su respuesta.
<br>
<?=stripslashes($msg_body)?></textarea>
         </td>
      </tr>
      </table>
      <?=Nifty_printF()?>
      <br>
      <table border="0" cellspacing="0" cellpadding="0" width="1020">
      <tr>
         <td>&nbsp;</td>
         <td width="130" style="padding-right:5px">
            <?
            printButton("Enviar", "postnav_save", "javascript: deactivateFormChange()", "tinyMCE.triggerSave();submitForm(document.xform_docsend)", "mail");
            ?>
         </td>
      </tr>
      </form>
      </table>
      <br><br><br>
      </div>
      <?
   }
}

//----------------------------------------------------------------------------------
if((int)$headdata["req_isfabricate"] && !(int)$headdata["req_production_act"] && (int)$headdata["req_status"] >= 2)
{  
   
   $sql = " select t1.*
            from plantas t1
            where
            t1.planta_status > 0
            order by t1.planta_name";
   $plantas = $CON->select($sql);
   ?>
   <br>
   <form action="index.php" method="post" name="form_prodinit" id="form_prodinit" enctype="multipart/form-data"
   onsubmit="return checkform(new Array(this.prd_plantaid))">
   <input type="hidden" name="exec" value="edit">
   <input type="hidden" name="subexec" value="prodinitsave">
   <input type="hidden" name="id" value="<?=$_REQUEST["id"]?>">
   <input type="hidden" name="mid" value="<?=$_REQUEST["mid"]?>">
   <input type="hidden" name="prodact" value="1">
   <?=Nifty_printH("box2", "1020",0)?>
   <table border="0" class="content_table" cellpadding="3" cellspacing="0" width="100%">
   <colgroup>
      <col width="120">
      <col width="140">
      <col>
   </colgroup>
   <tr>
      <td class="content_tbl_header" colspan="3">Registrar fechas de entrega y observaciones</td>
   </tr>
   <tr>
      <td class="content_tbl_subheader content_row_os">Cantidad</td>
      <td class="content_tbl_subheader content_row_os">Fecha entrega</td>
      <td class="content_tbl_subheader content_row_os">Planta y observaciones</td>
   </tr>
   <?
   for($x = 0; $x < 5; $x++)
   {  ?>
      <tr bgcolor="<?=getRowColor($x)?>">
         <td class="content_row">
            <input type="text" class="text" style="width:100%" onkeyup="$('#idx_finalbtnx').hide(0);"
            name="prodplan_amt_<?=$x?>" id="prodplan_amt_<?=$x?>"
            value="">
         </td>
         <td class="content_row">
            <input type="text" class="text format-d-m-y divider-dot highlight-days-67 no-locale no-transparency"
            name="prodplan_date_<?=$x?>" id="prodplan_date_<?=$x?>" style="width:80px"
            value="">
         </td>
         <?
         if(!$x)
         {  ?>
            <td class="content_row" valign="top" rowspan="5">
               <select class="text" style="width:100%" name="prd_plantaid"
               onchange="submitForm(document.idx_xform)">
                  <option value="">Seleccione una planta</option>
                  <?
                  foreach($plantas AS $planta)
                  {  ?>
                     <option value="<?=$planta["id"]?>" <?if($planta["id"] == $proddata["prd_plantaid"]) echo "selected"?>><?=$planta["planta_name"]?></option>
                     <?
                  }
                  ?>
               </select>
               <div style="height:3px"></div>
               <textarea name="prd_desc" class="text" style="width:100%;height:<?=((5 * 28)-28)?>px;min-height:60px"></textarea>
            </td>
            <?
         }  
         ?>
      </tr>
      <?
   }
   ?>
   </table>
   <?=Nifty_printF(false)?>
   <br>
   <?=Nifty_printH("boxopt_b", "1020",0)?>
   <table border="0" cellspacing="0" cellpadding="0" width="100%">
   <tr>
      <td width="130" style="padding-right:5px" align="right">
         <?
         printButton("Iniciar Fabricaci�n", "postnav_save", "javascript: deactivateFormChange()", "if(askDel('')) { submitForm(document.form_prodinit); }", "tick-circle-frame", 140);
         ?>
      </td>
   </tr>
   </table>
   <?=Nifty_printF(false)?>
   <?
}
?>
<iframe id="idxifrsrc" height="0" width="0" frameborder="0"></iframe>
<?
if($_REQUEST["setPosOrder"] == "prodnumber")
{  ?>
   <script language="JavaScript">
      submitForm(document.form_reqpos);
   </script>
   <?
}



//----------------------------------------------------------------------------------
if((int)$_REQUEST["generateInvoices"])
{
   $itemsperinvoice     = 999999;
   $invc_date           = mktime(15, 0, 0, date('m'), date('d'), date('Y'));
   $invc_delivery_date  = $invc_date;
   $invc_stockchange    = 0;
   $rowcount            = count($posdata);
   $geninvoices         = ceil($rowcount / $itemsperinvoice);
   $deleteafterpos      = 0;
   $orderdiscountamt    = $headdata["req_discount_amt"];
   $ordertotalnetto     = $headdata["req_total_netto"];
   $invc_isinvcbrutto   = (int)$headdata["req_isinvcbrutto"];

   //----------------------------------------------------------------------------------
   for($x = 0; $x < $geninvoices; $x++)
   {
      $invc_number      = createTransactionNumber($CON, $headdata["req_company_id"], "invoicesell");
      $invc_dlv_docnum  = $invc_number;
      $deleteafterpos   += $itemsperinvoice;

      $deleteposidx_before = $deleteafterpos - $itemsperinvoice;
      $deleteposidx_after  = $deleteafterpos -1;

      //----------------------------------------------------------------------------------
      $sql = " select t1.cust_paymentid, t1.cust_sellerid, t1.cust_transportid, t2.pay_days
               from customer t1
               LEFT OUTER JOIN payments t2 ON t1.cust_paymentid = t2.id
               where
               t1.id = {$headdata["req_cust_id"]}";
      $xcustdata = $CON->select($sql);
      $xcustdata = $xcustdata[0];

      $currtme          = time();
      $invc_paymentdays = (int)$xcustdata["pay_days"];
      $tmp_estpay       = time() + ($invc_paymentdays * 86400);
      $invc_estpay_date = mktime(15, 0, 0, date('m', $tmp_estpay), date('d', $tmp_estpay), date('Y', $tmp_estpay));

      //----------------------------------------------------------------------------------
      $sql = " insert into invoices_sell
               (invc_number, invc_cust_id, invc_company_id, invc_shop_id, invc_date, invc_receipt_date,
                invc_taxes, invc_type, invc_stockchange, invc_userid_seller, invc_userid_cashing,
                invc_paymentid, invc_transportid, invc_delivery_date, invc_dlv_docnum, invc_estpay_date,
                invc_docnumber, invc_crtdat, invc_crtusr, invc_cust_delivid, invc_isinvcbrutto)
               VALUES
               ('{$invc_number}', {$headdata["req_cust_id"]}, {$headdata["req_company_id"]},
                 {$headdata["req_shop_id"]}, {$invc_date}, {$invc_date}, {$headdata["req_taxes"]}, 2,
                 {$invc_stockchange}, {$headdata["req_userid_seller"]}, {$headdata["req_userid_cashing"]}, {$headdata["req_paymentid"]},
                 {$headdata["req_transportid"]}, {$invc_date}, '{$invc_number}', {$invc_estpay_date},
                 '{$invc_number}', {$currtme}, {$_SESSION["user_id"]}, {$headdata["req_cust_delivid"]},
                 {$invc_isinvcbrutto})";
      $res = $CON->no_result($sql);
      if($res)
      {
         $sql = " select MAX(id) 'thisid'
                  from invoices_sell
                  where
                  invc_crtusr = {$_SESSION["user_id"]}";
         $invoiceid = $CON->select($sql);
         $invoiceid = $invoiceid[0]["thisid"];

         invoiceSellAddOrder($CON, $invoiceid, $_REQUEST["id"]);

         $sql = " delete from invoices_sell_parts_items
                  where
                  invc_id  = {$invoiceid} and
                  (
                     item_pos < {$deleteposidx_before} or
                     item_pos > {$deleteposidx_after}
                  )";
         $CON->no_result($sql);

         $sql = " update invoices_sell
                  set
                  invc_discount_amt = 0.00
                  where
                  id = {$invoiceid}";
         $CON->no_result($sql);

         recalcOrder($CON, $invoiceid, "INVOICE");

         $sql = " select invc_total_netto
                  from invoices_sell
                  where
                  id = {$invoiceid}";
         $tempnetto = $CON->select($sql);
         $tempnetto = $tempnetto[0]["invc_total_netto"];

         $_INVCNETTOS[$invoiceid]["NETTO"] = $tempnetto;
         $_TOTALNETTO += $tempnetto;
      }
   }
   foreach(array_keys($_INVCNETTOS) AS $invcid)
   {
      $nettoamt   = $_INVCNETTOS[$invcid]["NETTO"];
      $nettoprc   = $nettoamt / $_TOTALNETTO * 100;
      $dscamt     = round($orderdiscountamt / 100 * $nettoprc,0);
      $_INVCNETTOS[$invcid]["DISCOUNT"] = $dscamt;
   }
   $_INVCNETTOS = calcNormalizeDiscountArray($_INVCNETTOS, $orderdiscountamt);
   foreach(array_keys($_INVCNETTOS) AS $invcid)
   {
      $invc_discount_amt = (float)$_INVCNETTOS[$invcid]["DISCOUNT"];

      $sql = " update invoices_sell
               set
               invc_discount_amt = {$invc_discount_amt}
               where
               id = {$invcid}";
      $CON->no_result($sql);
      recalcOrder($CON, $invcid, "INVOICE");

      $sql = " select invc_number
               from invoices_sell
               where
               id = {$invcid}";
      $invc_number = $CON->select($sql);
      $invc_number = $invc_number[0]["invc_number"];
      $invc_number_str .= $invc_number.", ";


      
   }
   $invc_number_str = substr($invc_number_str, 0, -2);

   if(count($_INVCNETTOS) > 1)
   {  ?>
      <script language="JavaScript">
         alert('FACTURAS GENERADAS: <?=$invc_number_str?>\nFAVOR INGRESA A LOS DOCUMENTOS VIA EL MENU.');
      </script>
      <?
   }
   else
   {  ?>
      <script language="JavaScript">
         //alert('FACTURA GENERADA: <?=$invc_number_str?>');
         location.href='/index.php?mid=751&exec=edit&subexec=edit&id=<?=$invcid?>';
      </script>
      <?
   }
}
if(is_array($_ALERTS) && count($_ALERTS) > 0 && $headdata["req_status"] == 1)
{
   /*
   $alert["PRODNAME"] = trim(addslashes(str_replace("'", "", str_replace('"', "", $alert["PRODNAME"]))));
   $jsstr .= "ADVERTENCIA:\\n";
   foreach($_ALERTS AS $alert)
      $jsstr .= "LA CANTIDAD DEL PRODUCTO \\\"{$alert["PRODNAME"]}\\\" SUPERA EL STOCK DE {$alert["STOCKMAX"]}\\n";
   ?>
   <script language="Javascript">
      alert('<?=$jsstr?>');
   </script>
   <?
   */
}
?>



<script language="JavaScript">
$(document).ready(function()
{
   $(".classy-editor").each(function()
   {
      $(this).ClassyEdit();
   });
});
</script>
<?
if((int)$_REQUEST["autoopensendmail"])
{
   $_SESSION["JSEXEC"] .= ";document.all.idx_mail.style.display='';";
   $_SESSION["JSEXEC"] .= ";$('html,body').animate({scrollTop:$('#idx_mail').offset().top}, 600);";
}
if((int)$_REQUEST["autoopenpdf"])
{
   $_SESSION["JSEXEC"] .= ";document.all.idxifrsrc.src = './libs/modules/orders/data.pdf.php?id={$_REQUEST["id"]}';";
}