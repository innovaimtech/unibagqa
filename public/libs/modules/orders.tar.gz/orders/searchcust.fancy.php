<?
//----------------------------------------------------------------------------------
// Author:        1BIT LTDA
// Copyright:     2011 by 1BIT LTDA. All Rights Reserved.
// Any unauthorized redistribution, reselling, modifying or reproduction of part
// or all of the contents in any form is strictly prohibited.
//----------------------------------------------------------------------------------

//----------------------------------------------------------------------------------
require_once("../../../libs/classes/page.php");
require_once("../../../libs/classes/mysql.php");
require_once("../../../libs/config.php");

//----------------------------------------------------------------------------------
error_reporting($_CONFIG[$_CONFIG["_MODUS"]]["ERROR_REPORTING"]);

//----------------------------------------------------------------------------------
session_start();

require_once("../../../libs/lang/{$_SESSION["_CONF"]["conf_lang_filename"]}");
require_once("../../../libs/functions.php");

//----------------------------------------------------------------------------------
$CON = new CMYSQL($_CONFIG[$_CONFIG["_MODUS"]]["DATABASE"]["NAME"],
                  $_CONFIG[$_CONFIG["_MODUS"]]["DATABASE"]["HOST"],
                  $_CONFIG[$_CONFIG["_MODUS"]]["DATABASE"]["USER"],
                  $_CONFIG[$_CONFIG["_MODUS"]]["DATABASE"]["PASS"]);
$CON->connect();

header ('Last-Modified: '.gmdate("D, d M Y H:i:s").' GMT');
header ('Expires: '.gmdate("D, d M Y H:i:s").' GMT');
header ('Cache-Control: no-cache, must-revalidate');
header ('Pragma: no-cache');

//----------------------------------------------------------------------------------
if($_REQUEST["subexec"] == "search")
{
   $_REQUEST["country"]        = (int)$_REQUEST["country"];
   $_REQUEST["regions"]        = (int)$_REQUEST["regions"];
   $_REQUEST["comunas"]        = (int)$_REQUEST["comunas"];
   $_REQUEST["provincias"]     = (int)$_REQUEST["provincias"];
   $_REQUEST["sql_stext"]      = trim(addslashes(str_replace("*","%",str_replace(".","",$_REQUEST["sql_stext"]))));

   $datsql = " select distinct t1.id, t1.cust_name, t1.cust_rut, t1.cust_street
               from customer t1
               where
               t1.cust_status = 1 ";

   //----------------------------------------------------------------------------------
   if($_REQUEST["country"])
      $datsql .= " and t1.cust_countryid = {$_REQUEST["country"]} ";
   if($_REQUEST["regions"])
      $datsql .= " and t1.cust_regionid = {$_REQUEST["regions"]} ";
   if($_REQUEST["comunas"])
      $datsql .= " and t1.cust_comunaid = {$_REQUEST["comunas"]} ";
   if($_REQUEST["provincias"])
      $datsql .= " and t1.cust_provinciaid = {$_REQUEST["provincias"]} ";
   if($_REQUEST["sql_stext"] != "")
      $datsql .= " and (t1.cust_name      like '%{$_REQUEST["sql_stext"]}%' or
                        t1.cust_company   like '%{$_REQUEST["sql_stext"]}%' or
                        REPLACE(t1.cust_rut,'.','') like '{$_REQUEST["sql_stext"]}%') ";

   $datsql .= " order by 2,3 ";
     
   //----------------------------------------------------------------------------------
   $customers  = $CON->select($datsql);
}
   
//----------------------------------------------------------------------------------
$countries  = getCountries($CON);
$regions    = getRegions($CON);
$comunas    = getComunas($CON);
$provincias = getProvincias($CON);

if($_REQUEST["inpobj"] == "")
   $_REQUEST["inpobj"] = "cust_search";
?>
<html>
<head>
   <title><?=$_SESSION["_CONF"]["conf_title"]?></title>
   <style type="text/css">
      <? $_SESSION["_PAGE"]->printStyle() ?>
   </style>
   <script language="Javascript">
      <?
      require_once("../../../libs/jscripts/sourcen.php");
      generateCountryJS($countries, $regions, $comunas, $provincias);
      ?>
      function setSelData(idx)
      {
         parent.document.getElementsByName('<?=$_REQUEST["inpobj"]?>')[0].value='';
         parent.document.getElementById('idxifrsrc').src='./libs/modules/orders/searchcust.php?destobj=<?=$_REQUEST["destobj"]?>&rowcount=0&custid=' +idx;
         parent.$.fancybox.close();
      }
   </script>
   <script type="text/javascript" src="/libs/jscripts/jquery-1.4.2.js"></script>
   <script type="text/javascript" src="/libs/jscripts/jquery.table_navigation.js"></script>
   <style type="text/css">
   tr.selected {background-color: <?=$_SESSION["_PAGE"]->getEffectVal("js_content_hover")?>;}
   </style>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body class="page_content" onload="<? if(count($customers) == 0 || $customers == false) echo "document.xform_itemsearch.sql_stext.focus()"?>">
<input type="hidden" name="jschk_formchange" id="jschk_formchange" value="0">
<input type="hidden" name="jschk_formchange_ignore" id="jschk_formchange_ignore" value="0">
<table border="0" cellpadding="0" cellspacing="0" width="100%">
<tr>
   <td>
      <form action="searchcust.fancy.php" method="post" name="xform_itemsearch" class="fokusfirst">
      <input type="hidden" name="subexec" value="search">
      <input type="hidden" name="mid" value="<?=$_REQUEST["mid"]?>">
      <input type="hidden" name="destobj" value="<?=$_REQUEST["destobj"]?>">
      <input type="hidden" name="inpobj" value="<?=$_REQUEST["inpobj"]?>">
      <?=Nifty_printH("box2", "980")?>
      <table border="0" class="content_table" cellpadding="3" cellspacing="0" width="100%">
      <colgroup>
         <col width="100">
         <col>
         <col width="100">
         <col width="385">
      </colgroup>
      <tr>
         <td class="content_tbl_header" colspan="4">Opciones de b�squeda</td>
      </tr>
      <tr>
         <td class="content_rowl">Palabra</td>
         <td class="content_row">
            <input name="sql_stext" type="text" class="text" style="width:375px"
            value="<?=str_replace("%","*",$_REQUEST["sql_stext"])?>"
            onfocus="markfield(this,0)" onblur="markfield(this,1)">
         </td>
         <td class="content_rowl">Pa�s</td>
         <td class="content_row">
            <select class="text" style="width:375px" name="country" id="country"
            onchange="setRegions(this.value)"
            onmousedown="markfield(this,0)" onblur="markfield(this,1)">
               <option value="">&lt; <?=$_LANG["FORM"]["OPTION"][0]?> &gt;</option>
               <?
               foreach($countries as $country)
               {  ?>
                  <option value="<?=$country["id"]?>"
                  <? if($country["id"] == $_REQUEST["country"]) echo "selected"?>><?=$country["country_name"]?></option>
                  <?
               }
               ?>
            </select>
         </td>
      </tr>
      <tr>
         <td class="content_rowl">Regi�n</td>
         <td class="content_row">
            <select class="text" style="width:375px" name="regions" id="regions"
            onchange="setProvincias(this.value);"
            onmousedown="markfield(this,0)" onblur="markfield(this,1)">
               <option value="">&lt; <?=$_LANG["FORM"]["OPTION"][0]?> &gt;</option>
               <?
               if((int)$_REQUEST["country"])
               {
                  foreach($regions as $region)
                  {
                     if($region["id_pais"] == $_REQUEST["country"])
                     {  ?>
                        <option value="<?=$region["id"]?>"
                        <? if($region["id"] == $_REQUEST["regions"]) echo "selected"?>><?=$region["name"]?></option>
                        <?
                     }
                  }
               }
               ?>
            </select>
         </td>
         <td class="content_rowl">Provincia</td>
         <td class="content_row">
            <select class="text" style="width:375px" name="provincias" id="provincias" onmousedown="markfield(this,0)" onblur="markfield(this,1)"
            onchange="setComunas(this.value)">
               <option value="">&lt; <?=$_LANG["FORM"]["OPTION"][0]?> &gt;</option>
               <?
               if((int)$_REQUEST["regions"])
               {
                  foreach($provincias as $provincia)
                  {
                     if($provincia["region_id"] == $_REQUEST["regions"])
                     {  ?>
                        <option value="<?=$provincia["id"]?>"
                        <? if($provincia["id"] == $_REQUEST["provincias"]) echo "selected"?>><?=$provincia["pro_name"]?></option>
                        <?
                     }
                  }
               }
               ?>
            </select>
         </td>
      </tr>
      <tr>
         <td class="content_rowl">Comuna</td>
         <td class="content_row">
            <select class="text" style="width:375px" name="comunas" id="comunas" onmousedown="markfield(this,0)" onblur="markfield(this,1)">
               <option value="">&lt; <?=$_LANG["FORM"]["OPTION"][0]?> &gt;</option>
               <?
               if((int)$_REQUEST["provincias"])
               {
                  foreach($comunas as $comuna)
                  {
                     if($comuna["prov_id"] == $_REQUEST["provincias"])
                     {  ?>
                        <option value="<?=$comuna["id"]?>"
                        <? if($comuna["id"] == $_REQUEST["comunas"]) echo "selected"?>><?=$comuna["nombre"]?></option>
                        <?
                     }
                  }
               }
               ?>
            </select>
         </td>
         <td class="content_row" align="right" colspan="2">
            <table border="0" cellpadding="0" cellspacing="0" width="270">
            <tr>
               <td align="right">&nbsp;</td>
               <td align="right">
                  <?
                  printButton("Buscar", "postnav_save", "javascript: deactivateFormChange()", "submitForm(document.xform_itemsearch)", "magnifier", 130);
                  $_SESSION["_SUBMITBTN"] = 1;
                  ?>
               </td>
            </tr>
            </table>
         </td>
      </tr>
      </table>
      <?=Nifty_printF()?>
      </form>
   </td>
</tr>
</table>
<?=Nifty_printH("box1", "980")?>
<table border="0" class="navigateable" cellpadding="3" cellspacing="0" width="100%">
<colgroup>
   <col width="90">
   <col>
   <col>
   <col width="85">
</colgroup>
<thead>
<tr>
   <td class="content_tbl_subheader">RUT</td>
   <td class="content_tbl_subheader">Nombre</td>
   <td class="content_tbl_subheader">Direcci�n</td>
   <td class="content_tbl_subheader" align="center">Opciones</td>
</tr>
</thead>
<tbody>
<?
//----------------------------------------------------------------------------------
for($x = 0; $x < count($customers) && $customers != false; $x++)
{  ?>
   <tr bgcolor="<?=getRowColor($x)?>" class="viewable_records">
      <td class="content_row"><?=$customers[$x]["cust_rut"]?>&nbsp;</td>
      <td class="content_row"><?=$customers[$x]["cust_name"]?>&nbsp;</td>
      <td class="content_row"><?=$customers[$x]["cust_street"]?>&nbsp;</nobr></td>
      <td class="content_row" align="center">
         <?
         printButton("Seleccionar", "postnav_save", "javascript: deactivateFormChange()\" class=\"activation", "setSelData('{$customers[$x]["id"]}')", "tick-circle-frame");
         ?>
      </td>
   </tr>
   <?
}
if(!$x)
{  ?>
   <tr bgcolor="<?=getRowColor($x)?>">
      <td class="content_row" colspan="4" align="center" style="height:40px">
         <b class="msg_save_err"><?=$_LANG["FORM"]["MESSAGE"][5]?></b>
      </td>
   </tr>
   <?
}
?>
</tbody>
</table>
<?=Nifty_printF()?>
<script type="text/javascript">
jQuery.tableNavigation({
   table_selector: 'table.navigateable',
   row_selector: 'table.navigateable tbody tr.viewable_records',
   selected_class: 'selected',
   activation_selector: 'a.activation',
   bind_key_events_to_links: true,
   focus_links_on_select: true,
   select_event: 'click',
   activate_event: 'dblclick',
   activation_element_activate_event: 'click',
   scroll_overlap: 20,
   cookie_name: null,
   focus_tables: true,
   focused_table_class: 'focused',
   jump_between_tables: false,
   disabled: false,
   on_activate: null,
   on_select: null
});
</script>
</body>
</html>