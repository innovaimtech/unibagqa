<?
//----------------------------------------------------------------------------------
// Author:        1BIT LTDA
// Copyright:     2011 by 1BIT LTDA. All Rights Reserved.
// Any unauthorized redistribution, reselling, modifying or reproduction of part
// or all of the contents in any form is strictly prohibited.
//----------------------------------------------------------------------------------

//----------------------------------------------------------------------------------
$sql = " select *
         from user
         where
         id = {$_SESSION["user_id"]}";
$userdata = $CON->select($sql);
$userdata = $userdata[0];

//----------------------------------------------------------------------------------
$_sesmodulename         = "orders";
$_sesbasefilterstatus   = "1";
$_sesbaseorderby        = "1";
$_sesbaseordersort      = "desc";
$_sortlinks             = Array("N�mero" => "2", "Cliente" => "8","Cartera De"=> "13", "Vendedor" => "12", "Monto Compra" => "5", "Creado" => "3", "Estado" => "4"); //  "Empresa" => "5,6", 
$_SESSION[$_sesmodulename]["sql_company"] = $_SESSION["user_company_id"];

//----------------------------------------------------------------------------------
resetOverviewSession($_sesmodulename);

if($_REQUEST["exec"] == "edit")
   require_once("overview.edit.php");
else
{
   //----------------------------------------------------------------------------------
   if($_REQUEST["subexec"] == "search")
   {
      $sql_item = explode("#", $_REQUEST["item_id"]);
      
      $_SESSION[$_sesmodulename]["sql_company"]   = (int)$_REQUEST["sql_company"];
      $_SESSION[$_sesmodulename]["sql_shop"]      = (int)$_REQUEST["sql_shop"];
      $_SESSION[$_sesmodulename]["sql_customer"]  = (int)$_REQUEST["sql_customer"];
      $_SESSION[$_sesmodulename]["sql_stext"]     = trim(addslashes(str_replace("*","%",$_REQUEST["sql_stext"])));
      $_SESSION[$_sesmodulename]["sql_item_id"]   = $sql_item[0];
      $_SESSION[$_sesmodulename]["sql_item_type"] = $sql_item[1];
      $_SESSION[$_sesmodulename]["sql_dateto"]    = trim($_REQUEST["sql_dateto"]);
      $_SESSION[$_sesmodulename]["sql_datefrom"]  = trim($_REQUEST["sql_datefrom"]);
      $_SESSION[$_sesmodulename]["sql_status"]    = $_REQUEST["sql_status"];
      $_SESSION[$_sesmodulename]["sql_mode"]      = (int)$_REQUEST["sql_mode"];
      $_SESSION[$_sesmodulename]["sql_custprov"]  = trim($_REQUEST["sql_custprov"]);
      $_SESSION[$_sesmodulename]["sql_seller"]    = trim($_REQUEST["sql_seller"]);
      $_SESSION[$_sesmodulename]["page"]          = 0;
      $_SESSION[$_sesmodulename]["search_active"] = 1;
   }

   //----------------------------------------------------------------------------------
   prepareOverviewSession($_sesmodulename, $_sesbasefilterstatus, $_sesbaseorderby, $_sesbaseordersort);

   if($_SESSION[$_sesmodulename]["filter_status"] != 5)
      if(!is_array($_SESSION[$_sesmodulename]["sql_status"]))
         $_SESSION[$_sesmodulename]["sql_status"] = Array(0=>1,1=>2,2=>3,3=>4);

   //----------------------------------------------------------------------------------
   if($_REQUEST["subexec"] == "del")
   {
      $sql = " update orders
               set
               req_status = 0
               where
               id = {$_REQUEST["id"]}";
      $res = $CON->no_result($sql);
      $savemsg = getSaveMessage($res);
   }

   //----------------------------------------------------------------------------------
   $seasql = "";
   $joisql = " LEFT OUTER JOIN company_data t2  ON t1.req_company_id = t2.id
               LEFT OUTER JOIN company_shops t3 ON t1.req_shop_id    = t3.id
               LEFT OUTER JOIN customer t4      ON t1.req_cust_id    = t4.id 
               LEFT OUTER JOIN user u4          ON t1.req_userid_seller = u4.id
               LEFT OUTER JOIN user u5          ON t4.cust_sellerid = u5.id ";

   if($_SESSION[$_sesmodulename]["sql_item_id"] != "")
      $joisql .= " INNER JOIN orders_items t6 ON t1.id = t6.req_id ";

   $cntsql = " select count(distinct t1.id) 'cc'
               from orders t1
               {$joisql}
               where
               t1.req_status IN ({$_SESSION[$_sesmodulename]["filter_status"]})";

   $datsql = " select distinct t1.id
                             , t1.req_number
                             , t1.req_crtdat
                             , t1.req_status
                             , t1.req_total_netto
                             , t2.company_short
                             , t3.shop_name
                             , t4.cust_name
                             , t1.req_isreserva
                             , t1.req_isfabricate
                             , t1.req_hash
                             , concat(u4.user_firstname,' ',u4.user_lastname) as Nombre
                             , concat(u5.user_firstname,' ',u5.user_lastname) as Cartera
               from orders t1
               {$joisql}
               where
               t1.req_status IN ({$_SESSION[$_sesmodulename]["filter_status"]}) ";

   //----------------------------------------------------------------------------------
   if($_SESSION[$_sesmodulename]["sql_company"])
      $seasql .= " and t1.req_company_id = {$_SESSION[$_sesmodulename]["sql_company"]} ";
   if($_SESSION[$_sesmodulename]["sql_shop"])
      $seasql .= " and t1.req_shop_id = {$_SESSION[$_sesmodulename]["sql_shop"]} ";
   if($_SESSION[$_sesmodulename]["sql_customer"])
      $seasql .= " and t1.req_cust_id = {$_SESSION[$_sesmodulename]["sql_customer"]} ";
   if((int)$_SESSION[$_sesmodulename]["sql_seller"])
      $seasql .= " and t1.req_userid_seller = {$_SESSION[$_sesmodulename]["sql_seller"]} ";

   if($_SESSION[$_sesmodulename]["sql_stext"] != "")
   {
      $seasql .= " and
                     (
                        t1.req_number     like '%{$_SESSION[$_sesmodulename]["sql_stext"]}%' or
                        t4.cust_name      like '%{$_SESSION[$_sesmodulename]["sql_stext"]}%' or
                        t4.cust_company   like '%{$_SESSION[$_sesmodulename]["sql_stext"]}%'
                     ) ";
   }
   if($_SESSION[$_sesmodulename]["sql_custprov"] != "")
      $seasql .= " and t1.req_custnameprov  like '%{$_SESSION[$_sesmodulename]["sql_custprov"]}%' ";
   if((int)$_SESSION[$_sesmodulename]["sql_mode"] == 1 )
      $seasql .= " and t1.req_isreserva  = 0 ";
   elseif((int)$_SESSION[$_sesmodulename]["sql_mode"] == 2 )
      $seasql .= " and t1.req_isreserva  = 1 ";

   if($_SESSION[$_sesmodulename]["sql_item_id"] != "")
      $seasql .= " and t6.item_id = {$_SESSION[$_sesmodulename]["sql_item_id"]}
                   and t6.item_type = '{$_SESSION[$_sesmodulename]["sql_item_type"]}' ";

   if((int)$userdata["user_orderlimit_perm"])
      $seasql .= " and (t1.req_crtusr = {$_SESSION["user_id"]} or t4.cust_sellerid = {$_SESSION["user_id"]} or t1.req_userid_seller = {$_SESSION["user_id"]} )  "; 

   //----------------------------------------------------------------------------------
   if($_SESSION[$_sesmodulename]["sql_datefrom"] != "" || $_SESSION[$_sesmodulename]["sql_dateto"] != "")
   {
      if($_SESSION[$_sesmodulename]["sql_dateto"] == "")
         $_SESSION[$_sesmodulename]["sql_dateto"] = date('d.m.Y');
      if($_SESSION[$_sesmodulename]["sql_datefrom"] == "")
         $_SESSION[$_sesmodulename]["sql_datefrom"] = "01.01.".date('Y');

      $sqldate_from = getDateFromString($_SESSION[$_sesmodulename]["sql_datefrom"]);
      $sqldate_to   = getDateFromString($_SESSION[$_sesmodulename]["sql_dateto"], false);

      $seasql .= " and t1.req_crtdat between {$sqldate_from} and {$sqldate_to} ";
   }

   //----------------------------------------------------------------------------------
   if($_SESSION[$_sesmodulename]["filter_status"] != 4)
   {
      $seastatstr = "";
      foreach($_SESSION[$_sesmodulename]["sql_status"] AS $seastat)
         $seastatstr .= $seastat.",";
      $seastatstr = substr($seastatstr, 0, -1);
      $seasql .= " and req_status IN ({$seastatstr}) ";
   }

   //----------------------------------------------------------------------------------
   $cntsql   .= $seasql;
   $datsql   .= $seasql;
   $itemcount = $CON->select($cntsql);
   $itemcount = (int)$itemcount[0]["cc"];

   //----------------------------------------------------------------------------------
   $_SESSION[$_sesmodulename]["startrow"] = $_SESSION[$_sesmodulename]["page"] * $_SESSION[$_sesmodulename]["rows_per_page"];

   $datsql .= " order by {$_SESSION[$_sesmodulename]["orderBy"]} {$_SESSION[$_sesmodulename]["orderSort"]} ";
   $datsql .= " LIMIT {$_SESSION[$_sesmodulename]["startrow"]}, {$_SESSION[$_sesmodulename]["rows_per_page"]}";

   //----------------------------------------------------------------------------------
   $orders = $CON->select($datsql);
   // Convierte el primer objeto del arreglo a JSON
   $jsonOrder = json_encode($orders[1]);

   $companies  = getCompanies($CON);
   $shops      = getShops($CON);
   $sellers    = getSellers($CON);

   //----------------------------------------------------------------------------------
   ?>
   <style type="text/css"><!-- @import url(./libs/jscripts/datepicker/datepicker.css); //--></style>
   <script language="JavaScript" src="./libs/jscripts/datepicker/datepicker.js"></script>
   <?
   printJSsetCompanyShop($shops);
   ?>
   <table border="0" cellpadding="0" cellspacing="0" width="980">
   <tr>
      <td height="30"><b class="content_header">Resumen de confirmaciones de compra</b></td>
      <td align="right" class="content_row_clear"><? if($savemsg == "") printOverviewResults($itemcount); else echo $savemsg;?></td>
   </tr>
   <tr>
      <td class="content_headerline" colspan="2">&nbsp;</td>
   </tr>
   </table>
   <table border="0" cellpadding="0" cellspacing="0" width="100%">
   <tr>
      <td>
         <form action="index.php" method="post" name="xform_itemsearch" class="fokusfirst">
         <input type="hidden" name="subexec" value="search">
         <input type="hidden" name="mid" value="<?=$_REQUEST["mid"]?>">
         <?=Nifty_printH("box2", "980")?>
         <table border="0" class="content_table" cellpadding="3" cellspacing="0" width="100%">
         <colgroup>
            <col width="100">
            <col>
            <col width="100">
            <col width="300">
         </colgroup>
         <tr>
            <td class="content_tbl_header" colspan="4">Opciones de b�squeda</td>
         </tr>
         <tr>
            <td class="content_rowl">N�mero/Nombre</td>
            <td class="content_row">
               <input name="sql_stext" type="text" class="text" style="width:375px"
               value="<?=str_replace("%","*",$_SESSION[$_sesmodulename]["sql_stext"])?>"
               onfocus="markfield(this,0)" onblur="markfield(this,1)">
            </td>
            <td class="content_rowl">Empresa</td>
            <td class="content_row"><? printOverviewCompanySelect($companies, $_sesmodulename) ?></td>
         </tr>
         <tr>
            <td class="content_rowl">Art�culo</td>
            <td class="content_row"><? printOverviewItemSelect($_sesmodulename) ?></td>
            <td class="content_rowl">Sucursal</td>
            <td class="content_row"><? printOverviewShopSelect($shops, $_sesmodulename) ?></td>
         </tr>
         <tr>
            <td class="content_rowl">Cliente</td>
            <td class="content_row"><? printOverviewCustomerSelect($_sesmodulename) ?></td>
            <td class="content_rowl">Periodo</td>
            <td class="content_row"><? printOverviewPeriodSelect($_sesmodulename) ?></td>
         </tr>
         <tr>
            <?
            if($_SESSION[$_sesmodulename]["filter_status"] != 5)
            {  ?>
               <td class="content_rowl">Estado</td>
               <td class="content_row">
                  <?
                  for($x = 1; $x <= 4; $x++)
                  {  ?>
                     <input type="checkbox" name="sql_status[]" value="<?=$x?>"
                     <? if(array_search($x, $_SESSION[$_sesmodulename]["sql_status"]) !== false) echo "checked"?>><?=getOrderStatus($x, true)?>
                     <?
                  }
                  ?>
               </td>
               <?
            }
            else
            {  ?>
               <td class="content_row" colspan="2">&nbsp;</td>
               <?
            }
            ?>
            <td class="content_rowl" valign="top">Vendedor</td>
            <td class="content_row" valign="top">
               <select class="text" style="width:375px" name="sql_seller" id="sql_seller" onmousedown="markfield(this,0)" onblur="markfield(this,1)">
                  <option value="">&lt; <?=$_LANG["FORM"]["OPTION"][0]?> &gt;</option>
                  <?
                  foreach($sellers as $seller)
                  {  ?>
                     <option value="<?=$seller["id"]?>"
                     <? if($seller["id"] == $_SESSION[$_sesmodulename]["sql_seller"]) echo "selected"?>><?=$seller["user_firstname"]?> <?=$seller["user_lastname"]?></option>
                     <?
                  }
                  ?>
               </select>
            </td>
        </tr>
         <tr>
            <td class="content_row" align="right" colspan="4">
               <table border="0" cellpadding="0" cellspacing="0" width="270">
               <tr>
                  <td align="right">
                     <?
                     if((int)$_SESSION[$_sesmodulename]["search_active"])
                        printButton("Resetear", "postnav", "index.php?mid={$_REQUEST["mid"]}&searchexec=reset", "", "arrow-circle-double-135", 130);
                     ?>
                  </td>
                  <td align="right">
                     <?
                     printButton("Buscar", "postnav_save", "javascript: deactivateFormChange()", "submitForm(document.xform_itemsearch)", "magnifier", 130);
                     $_SESSION["_SUBMITBTN"] = 1;
                     ?>
                  </td>
               </tr>
               </table>
            </td>
         </tr>
         </table>
         <?=Nifty_printF(false)?>
         </form>
      </td>
   </tr>

   <tr>
      <td>
         <?=Nifty_printH("box1", "980")?>
         <?
         printPageCounts($_SESSION[$_sesmodulename]["rows_per_page"], $itemcount, $_SESSION[$_sesmodulename]["page"]);
         ?>
         <table border="0" cellpadding="3" cellspacing="0" width="100%">
         <colgroup>
            <col width="55">
            <col>
            <col>
            <col>
            <col>
            <col>
            <col>
            <col width="65">
         </colgroup>
         <tr>
            <td class="content_tbl_subheader"><?=printSortLink($_sesmodulename, $_sortlinks, 0)?></td>
            <td class="content_tbl_subheader"><?=printSortLink($_sesmodulename, $_sortlinks, 1)?></td>
            <td class="content_tbl_subheader"><?=printSortLink($_sesmodulename, $_sortlinks, 2)?></td>
            <td class="content_tbl_subheader"><?=printSortLink($_sesmodulename, $_sortlinks, 3)?></td>
            <td class="content_tbl_subheader"><?=printSortLink($_sesmodulename, $_sortlinks, 4)?></td>
            <td class="content_tbl_subheader"><?=printSortLink($_sesmodulename, $_sortlinks, 5)?></td>
            <td class="content_tbl_subheader"><?=printSortLink($_sesmodulename, $_sortlinks, 6)?></td>
            <td class="content_tbl_subheader" align="center">Opciones</td>
         </tr>
         <?

         //----------------------------------------------------------------------------------
         for($x = 0; $x < count($orders) && $orders != false; $x++)
         {
            $_SESSION[$_sesmodulename]["FLW"][$orders[$x]["id"]]["L"] = (int)$orders[($x -1)]["id"];
            $_SESSION[$_sesmodulename]["FLW"][$orders[$x]["id"]]["N"] = (int)$orders[($x +1)]["id"];

            $statimg = "";
            switch((int)$orders[$x]["req_status"])
            {
               case 1: $statimg = "red_active.gif"; break;
               case 2: $statimg = "green_active.gif"; break;
               case 3: $statimg = "purple_active.gif"; break;
               case 4: $statimg = "blue_active.gif"; break;
            }

            /*
            unset($_RESGLBIDS);
            global $_RESGLBIDS;
            getOrdersRelations($CON, $orders[$x]["id"], false);

            $specicon = "";
            if(count($_RESGLBIDS) > 1)
               $specicon = "<img src='/images/menu/icons/arrow-continue-000-top.png' title='Nota de venta contectada' style='vertical-align:bottom'>&nbsp;";
            */
            
            ?>

            <tr bgcolor="<?=getRowColor($x)?>" onmouseover="mark(this, 0)" onmouseout="mark(this,1)">
               <td class="content_row">
                  <?
                  if($orders[$x]["req_status"] > 0 && $orders[$x]["req_hash"] != "")
                  {
                     if((int)$orders[$x]["req_isfabricate"])
                     {  ?>
                        <a href="javascript:void(0);" class="link"
                        onclick="document.all.idxifrsrc.src = './libs/modules/structure/document_file.php?type=0&hash=<?=$orders[$x]["req_hash"]?>&name=<?=$orders[$x]["req_number"]?>.pdf&path=../../../docs.order/'"><?=$orders[$x]["req_number"]?></a>
                        <?
                     }
                     else
                     {  ?>
                        <a href="javascript:void(0);" class="link"
                        onclick="document.all.idxifrsrc.src = './libs/modules/structure/document_file.php?type=0&hash=<?=$orders[$x]["id"]?>.<?=$orders[$x]["req_hash"]?>.pdf&name=<?=$orders[$x]["req_number"]?>.pdf&path=../../../docs.order/'"><?=$orders[$x]["req_number"]?></a>
                        <?
                     }
                  }
                  else
                     echo $orders[$x]["req_number"];
                  ?>
               </td>
               <?
                   $sql = "select count(1) as contador_cust from customer where cust_rut = '{$orders[$x]["cust_rut"]}' and cust_status > 0 ";
                   $con_rut = $CON->select($sql);
                   $con_rut = $con_rut[0];
                   $k_rut = "";
                   if((int)$con_rut["contador_cust"]>1)
                      $k_rut = " (".$con_rut["contador_cust"].")";
               ?>
               <td class="content_row"><?=$orders[$x]["cust_name"]?></td>
               <!--
               <td class="content_row"><?=$orders[$x]["company_short"]?></td>
               -->
               <td class="content_row"><?=$orders[$x]["Cartera"]?></td>
               <td class="content_row"><?=$orders[$x]["Nombre"]?></td>
               <td class="content_row">$ <?=printPrice($orders[$x]["req_total_netto"],0)?></td>
               <td class="content_row"><?=date('d.m.Y',$orders[$x]["req_crtdat"])?></td>
               <td class="content_row" align="center">
                  <img class="select" src="./images/content/<?=$statimg?>" title="Estado: <?=getOrderStatus($orders[$x]["req_status"])?>">
               </td>
               <td class="content_row" align="center">
                  <?
                  printButton($_LANG["FORM"]["BUTTON"][3], "postnav", "index.php?mid={$_REQUEST["mid"]}&exec=edit&id={$orders[$x]["id"]}", "button-error", "pencil");
                  ?>
               </td>
         
            </tr>
            <?
         }

         if(!$x)
         {  ?>
            <tr bgcolor="<?=getRowColor(0)?>">
               <td class="content_row" colspan="7" align="center">
                  <br>
                  <b class="msg_save_err">No hay datos disponibles.</b>
                  <br><br>
               </td>
            </tr>
            <?
         }
         ?>
         </table>
         <?
         printPageCounts($_SESSION[$_sesmodulename]["rows_per_page"], $itemcount, $_SESSION[$_sesmodulename]["page"]);
         ?>
         <?=Nifty_printF()?>
         <br>
      </td>
   </tr>
   </table>
   <iframe id="idxifrsrc" height="0" width="0" frameborder="0"></iframe>
   <?
}