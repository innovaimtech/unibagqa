<?
//----------------------------------------------------------------------------------
// Author:        1BIT LTDA
// Copyright:     2011 by 1BIT LTDA. All Rights Reserved.
// Any unauthorized redistribution, reselling, modifying or reproduction of part
// or all of the contents in any form is strictly prohibited.
//----------------------------------------------------------------------------------

if($_REQUEST["subcatexec"] == "")
   $_REQUEST["subcatexec"] = "basic";

if($_REQUEST["id"] != "")
{
   $sql = " select req_number
            from offers 
            where
            id = {$_REQUEST["id"]} ";
   $title = $CON->select($sql);
   
   $title = "Cambiar cotizaci�n: {$title[0]["req_number"]}";
}
else
   $title = "Agregar cotizaci�n:";
?>
<table border="0" cellpadding="0" cellspacing="0" width="980">
<tr>
   <td height="30"><b class="content_header"><?=$title?></b></td>
   <td align="right"><div id="idx_status_msg"><?=$savemsg?></div></td>
</tr>
<tr>
   <td class="content_headerline" colspan="2">&nbsp;</td>
</tr>
</table>
<input type="hidden" name="idx_redirect_id" value="<?=$_REQUEST["id"]?>">
<?=Nifty_printH("boxopt_t", "980")?>
<table border="0" class="content_table" cellpadding="0" cellspacing="0" width="100%">
<tr>
   <td width="20%" style="padding-right:5px">
      <?
      if($_REQUEST["subcatexec"] == "basic")
         $btype = "postnav_act";
      else
         $btype = "postnav";

      printButton("Datos b�sicos", $btype, "index.php?mid={$_REQUEST["mid"]}&exec={$_REQUEST["exec"]}&subcatexec=basic&id={$_REQUEST["id"]}&user_pricesell_perm={$_REQUEST["user_pricesell_perm"]}", "", "cookies");
      ?>
   </td>
   <td class="content_row_clear">&nbsp;</td>
   <?
   if($_REQUEST["id"] != "")
   {  ?>
      <td width="110" align="right" style="padding-right:5px">
         <?
         //printButton("Clonear Cotizaci�n", "postnav", "javascript:voic(0)", "if(askDel('')) { location.href='index.php?mid={$_REQUEST["mid"]}&exec={$_REQUEST["exec"]}&subcatexec=basic&id={$_REQUEST["id"]}&clonegen=1'; }", "cards", 160);
         printButton("Clonear Cotizaci�n", "postnav", "javascript:voic(0)", "showFancybox('/libs/modules/orders_offers/fancy.clone.php?mid={$_REQUEST["mid"]}&id={$_REQUEST["id"]}', 'iframe', 500, 160, 'no')", "cards", 160);
         ?>
      </td>
      <?
   }
   ?>
   <td width="110" align="right" style="padding-right:5px">
      <?
      if($_REQUEST["id"] != "")
         printButton("Anexos", "postnav", "javascript:void(0)", "showFancybox('/libs/modules/docs_management/overview.php?mode=orders_offers&id={$_REQUEST["id"]}', 'iframe', 850, 450, 'auto')", "scanner--plus", 110);
      ?>
   </td>
   <?
   if((int)$_SESSION[$_sesmodulename]["FLW"][$_REQUEST["id"]]["L"])
   {  ?>
      <td class="content_row_clear" width="53" style="padding-right:5px">
      <?
      printButton("", "postnav", "index.php?mid={$_REQUEST["mid"]}&exec=edit&id={$_SESSION[$_sesmodulename]["FLW"][$_REQUEST["id"]]["L"]}", "", "arrow-180", 53);
      ?>
      </td>
      <?
   }
   if((int)$_SESSION[$_sesmodulename]["FLW"][$_REQUEST["id"]]["N"])
   {  ?>
      <td class="content_row_clear" width="53" style="padding-right:2px">
      <?
      printButton("", "postnav", "index.php?mid={$_REQUEST["mid"]}&exec=edit&id={$_SESSION[$_sesmodulename]["FLW"][$_REQUEST["id"]]["N"]}", "", "arrow", 53);
      ?>
      </td>
      <?
   }
   ?>
</tr>
</table>
<?=Nifty_printF(false)?>
<br>
<?
//----------------------------------------------------------------------------------
if($_REQUEST["subcatexec"] == "basic")
   require_once("data.basic.php");
?>