<?php
session_start(); // Iniciar sesi�n

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["id_contacto"])) {
    $_SESSION["id_contacto"] = $_POST["id_contacto"]; // Guardar en sesi�n
    echo "ID guardado en sesi�n: " . htmlspecialchars($_SESSION["id_contacto"]);
} else {
    echo "No se recibi� ning�n ID.";
}
?>
