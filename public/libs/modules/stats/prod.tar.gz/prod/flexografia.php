<?
//----------------------------------------------------------------------------------
// Author:        1BIT LTDA
// Copyright:     2023 by 1BIT LTDA. All Rights Reserved.
// Any unauthorized redistribution, reselling, modifying or reproduction of part
// or all of the contents in any form is strictly prohibited.
//----------------------------------------------------------------------------------

//----------------------------------------------------------------------------------
$_sesmodulename         = "stats_prodflexo";
$_sesbasefilterstatus   = "0";
$_sesbaseorderby        = "2";
$_sesbaseordersort      = "";
$_sortlinks             = Array();

unset($_SESSION["STATS"][$_sesmodulename]);

//----------------------------------------------------------------------------------
resetOverviewSession($_sesmodulename);

//----------------------------------------------------------------------------------
if($_REQUEST["subexec"] == "search")
{
   $_SESSION[$_sesmodulename]["sql_month1"]        = trim($_REQUEST["sql_month1"]);
   $_SESSION[$_sesmodulename]["sql_month2"]        = trim($_REQUEST["sql_month2"]);
   $_SESSION[$_sesmodulename]["sql_year1"]         = trim($_REQUEST["sql_year1"]);
   $_SESSION[$_sesmodulename]["sql_year2"]         = trim($_REQUEST["sql_year2"]);
   $_SESSION[$_sesmodulename]["sql_selmode"]       = (int)$_REQUEST["sql_selmode"];
   $_SESSION[$_sesmodulename]["sql_date"]          = trim($_REQUEST["sql_date"]);
   $_SESSION[$_sesmodulename]["sql_date_pfrom"]    = trim($_REQUEST["sql_date_pfrom"]);
   $_SESSION[$_sesmodulename]["sql_date_pto"]      = trim($_REQUEST["sql_date_pto"]);
   $_SESSION[$_sesmodulename]["sql_xstate"]        = (int)$_REQUEST["sql_xstate"];
   $_SESSION[$_sesmodulename]["sql_plantaid"]      = (int)$_REQUEST["sql_plantaid"];
   $_SESSION[$_sesmodulename]["sql_equipotypeid"]  = (int)$_REQUEST["sql_equipotypeid"];
   $_SESSION[$_sesmodulename]["sql_equipoid"]      = (int)$_REQUEST["sql_equipoid"];
   $_SESSION[$_sesmodulename]["sql_customer"]      = (int)$_REQUEST["sql_customer"];
   $_SESSION[$_sesmodulename]["sql_number"]        = trim(addslashes($_REQUEST["sql_number"]));
   $_SESSION[$_sesmodulename]["sql_fab_design_name"] = trim(addslashes($_REQUEST["sql_fab_design_name"]));
   $_SESSION[$_sesmodulename]["page"]              = 0;
   $_SESSION[$_sesmodulename]["search_active"]     = 1;
}

//----------------------------------------------------------------------------------
if(!(int)$_SESSION[$_sesmodulename]["sql_selmode"])
   $_SESSION[$_sesmodulename]["sql_selmode"] = 1;

//----------------------------------------------------------------------------------
if($_SESSION[$_sesmodulename]["sql_month1"] == "")
{
   $_SESSION[$_sesmodulename]["sql_month1"]  = (int)date('m',time());
   $_SESSION[$_sesmodulename]["sql_year1"]   = (int)date('Y',time());
   $_SESSION[$_sesmodulename]["sql_month2"]  = (int)date('m',time());
   $_SESSION[$_sesmodulename]["sql_year2"]   = (int)date('Y',time());
}
if($_SESSION[$_sesmodulename]["sql_date"] == "")
   $_SESSION[$_sesmodulename]["sql_date"] = date('d.m.Y');
if($_SESSION[$_sesmodulename]["sql_date_pfrom"] == "")
{
   $_SESSION[$_sesmodulename]["sql_date_pfrom"] = date('d.m.Y', time());
   $_SESSION[$_sesmodulename]["sql_date_pto"]   = date('d.m.Y', time() + (86400 * 7));
}

//----------------------------------------------------------------------------------
if($_SESSION[$_sesmodulename]["sql_selmode"] == 1)
{
   $datearr       = explode(".", $_SESSION[$_sesmodulename]["sql_date"]);
   $sql_datefrom  = mktime(0, 0, 0, $datearr[1], $datearr[0], $datearr[2]);
   $sql_dateto    = mktime(23, 59, 59, $datearr[1], $datearr[0], $datearr[2]);
}
elseif($_SESSION[$_sesmodulename]["sql_selmode"] == 2)
{
   $sql_datefrom  = mktime(0, 0, 0, $_SESSION[$_sesmodulename]["sql_month1"], 1, $_SESSION[$_sesmodulename]["sql_year1"]);
   $sql_dateto    = mktime(23, 59, 59, $_SESSION[$_sesmodulename]["sql_month2"], 1, $_SESSION[$_sesmodulename]["sql_year2"]);
   $datedays      = date('t', $sql_dateto);
   $sql_dateto    = mktime(23, 59, 59, $_SESSION[$_sesmodulename]["sql_month2"], $datedays, $_SESSION[$_sesmodulename]["sql_year2"]);
}
elseif($_SESSION[$_sesmodulename]["sql_selmode"] == 3)
{
   $datearr       = explode(".", $_SESSION[$_sesmodulename]["sql_date_pfrom"]);
   $sql_datefrom  = mktime(0, 0, 0, $datearr[1], $datearr[0], $datearr[2]);
   $datearr       = explode(".", $_SESSION[$_sesmodulename]["sql_date_pto"]);
   $sql_dateto    = mktime(23, 59, 59, $datearr[1], $datearr[0], $datearr[2]);
}

//----------------------------------------------------------------------------------
prepareOverviewSession($_sesmodulename, $_sesbasefilterstatus, $_sesbaseorderby, $_sesbaseordersort, 200);

//----------------------------------------------------------------------------------
$plantas = getPlantas($CON);
if(!(int)$_SESSION[$_sesmodulename]["sql_plantaid"])
   $_SESSION[$_sesmodulename]["sql_plantaid"] = $plantas[0]["id"];

    $sql = "select t9.req_production_initdate       As Ingreso
                , t9.req_number                    As NCC
                , t10.item_amount                  As CantBolsa
                , t4.prd_number                    As NROT
                , t12.cust_name                    As Cliente
                , t11.item_title                   As TipoBolsa
                , t10.fab_med_width                As Ancho
                , t10.fab_med_height               As Alto
                , t10.fab_med_fuelle               As Fuelle
                , t11.item_number_prod             as CodigoPrd
                , t11.item_title                   as Producto
                , ''                               as CorteDeBolsa
                , t10.fab_med_width                as AnchoBolsa
                , t10.fab_med_height               as AltoFrenteBolsa
                , t10.fab_med_height               as AltoDorsoBolsa
                , 0                                as MedidaDoblezSuperior
                , t10.fab_med_fuelle               as MedidaFuelleBolsa
                , t10.fab_mat_fabric_color         as CodigoColor
                , t10.fab_mat_gramms               as Gramaje
                , t10.fab_type                     as CodigoTela
                , t10.item_compdesc                as PieImprenta
                , t9.req_dsgnchk_barcode_act       as CodigoBarraSN
                , t10.item_sellprice_barcodenumber as CodigoBarra
                , ''                               as AlarmaSN
                , 0                                as NumeroAlarma
                , t9.req_solic_devprints_cc        as ImprDesarrollo
                , t11.item_prodcalc_fuelle_act
            from prod_worker_ot t1
               INNER JOIN prod_agenda t2        ON t1.wok_ag_id = t2.id
               INNER JOIN prod_worker_init t3   ON t1.wok_init_id = t3.id
               INNER JOIN prod_header t4        ON t2.ag_prdid = t4.id
               LEFT OUTER JOIN equipo t7        ON t3.win_equipoid = t7.id
               LEFT OUTER JOIN equipo_type t8   ON t7.equipo_type_id = t8.id
               INNER JOIN orders t9             ON t2.ag_reqid = t9.id
               INNER JOIN orders_items t10      ON t9.id = t10.req_id
               INNER JOIN item t11              ON t10.item_id = t11.id
               LEFT OUTER JOIN customer t12     ON t9.req_cust_id = t12.id 
               INNER JOIN prod_worker_ot_events t13 on t1.id = t13.evt_prod_worker_otid
            where t1.wok_crtdat     between {$sql_datefrom} and {$sql_dateto} 
                  and t4.prd_plantaid   = 1 
                  and t1.wok_status > 0 
                  and (select count(*) 'cc'
                        from prod_worker_ot_autocontrol t99
                        where t99.ctr_init_id = t1.id) > 0
            ";
 
/*   
$sql = " select t1.id
              , t1.req_number
              , t1.req_production_initdate
              , t2.user_lastname
              , t2x.item_title
              , t6.fab_med_width
              , t6.fab_med_height
              , t6.fab_med_fuelle
              , t6.fab_type
              , t6.fab_printtype
              , t7.supp_short
              , t6.fab_mat_fabric_color
              , t6.fab_mat_manilla_color
              , t6.fab_print_colors_front_1
              , t6.fab_print_colors_back_1
              , t6.fab_print_colors_front_2
              , t6.fab_print_colors_back_2
              , t6.fab_print_colors_front_3
              , t6.fab_print_colors_back_3
              , t6.fab_print_colors_front_4
              , t6.fab_print_colors_back_4
              , t6.fab_print_colordesc_1
              , t6.fab_print_colordesc_2
              , t6.fab_print_colordesc_3
              , t6.fab_print_colordesc_4
              , t6.fab_manilla_length
              , t1.req_dsgnchk_pieimprenta_act
              , t1.req_dsgnchk_barcode_act
              , t8.user_lastname 'designername'
              , t1.req_cliche_peli_recep_dat
              , t1.req_solic_devprints_cc
              , t1.req_operador_tela_width
              , t1.req_operador_mermaperc
              , t2x.item_prodcalc_fuelle_act
              , t1.req_solic_devprints_poltype
              , t1.req_crtdat
         from orders t1
         LEFT OUTER JOIN user t2          ON t1.req_userid_seller = t2.id
         INNER JOIN orders_items t6       ON t1.id = t6.req_id
         INNER JOIN item t2x              ON t6.item_id = t2x.id
         LEFT OUTER JOIN supplier t7      ON t1.req_solic_supp_id = t7.id
         LEFT OUTER JOIN user t8          ON t1.req_design_blocked_uid = t8.id
         where
         t1.req_status                 > 1 and
         t1.req_isfabricate            = 1 and
         t1.req_production_act         > 0 ";
*/

if($_SESSION[$_sesmodulename]["sql_number"] != "")
   $sql .= " and t1.req_number = '{$_SESSION[$_sesmodulename]["sql_number"]}' ";
/* if((int)$_SESSION[$_sesmodulename]["sql_customer"])
   $sql .= " and t1.req_cust_id = {$_SESSION[$_sesmodulename]["sql_customer"]} ";
if($_SESSION[$_sesmodulename]["sql_fab_design_name"] != "")
   $sql .= " and t6.fab_design_name like '%{$_SESSION[$_sesmodulename]["sql_fab_design_name"]}%' ";
*/
$sql .=" order by t1.req_production_initdate, t1.req_number";
// echo($sql);
$data = $CON->select($sql);

$resdata = Array();
for($x = 0; $x < count($data) && $data != false; $x++)
{
   $row = $data[$x];

   
   if((int)$row["item_prodcalc_fuelle_act"])
      $param_medida = (int)$row["fab_med_width"] + (int)$row["fab_med_fuelle"];
   else
      $param_medida = (int)$row["fab_med_width"];
   
   $events = getProdEvents($CON, 0, 0, 0, 0, $row["id"], (int)$_SESSION[$_sesmodulename]["sql_equipotypeid"], (int)$_SESSION[$_sesmodulename]["sql_equipoid"]);

   for($y = 0; $y < count($events) && $events != false; $y++)
   {
      if($events[$y]["evt_type"] == "prod" && (int)$events[$y]["evt_amount"] &&
         ((int)$events[$y]["equipo_prod_isprinter_seri"] || (int)$events[$y]["equipo_prod_isprinter_flexo"]))
      {
         // echo "<pre>";
         // print_r($row);
         // print_r($events[$y]);

         $sql = " select *
                  from equipo_params
                  where
                  param_equipo_id = {$events[$y]["ag_equipo_id"]} and
                  param_medida    >= {$param_medida}
                  order by param_medida asc
                  LIMIT 0,1";
         $equipo_params = $CON->select($sql);
         $equipo_params = $equipo_params[0];

         // print_r($equipo_params);
         // echo "<hr>";

         $corte_m2 = 0;
         $corte_z = 0;
         if((int)$events[$y]["equipo_prod_isprinter_seri"])
         {
            $corte_m2 = (float)$equipo_params["param_corte"];
            $corte_z  = (int)$equipo_params["param_z"];
         }
         elseif((int)$events[$y]["equipo_prod_isprinter_flexo"])
         {
            if($row["req_solic_devprints_poltype"] == "pol284")
            {
               $corte_m2 = (float)$equipo_params["param_poly28"];
               $corte_z  = (int)$equipo_params["param_z"];
            }
            elseif($row["req_solic_devprints_poltype"] == "pol170")
            {
               $corte_m2 = (float)$equipo_params["param_poly17"];
               $corte_z  = (int)$equipo_params["param_z"];
            }
         }

         // $corte_m2      = (float)$equipo_params["param_corte"];
         // $corte_z       = (int)$equipo_params["param_z"];
         $mlin_prog     = round($events[$y]["ag_amount"] * $corte_m2);
         $mlin_impresos = round($events[$y]["evt_amount"] * $corte_m2);
         $mlin_user     = $events[$y]["wrk_lastname"];

         if(!(int)$events[$y]["equipo_prod_isprinter_flexo"])
            $corte_z = 0;

         $baserow                   = $row;
         $baserow["corte_z"]        = $corte_z;
         $baserow["mlin_prog"]      = $mlin_prog;
         $baserow["mlin_impresos"]  = $mlin_impresos;
         $baserow["mlin_user"]      = $mlin_user;
         $resdata[]                 = $baserow;
      }
   }
}
$data = $resdata;

//----------------------------------------------------------------------------------
$sql = " select *
         from equipo_type
         where
         type_ant_status > 0 and
         type_ant_prod_dabl = 0
         order by type_ant_title";
$selequipotypes = $CON->select($sql);
$temp = Array();
for($x = 0; $x < count($selequipotypes) && $selequipotypes != false; $x++)
{
   $sql = " select *
            from equipo
            where
            equipo_status     > 0 and
            equipo_type_id    = {$selequipotypes[$x]["id"]} and
            equipo_prod_dabl = 0
            order by equipo_name";
   $equipos = $CON->select($sql);
   if(count($equipos) && $equipos != false)
   {
      $_SELEQUIPOTYPES[$selequipotypes[$x]["id"]] = $selequipotypes[$x]["type_ant_title"];

      foreach($equipos AS $equipo)
      {
         if((int)$_SESSION[$_sesmodulename]["sql_equipotypeid"] && (int)$_SESSION[$_sesmodulename]["sql_equipotypeid"] == $equipo["equipo_type_id"])
         {
            $_SELEQUIPOS[$equipo["id"]] = $equipo["equipo_name"];
         }
      }
   }
}

//----------------------------------------------------------------------------------
$sql = " select t1.id, t1.equipo_name
         from equipo t1
         where
         t1.equipo_status > 0 and
         t1.equipo_planta_id = {$_SESSION[$_sesmodulename]["sql_plantaid"]} and
         t1.equipo_prod_dabl = 0 ";
if((int)$_SESSION[$_sesmodulename]["sql_equipotypeid"])
   $sql .= " and t1.equipo_type_id = {$_SESSION[$_sesmodulename]["sql_equipotypeid"]} ";
if((int)$_SESSION[$_sesmodulename]["sql_equipoid"])
   $sql .= " and t1.id = {$_SESSION[$_sesmodulename]["sql_equipoid"]} ";
$sql .= " order by 2";
$equipos = $CON->select($sql);

//----------------------------------------------------------------------------------
$plantas = getPlantas($CON);
if(!(int)$_SESSION[$_sesmodulename]["sql_plantaid"])
   $_SESSION[$_sesmodulename]["sql_plantaid"] = $plantas[0]["id"];

//----------------------------------------------------------------------------------
?>
<div style="display:none">
   <select class="text" name="sql_plantaid" id="sql_plantaid" style="width:100%"
   onmousedown="markfield(this,0)" onblur="markfield(this,1)"
   onchange="jqLoadPlantaEquipoTypes(this.value)">
      <option value="">&lt; <?=$_LANG["FORM"]["OPTION"][0]?> &gt;</option>
      <?
      foreach ($plantas as $planta)
      {  ?>
         <option value="<?=$planta["id"]?>" <? if($planta["id"] == $_SESSION[$_sesmodulename]["sql_plantaid"]) echo "selected"?>>
            <?=$planta["planta_name"]?>
         </option>
         <?
      }
      ?>
   </select>
</div>
<style type="text/css"><!-- @import url(./libs/jscripts/datepicker/datepicker.css); //--></style>
<script language="JavaScript" src="./libs/jscripts/datepicker/datepicker.js"></script>
<table border="0" cellpadding="0" cellspacing="0" width="980">
<tr>
   <td height="30"><b class="content_header">Informe de Flexografias</b></td>
   <td align="right" class="content_row_clear">&nbsp;</td>
</tr>
<tr>
   <td class="content_headerline" colspan="2">&nbsp;</td>
</tr>
</table>
<table border="0" cellpadding="0" cellspacing="0" width="100%">
<tr>
   <td>
      <form action="index.php" method="post" name="xform_itemsearch" class="fokusfirst">
      <input type="hidden" name="subexec" value="search">
      <input type="hidden" name="mid" value="<?=$_REQUEST["mid"]?>">
      <input type="hidden" name="subcatexec" value="<?=$_REQUEST["subcatexec"]?>">
      <input type="hidden" name="id" value="<?=$_REQUEST["id"]?>">
      <input type="hidden" name="exec" value="<?=$_REQUEST["exec"]?>">
      <input type="hidden" name="printpdf" value="0">
      <input type="hidden" name="printxls" value="0">
      <?=Nifty_printH("box2", "980")?>
      <table border="0" class="content_table" cellpadding="3" cellspacing="0" width="100%">
      <colgroup>
         <col width="80">
         <col>
         <col width="80">
         <col width="400">
      </colgroup>
      <tr>
         <td class="content_tbl_header" colspan="4">Opciones de b�squeda</td>
      </tr>
      <tr>
         <td class="content_rowl">Periodo</td>
         <td class="content_row">
            <table border="0" class="content_table" cellpadding="0" cellspacing="0">
            <tr>
               <td class="content_row_clear" width="70">
                  <input type="radio" name="sql_selmode" value="2"
                  onclick="document.getElementById('idx_selmode1').style.display='none';
                           document.getElementById('idx_selmode2').style.display='';
                           document.getElementById('idx_selmode3').style.display='none';"
                  <? if($_SESSION[$_sesmodulename]["sql_selmode"] == 2) echo "checked"?>> Meses
               </td>
               <td class="content_row_clear" width="205" id="idx_selmode2" <? if($_SESSION[$_sesmodulename]["sql_selmode"] != 2) echo "style='display:none'"?>>
                  <nobr>
                  <select class="text" name="sql_month1" id="sql_month1"
                  onmousedown="markfield(this,0)" onblur="markfield(this,1)">
                     <?
                     for($x = 1; $x <= 12; $x++)
                     {
                        $dsp_month = $x;
                        if($dsp_month < 10)
                           $dsp_month = "0{$dsp_month}";
                        ?>
                        <option value="<?=$x?>"
                        <? if($x == $_SESSION[$_sesmodulename]["sql_month1"]) echo "selected" ?>><?=$dsp_month?></option>
                        <?
                     }
                     ?>
                  </select>
                  <select class="text" name="sql_year1" id="sql_year1"
                  onmousedown="markfield(this,0)" onblur="markfield(this,1)">
                     <?
                     $startyear  = date('Y') -20;
                     $endyear    = date('Y');

                     for($x = $startyear; $x <= $endyear; $x++)
                     {
                        ?>
                        <option value="<?=$x?>"
                        <? if($x == $_SESSION[$_sesmodulename]["sql_year1"]) echo "selected" ?>><?=$x?></option>
                        <?
                     }
                     ?>
                  </select>
                  &nbsp;-&nbsp;
                  <select class="text" name="sql_month2" id="sql_month2"
                  onmousedown="markfield(this,0)" onblur="markfield(this,1)">
                     <?
                     for($x = 1; $x <= 12; $x++)
                     {
                        $dsp_month = $x;
                        if($dsp_month < 10)
                           $dsp_month = "0{$dsp_month}";
                        ?>
                        <option value="<?=$x?>"
                        <? if($x == $_SESSION[$_sesmodulename]["sql_month2"]) echo "selected" ?>><?=$dsp_month?></option>
                        <?
                     }
                     ?>
                  </select>
                  <select class="text" name="sql_year2" id="sql_year2"
                  onmousedown="markfield(this,0)" onblur="markfield(this,1)">
                     <?
                     $startyear  = date('Y') -20;
                     $endyear    = date('Y');

                     for($x = $startyear; $x <= $endyear; $x++)
                     {
                        ?>
                        <option value="<?=$x?>"
                        <? if($x == $_SESSION[$_sesmodulename]["sql_year2"]) echo "selected" ?>><?=$x?></option>
                        <?
                     }
                     ?>
                  </select>
                  </nobr>
               </td>
               <td class="content_row_clear" width="50">
                  <input type="radio" name="sql_selmode" value="1"
                  onclick="document.getElementById('idx_selmode1').style.display='';
                           document.getElementById('idx_selmode2').style.display='none';
                           document.getElementById('idx_selmode3').style.display='none';"
                  <? if($_SESSION[$_sesmodulename]["sql_selmode"] == 1) echo "checked"?>> Dia
               </td>
               <td class="content_row_clear" width="110" id="idx_selmode1" <? if($_SESSION[$_sesmodulename]["sql_selmode"] != 1) echo "style='display:none'"?>>
                  <nobr>
                  <input type="text" style="width:80px" id="sql_date" name="sql_date"
                  class="text format-d-m-y divider-dot highlight-days-67 no-locale no-transparency"
                  onfocus="markfield(this,0)" onblur="markfield(this,1)"
                  value="<?=$_SESSION[$_sesmodulename]["sql_date"]?>">
                  </nobr>
               </td>
               <td class="content_row_clear" width="75">
                  <input type="radio" name="sql_selmode" value="3"
                  onclick="document.getElementById('idx_selmode1').style.display='none';
                           document.getElementById('idx_selmode2').style.display='none';
                           document.getElementById('idx_selmode3').style.display='';"
                  <? if($_SESSION[$_sesmodulename]["sql_selmode"] == 3) echo "checked"?>> Periodo
               </td>
               <td class="content_row_clear" width="180" id="idx_selmode3" <? if($_SESSION[$_sesmodulename]["sql_selmode"] != 3) echo "style='display:none'"?>>
                  <nobr>
                  <input type="text" style="width:75px" id="sql_date_pfrom" name="sql_date_pfrom"
                  class="text format-d-m-y divider-dot highlight-days-67 no-locale no-transparency"
                  onfocus="markfield(this,0)" onblur="markfield(this,1)"
                  value="<?=$_SESSION[$_sesmodulename]["sql_date_pfrom"]?>">
                  -
                  <input type="text" style="width:75px" id="sql_date_pto" name="sql_date_pto"
                  class="text format-d-m-y divider-dot highlight-days-67 no-locale no-transparency"
                  onfocus="markfield(this,0)" onblur="markfield(this,1)"
                  value="<?=$_SESSION[$_sesmodulename]["sql_date_pto"]?>">
                  </nobr>
               </td>
            </tr>
            </table>
         </td>
         <td class="content_rowl">N� CC</td>
         <td class="content_row">
            <input type="text" class="text" style="width:100%"
            name="sql_number" value="<?=$_SESSION[$_sesmodulename]["sql_number"]?>"
            onfocus="markfield(this,0)" onblur="markfield(this,1)">
         </td>
      </tr>
      <tr>
         <td class="content_rowl">Cliente</td>
         <td class="content_row"><? printOverviewCustomerSelect($_sesmodulename) ?></td>
         <td class="content_rowl">Dise�o</td>
         <td class="content_row">
            <input type="text" class="text" style="width:375px"
            name="sql_fab_design_name" value="<?=$_SESSION[$_sesmodulename]["sql_fab_design_name"]?>"
            onfocus="markfield(this,0)" onblur="markfield(this,1)">
         </td>
      </tr>
      <tr>
         <td class="content_rowl">Tipo m�quina</td>
         <td class="content_row">
            <select class="text" style="width:375px" name="sql_equipotypeid" id="sql_equipotypeid"
            onmousedown="markfield(this,0)" onblur="markfield(this,1)"
            onchange="jqLoadPlantaEquipos(this.value)">
               <option value="">&lt; <?=$_LANG["FORM"]["OPTION"][0]?> &gt;</option>
               <?
               foreach(array_keys($_SELEQUIPOTYPES) AS $etypeid)
               {  ?>
                  <option value="<?=$etypeid?>"
                  <? if($etypeid == $_SESSION[$_sesmodulename]["sql_equipotypeid"]) echo "selected"?>><?=$_SELEQUIPOTYPES[$etypeid]?></option>
                  <?
               }
               ?>
            </select>
         </td>
         <td class="content_rowl">M�quina</td>
         <td class="content_row">
            <select class="text" style="width:100%" name="sql_equipoid" id="sql_equipoid"
            onmousedown="markfield(this,0)" onblur="markfield(this,1)">
               <option value="">&lt; <?=$_LANG["FORM"]["OPTION"][0]?> &gt;</option>
               <?
               foreach(array_keys($_SELEQUIPOS) AS $eqid)
               {  ?>
                  <option value="<?=$eqid?>"
                  <? if($eqid == $_SESSION[$_sesmodulename]["sql_equipoid"]) echo "selected"?>><?=$_SELEQUIPOS[$eqid]?></option>
                  <?
               }
               ?>
            </select>
         </td>
      </tr>
      <tr>
         <td class="content_row" align="right" colspan="4">
            <table border="0" cellpadding="0" cellspacing="0" width="100%">
            <colgroup>
               <col width='132'>
               <col>
               <col width="132">
               <col width="132">
            </colgroup>
            <tr>
               <td type="hidden" align="left">
                  <?
                  if(count($data) > 0 && $data != false)
                  {
                     printButton("Imprimir PDF", "postnav", "javascript: deactivateFormChange()", "document.xform_itemsearch.printpdf.value='1';submitForm(document.xform_itemsearch)", "document-pdf", 130);
                     $_SESSION["_SUBMITBTN"] = 1;
                  }
                  ?>
               </td>
               <td align="left">
                  <?
                  if(count($data) > 0 && $data != false)
                  {
                     printButton("Generar XLS", "postnav", "javascript: deactivateFormChange()", "document.xform_itemsearch.printxls.value='1';submitForm(document.xform_itemsearch)", "document-excel", 130);
                     $_SESSION["_SUBMITBTN"] = 1;
                  }
                  ?>
               </td>
               <td align="right" style="padding-right:5px" width="1">
                  <?
                  if((int)$_SESSION[$_sesmodulename]["search_active"])
                  {
                     printButton("Resetear", "postnav", "index.php?mid={$_REQUEST["mid"]}&searchexec=reset", "", "arrow-circle-double-135", 130);
                  }
                  ?>
               </td>
               <td align="right" width="1">
                  <?
                  printButton("Buscar", "postnav_save", "javascript: deactivateFormChange()", "submitForm(document.xform_itemsearch)", "magnifier", 130);
                  $_SESSION["_SUBMITBTN"] = 1;
                  ?>
               </td>
            </tr>
            </table>
         </td>
      </tr>
      </table>
      <?=Nifty_printF(false)?>
      </form>
   </td>
</tr>
<tr>
   <td>
      <?=Nifty_printH("box1", "99%")?>
      <table border="0" cellpadding="3" cellspacing="0" width="100%">
      <colgroup>
      </colgroup>
      <tr>
         <td colspan="27" class="content_row_os" align="center">Informacion C.C.</td>
         <td colspan="16" class="content_row_os" align="center">Produccion</td>
         <td colspan="13" class="content_row_os" align="center">Programado y Producido</td>
         <td colspan="10" class="content_row_os" align="center">Materia Prima</td>
         <td colspan="18" class="content_row_os" align="center">Colores</td>
         <td class="content_row_os" align="center"> </td>
         <td colspan="4" class="content_row_os" align="center">Mermas</td>
         <td colspan="9" class="content_row_os" align="center">Eficiencia</td>
      </tr>
      <tr>
         <td class="content_rowl content_row_os" align="center">Fecha-Hora Ingreso CC</td>
         <td class="content_rowl content_row_os">Nro.CC</td>
         <td class="content_rowl content_row_os">Cantidad de Bolsas</td>
         <td class="content_rowl content_row_os">Nro OT</td>
         <td class="content_rowl content_row_os">Cliente</td>
         <td class="content_rowl content_row_os">Tipo Bolsa</td>
         <td class="content_rowl content_row_os">Formato Bolsa</td>
         <td class="content_rowl content_row_os">Codigo Producto</td>
         <td class="content_rowl content_row_os">Descripcion Producto</td>
         <td class="content_rowl content_row_os">Corte de Bolsa</td>
         <td class="content_rowl content_row_os">Ancho de Bolsa</td>
         <td class="content_rowl content_row_os">Alto Frente de Bolsa</td>
         <td class="content_rowl content_row_os">Alto Dorso de Bolsa</td>
         <td class="content_rowl content_row_os">Medida Doblez Superior</td>
         <td class="content_rowl content_row_os">Medida Fuelle de Bolsa</td>
         <td class="content_rowl content_row_os">Color Tela</td>
         <td class="content_rowl content_row_os">Codigo Color Tela</td>
         <td class="content_rowl content_row_os">Gramaje</td>
         <td class="content_rowl content_row_os">Ancho Bobina</td>
         <td class="content_rowl content_row_os">Codigo de Tela</td>
         <td class="content_rowl content_row_os">Cantidad de Bobinas</td>
         <td class="content_rowl content_row_os">Pie de Imprenta</td>
         <td class="content_rowl content_row_os">Codgo de Barraº</td>
         <td class="content_rowl content_row_os">Numero Codigo de Barra</td>
         <td class="content_rowl content_row_os">Alarma</td>
         <td class="content_rowl content_row_os">Numero de Alarma</td>
         <td class="content_rowl content_row_os">Impresiones al Desarrollo</td>

         <td class="content_rowl content_row_os">Nombre Maquina</td>
         <td class="content_rowl content_row_os">Nro Maquina</td>
         <td class="content_rowl content_row_os">Nombre Supervidor</td>
         <td class="content_rowl content_row_os">Rut Supervisor</td>
         <td class="content_rowl content_row_os">Fecha-Hora Inicio(Alistamiento)</td>
         <td class="content_rowl content_row_os">Fecha-Hora Fin(Alistamiento)</td>
         <td class="content_rowl content_row_os">Total Horas(Alistamiento)</td>
         <td class="content_rowl content_row_os">Fecha-Hora Inicio(Produccion)</td>
         <td class="content_rowl content_row_os">Fecha-Hora Fin(Produccion)</td>
         <td class="content_rowl content_row_os">Total Horas(Produccion)</td>
         <td class="content_rowl content_row_os">Turno</td>
         <td class="content_rowl content_row_os">Horas Turno</td>
         <td class="content_rowl content_row_os">Nombre Operador</td>	
         <td class="content_rowl content_row_os">Rut Operador</td>
         <td class="content_rowl content_row_os">Nombre Ayudante</td>
         <td class="content_rowl content_row_os">Rut Ayudante</td>

         <td class="content_rowl content_row_os">% Merma Programado</td>	
         <td class="content_rowl content_row_os">Total Programado Impresora(Contador)</td>
         <td class="content_rowl content_row_os">Total Programado Impresora(Metros/Lineales)</td>
         <td class="content_rowl content_row_os">Total Programado Impresora(Kgs)</td>	
         <td class="content_rowl content_row_os">Produccion Esperada (UN)</td>	
         <td class="content_rowl content_row_os">Total Producido Impresora(Contador/Turno)</td>	
         <td class="content_rowl content_row_os">Total Producido Impresora(Metros/Lineales)</td>	
         <td class="content_rowl content_row_os">Total Producido Impresora(Kgs)</td>	
         <td class="content_rowl content_row_os">Eficiencia Productiva(%)</td>	
         <td class="content_rowl content_row_os">Velocidad Maquina(Mts/Minutos)</td>	
         <td class="content_rowl content_row_os">Peso Unitario(gramos)</td>	
         <td class="content_rowl content_row_os">Tipo Clise</td>	
         <td class="content_rowl content_row_os">Altura Clise</td>

         <td class="content_rowl content_row_os">Ancho Bobina</td>	
         <td class="content_rowl content_row_os">Color Bobina</td>	
         <td class="content_rowl content_row_os">Codigo Color Bobina</td>	
         <td class="content_rowl content_row_os">Gramaje Bobina</td>
         <td class="content_rowl content_row_os">Estado Bobina(Nva/Usada)</td>	
         <td class="content_rowl content_row_os">Nro. Bobina Procesadas(Unidad)</td>	
         <td class="content_rowl content_row_os">Kilos Bobina Procesadas</td>	
         <td class="content_rowl content_row_os">Metros Lineales Bobina Procesadas(Mts/Lineales)</td>
         <td class="content_rowl content_row_os">Kilos Mermas</td>
         <td class="content_rowl content_row_os">% Merma</td>

         <td class="content_rowl content_row_os">Color 1 Frente</td>
         <td class="content_rowl content_row_os">Color 2 Frente</td>	
         <td class="content_rowl content_row_os">Color 3 Frente</td>	
         <td class="content_rowl content_row_os">Color 4 Frente</td>	
         <td class="content_rowl content_row_os">Color 5 Frente</td>	
         <td class="content_rowl content_row_os">Color 6 Frente</td>	
         <td class="content_rowl content_row_os">Color 1 Dorso</td>	
         <td class="content_rowl content_row_os">Color 2 Dorso</td>	
         <td class="content_rowl content_row_os">Color 3 Dorso</td>	
         <td class="content_rowl content_row_os">Color 4 Dorso</td>	
         <td class="content_rowl content_row_os">Color 5 Dorso</td>	
         <td class="content_rowl content_row_os">Color 6 Dorso</td>
         <td class="content_rowl content_row_os">Kgs Tinta Utilizada(Color 1)</td>
         <td class="content_rowl content_row_os">Kgs Tinta Utilizada(Color 2)</td>
         <td class="content_rowl content_row_os">Kgs Tinta Utilizada(Color 3)</td>
         <td class="content_rowl content_row_os">Kgs Tinta Utilizada(Color 4)</td>	
         <td class="content_rowl content_row_os">Kgs Tinta Utilizada(Color 5)</td>	
         <td class="content_rowl content_row_os">Kgs Tinta Utilizada(Color 6)</td>

         <td class="content_rowl content_row_os">Bobina Sobrante (Kgs)</td>	

         <td class="content_rowl content_row_os">Scraps Unidades(Alistamiento)</td>	
         <td class="content_rowl content_row_os">Scraps Kgs(Alistamiento)</td>	
         <td class="content_rowl content_row_os">Scraps Malas por Impresion(Unidades)</td>
         <td class="content_rowl content_row_os">Scraps Malas por Impresion(Kgs)</td>

         <td class="content_rowl content_row_os">Bobina Defectuosa(Unidad)</td>	
         <td class="content_rowl content_row_os">Bobina Defectuosa(Kgs)/td>	
         <td class="content_rowl content_row_os">Tiempo Productivo(Horas)</td>
         <td class="content_rowl content_row_os">Total Paros(Horas)</td>
         <td class="content_rowl content_row_os">Tiempo Neto Productivo</td>
         <td class="content_rowl content_row_os">Disponibilidad(%)</td>
         <td class="content_rowl content_row_os">Rendimiento(%)</td>
         <td class="content_rowl content_row_os">Calidad(%)</td>
         <td class="content_rowl content_row_os">OEE (%)</td>	
         
         <td class="content_rowl content_row_os">$ Producidos</td>
         <td class="content_rowl content_row_os">Observacion</td>

      </tr>
      <?
      for($x = 0; $x < count($data) && $data != false; $x++)
      {  ?>
         <tr bgcolor="<?=getRowColor($x)?>" onmouseover="mark(this, 0)" onmouseout="mark(this,1)">
            <td class="content_row_os"><?=date("d.m.Y H:i:s",$data[$x]["req_crtdat"])?></td> 
            <td class="content_row_os" align="center"><nobr><?=$data[$x]["req_number"]?></nobr></td>
            <td class="content_row_os" align="center"><nobr></nobr></td>
            <td class="content_row_os"><?=$data[$x]["mlin_user"]?>&nbsp;</td>
            <td class="content_row_os"><?=printPrice($data[$x]["mlin_prog"])?></td>
            <td class="content_row_os"><?=$data[$x]["req_solic_supp_seudonimo"]?>&nbsp;</td>
            <td class="content_row_os"><?=$data[$x]["corte_z"]?></td>
            <td class="content_row_os"><?=$data[$x]["req_solic_devprints_cc"]?></td>
            <td class="content_row_os"><?=(int)$data[$x]["req_operador_tela_width"]?></td>
            <td class="content_row_os"><?=printPrice($data[$x]["mlin_impresos"])?></td>
            <td class="content_row_os"><?=printPrice($data[$x]["req_operador_mermaperc"],2)?></td>
            <td class="content_row_os"><?=$data[$x]["designername"]?>&nbsp;</td>
         </tr>
         <?
         /*
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["req_number"]        = $data[$x]["req_number"];
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["mlin_user"]         = $data[$x]["mlin_user"];
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["mlin_prog"]         = printPrice($data[$x]["mlin_prog"]);
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["seudonimo"]         = $data[$x]["req_solic_supp_seudonimo"];
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["corte_z"]           = $data[$x]["corte_z"];
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["devprints_cc"]      = $data[$x]["req_solic_devprints_cc"];
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["tela_width"]        = (int)$data[$x]["req_operador_tela_width"];
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["mlin_impresos"]     = printPrice($data[$x]["mlin_impresos"]);
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["mermaperc"]         = printPrice($data[$x]["req_operador_mermaperc"],2);
         $_SESSION["STATS"][$_sesmodulename]["DATA"][$x]["designername"]      = $data[$x]["designername"];
         */
      }
      if(!$x)
      {  ?>
         <tr bgcolor="<?=getRowColor(0)?>">
            <td class="content_row" colspan="11" align="center">
               <br>
               <b class="msg_save_err">No hay datos disponibles.</b>
               <br><br>
            </td>
         </tr>
         <?
      }
      ?>
      </table>
      <?=Nifty_printF()?>
      <br>
   </td>
</tr>
</table>
</form>
<?
//----------------------------------------------------------------------------------
if($_REQUEST["printpdf"])
  $pdffile = doc_createStatsTrazaCC($CON);

if($_REQUEST["printxls"])
  $xlsfile = xls_createStatsTrazaCC($CON);

if($pdffile != "")
{
   $doctitle = "Trazabilidad-CC-".time().".pdf";
   $pdflink = "./libs/modules/structure/document_file.php?type=0&hash={$pdffile}.pdf&name={$doctitle}&path=../../../docs.print/";
   ?>
   <iframe height="0" width="0" frameborder="0" src="<?=$pdflink?>"></iframe>
   <?
}
if($xlsfile != "")
{
   $doctitle = "Trazabilidad-CC-".time().".xls";
   $xlslink = "./libs/modules/structure/document_file.php?type=0&hash={$xlsfile}.xls&name={$doctitle}&path=../../../docs.print/";
   ?>
   <iframe height="0" width="0" frameborder="0" src="<?=$xlslink?>"></iframe>
   <?
}
?>
<iframe id="idxifrsrc" height="0" width="0" frameborder="0"></iframe>
<?
$_SESSION["JSEXEC"] .= ';$("#obitpanel").html("");';
?>