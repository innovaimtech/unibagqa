<?
//----------------------------------------------------------------------------------
$sql_day    = (int)date("d");
$sql_month  = (int)date("m");
$sql_year   = (int)date("Y");
$_REQUEST["agid"] = (int)$_REQUEST["agid"];

//----------------------------------------------------------------------------------
if($_REQUEST["exec"] == "init")
{
   $sql = " select *
            from prod_worker_init
            where
            win_wrkid      = {$_SESSION["wrk_id"]} and
            win_plantaid   = {$_SESSION["user_planta_id"]}
            win_status     = 1";
   $hasopen = $CON->select($sql);
   $hasopen = $hasopen[0];
   if(!(int)$hasopen["id"])
   {
      $currtme                = time();
      $_REQUEST["equipoid"]   = (int)$_REQUEST["equipoid"];
      $_REQUEST["assid"]      = (int)$_REQUEST["assid"];
      
      $sql = " insert into prod_worker_init
               (win_crtdat, win_wrkid, win_status, win_plantaid, win_equipoid,
                win_ass_id, win_day, win_month, win_year)
               VALUES
               ({$currtme}, {$_SESSION["wrk_id"]}, 1, {$_SESSION["user_planta_id"]}, {$_REQUEST["equipoid"]},
                {$_REQUEST["assid"]}, {$sql_day}, {$sql_month}, {$sql_year})";
      $CON->no_result($sql);
   }        
}

//----------------------------------------------------------------------------------
if($_REQUEST["exec"] == "end")
{
   $hasopeninit = getProdOpenWorkerInit($CON, $_SESSION["wrk_id"], $_SESSION["user_planta_id"]);
   if((int)$hasopeninit["id"])
   {
      $currtme = time();
      $sql = " update prod_worker_init
               set
               win_enddat  = {$currtme},
               win_status  = 2
               where
               id = {$hasopeninit["id"]}";
      $CON->no_result($sql);
   }
}
// echo($_SESSION["wrk_id"]);
//----------------------------------------------------------------------------------
$hasopeninit = getProdOpenWorkerInit($CON, $_SESSION["wrk_id"], $_SESSION["user_planta_id"]);
$hasopenot   = getProdOpenWorkerOTId($CON, $_SESSION["wrk_id"], $_SESSION["user_planta_id"],$_REQUEST["agid"]);

//----------------------------------------------------------------------------------
if(!(int)$hasopeninit["id"])
{
   $sql = " select t1.*, t3.turn_name, t5.inc_name_short, t5.inc_color, t5.inc_color_dom, t6.type_libre_act,
                   t5.inc_type, t4.cfi_inc_id, t7.equipo_name, t6.type_init_hour 'assign_hr_inithr',
                   t6.type_init_min 'assign_hr_initmin',
                   t6.type_end_hour 'assign_hr_endhr', t6.type_end_min 'assign_hr_endmin',
                   t1.assign_equipoaid, t8.type_ant_title
            from turnos_config_assign t1
            INNER JOIN turnos t3                            ON t1.assign_turno_id = t3.id
            LEFT OUTER JOIN turnos_config_incidencias t4    ON t1.incidencia_cfi_id = t4.id
            LEFT OUTER JOIN incidencias t5                  ON t4.cfi_inc_id = t5.id
            LEFT OUTER JOIN turnos_types t6                 ON t1.assign_turno_type_id = t6.id
            LEFT OUTER JOIN equipo t7                       ON t1.assign_equipoaid = t7.id
            LEFT OUTER JOIN equipo_type t8                  ON t7.equipo_type_id = t8.id
            where
            t1.assign_day        = {$sql_day} and
            t1.assign_month      = {$sql_month} and
            t1.assign_year       = {$sql_year} and
            t1.assign_planta_id  = {$_SESSION["user_planta_id"]} and
            t1.assign_worker_id  = {$_SESSION["wrk_id"]} and, 
            t8.type_ant_prod_dabl = 0 and
            t7.equipo_prod_dabl = 0
            order by t3.turn_name, t7.equipo_name, t1.assign_special_slot, t1.assign_worker_id desc, t6.type_libre_act desc";
   $assdata = $CON->select($sql);

   $_SQL_EXLUDE_EQUIPOIDS = "";
   foreach($assdata AS $assdatarow)
      $_SQL_EXLUDE_EQUIPOIDS .= $assdatarow["assign_equipoaid"].",";
   $_SQL_EXLUDE_EQUIPOIDS = substr($_SQL_EXLUDE_EQUIPOIDS, 0, -1);

   //----------------------------------------------------------------------------------
   $sql = " select t1.id, t1.equipo_name, t8.type_ant_title
            from equipo t1
            LEFT OUTER JOIN equipo_type t8 ON t1.equipo_type_id = t8.id
            where
            t1.equipo_status > 0 and
            t8.type_ant_prod_dabl = 0 and
            t1.equipo_prod_dabl = 0  ";
   if($_SQL_EXLUDE_EQUIPOIDS != "")
      $sql .= " and t1.id NOT IN ({$_SQL_EXLUDE_EQUIPOIDS})";
   $sql .= " order by t8.type_ant_title, t1.equipo_name";
   $othereqs = $CON->select($sql);
}

function getProdOpenWorkerOTId($CON, $wrkid, $plantaid, $idagid)
{
   $hasopeninit = getProdOpenWorkerInit($CON, $wrkid, $plantaid);
   if((int)$hasopeninit["id"])
   {
      $sql = " select t1.*, t4.prd_number, t4.prd_reqid
                 from prod_worker_ot t1
                 INNER JOIN prod_worker_init t2   ON t1.wok_init_id = t2.id
                 INNER JOIN prod_agenda t3        ON t1.wok_ag_id = t3.id
                 INNER JOIN prod_header t4        ON t3.ag_prdid = t4.id
                 where
                 t1.wok_init_id = {$hasopeninit["id"]} and
                 t1.wok_ag_id   = {$idagid} and
                 t1.wok_status  = 1";
      $hasopenot = $CON->select($sql);
      $hasopenot = $hasopenot[0];

  
      return $hasopenot;
   }
   return false;
}

?>
<font style="font-size:20px"><b>Iniciar / Terminar turno</b></font>
<div style="clear:both;height:10px"></div>
<table border="0" width="100%" cellpadding="0" cellspacing="0">
<tr>
   <td style="background-color:#FFFFFF;padding:10px;color:#666666;font-size:14px;border-radius:5px;padding:20px">
      <i class="fa fa-fw fa-laptop-code" style="font-size:14px;"></i> Asignaci�n m�quina
      <i class="fa fa-fw fa-chevron-right" style="font-size:14px;"></i>
      Iniciar / Terminar turno
   </td>
</tr>
</table>
<div style="clear:both;height:10px"></div>
<?
if((int)$hasopeninit["id"])
{  ?>
   <table border="0" width="100%" cellpadding="0" cellspacing="0">
   <tr>
      <td style="background-color:#FFFFFF;border:1px solid #EEEEEE;border-radius:5px;padding:20px">
         <table border="0" width="100%" cellpadding="6" cellspacing="0">
         <colgroup>
            <col width="120">
            <col>
         </colgroup>
         <tr>
            <td class="tdleft">Fecha inicio</td>
            <td class="tdnrm"><?=date("d.m.Y", $hasopeninit["win_crtdat"])?></td>
         </tr>
         <tr>
            <td class="tdleft">Hora inicio</td>
            <td class="tdnrm"><?=date("H:i:s", $hasopeninit["win_crtdat"])?></td>
         </tr>
         <tr>
            <td class="tdleft">Tipo</td>
            <td class="tdnrm"><?=$hasopeninit["type_ant_title"]?></td>
         </tr>
         <tr>
            <td class="tdleft">M�quina</td>
            <td class="tdnrm"><?=$hasopeninit["equipo_name"]?></td>
         </tr>
         </table>
         <div style="clear:both;height:10px"></div>
         <?
         if((int)$hasopenot["id"])
         {  ?>
            <div style="clear:both;height:10px"></div>
            <b class="msg_save_err">
               <i class="fa fa-fw fa-exclamation-triangle"></i>
               Termino del turno no disponible, mientras la OT <b><?=$hasopenot["prd_number"]?> se encuentra activada.
            </b>
            <?
         }
         else
         {  ?>
            <div class="btnred"
            onclick="location.href='prodwrk.php?exec=end&refid=<?=$hasopeninit[$x]["id"]?>'">
               <i class="fa fa-fw fa-stop" style="color:white;"></i> Terminar turno&nbsp;
            </div>
            <?
            if((int)$_REQUEST["autoclose"])
            {  ?>
               <script language="Javascript">
                  location.href='prodwrk.php?exec=end&refid=<?=$hasopeninit[$x]["id"]?>'
               </script>
               <?
               exit;
            }
         }
         ?>
      </td>
   </tr>
   </table>
   <?
}
else
{  ?>
   <table border="0" width="100%" cellpadding="0" cellspacing="0">
   <tr>
      <td style="background-color:#FFFFFF;border:1px solid #EEEEEE;border-radius:5px;padding:20px">
         <table border="0" width="100%" cellpadding="6" cellspacing="0">
         <colgroup>
            <col>
            <col>
            <col width="150">
            <col width="130">
            <col width="130">
            <col width="160">
         </colgroup>
         <tr>
            <td class="tdheader">Tipo</td>
            <td class="tdheader">M�quina</td>
            <td class="tdheader">Turno</td>
            <td class="tdheader" align="center">Horario</td>
            <td class="tdheader" align="center">Tipo</td>
            <td class="tdheader" align="center">Opciones</td>
         </tr>
         <?
         for($x = 0; $x < count($assdata) && $assdata != false; $x++)
         {  ?>
            <tr onmouseover="mark(this, 0)" onmouseout="mark(this,1)">
               <td class="tdnrm"><?=$assdata[$x]["type_ant_title"]?></td>
               <td class="tdnrm"><?=$assdata[$x]["equipo_name"]?></td>
               <td class="tdnrm"><?=$assdata[$x]["turn_name"]?></td>
               <td class="tdnrm" align="center">
                  <?=sprintf("%02s", $assdata[$x]["ass_init_hour"])?>:<?=sprintf("%02s", $assdata[$x]["ass_init_min"])?>
                  -
                  <?=sprintf("%02s", $assdata[$x]["ass_end_hour"])?>:<?=sprintf("%02s", $assdata[$x]["ass_end_min"])?>
               </td>
               <td class="tdnrm" align="center"><b class="msg_save_ok">Planificado</b></td>
               <td class="tdnrm" align="center">
                  <div class="btngreen"
                  onclick="location.href='prodwrk.php?exec=init&equipoid=<?=$assdata[$x]["assign_equipoaid"]?>&assid=<?=$assdata[$x]["id"]?>'">
                     <i class="fa fa-fw fa-play" style="color:white;"></i> Iniciar turno&nbsp;
                  </div>
               </td>
            </tr>
            <?
         }
         if(count($othereqs) && $othereqs != false)
         {
            for($x = 0; $x < count($othereqs) && $othereqs != false; $x++)
            {  ?>
               <tr onmouseover="mark(this, 0)" onmouseout="mark(this,1)">
                  <td class="tdnrm"><?=$othereqs[$x]["type_ant_title"]?></td>
                  <td class="tdnrm"><?=$othereqs[$x]["equipo_name"]?></td>
                  <td class="tdnrm"><?=$othereqs[$x]["turn_name"]?></td>
                  <td class="tdnrm" align="center"></td>
                  <td class="tdnrm" align="center"><b class="msg_save_err">Sin turno</b></td>
                  <td class="tdnrm" align="center">
                     <div class="btnorange"
                     onclick="if(askDel('')) { location.href='prodwrk.php?exec=init&equipoid=<?=$othereqs[$x]["id"]?>&assid=0'; }">
                        <i class="fa fa-fw fa-play" style="color:white;"></i> Iniciar turno&nbsp;
                     </div>
                  </td>
               </tr>
               <?
            }
         }
         ?>
         </table>
      </td>
   </tr>
   </table>
   <?
}